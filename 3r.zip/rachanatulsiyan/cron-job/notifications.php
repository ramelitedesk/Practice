<?php
include "db_config.php";

// Ensure required POST data is received
$subject = $_POST['subject'] ?? 'Blog Notification';
$message = $_POST['message'] ?? '';

if (empty($message)) {
    die("Message content is required.");
}

// Fetch all emails from newsletter form submissions
$sql = "SELECT form_data FROM rachanaatulsyan_form_data WHERE form_name = 'newsletter form'";
$result = $conn->query($sql);

if (!$result) {
    die("Database query failed: " . $conn->error);
}

$emails = [];
while ($row = $result->fetch_assoc()) {
    $data = json_decode($row['form_data'], true);
    if (isset($data['email']) && filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $emails[] = $data['email'];
    }
}

if (empty($emails)) {
    die("No valid subscriber emails found.");
}

$insert = $conn->prepare("INSERT INTO rachanaatulsyan_email_queue (email, subject, message) VALUES (?, ?, ?)");
$insert->bind_param("sss", $email, $subject, $message);

foreach ($emails as $email) {
    $insert->execute();
}

echo "Emails have been queued.";

?>