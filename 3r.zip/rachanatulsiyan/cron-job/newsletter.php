<?php
include "db_config.php";
include("include-file/header.php");
?>
<?php

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

use SendGrid\Mail\Mail;

require 'include-file/vendor/autoload.php';

$emailErr = "";
$email = $form_title = "";
$formData = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        return $data;
    }

    // Ensure $conn is initialized
    if (!isset($conn)) {
        die("Database connection not established.");
    }

    $form_title = !empty($_POST["form_title"]) ? test_input($_POST["form_title"]) : "";

    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        }
    }

    // Prepare the data for insertion
    $frm_name = strtolower(str_replace(' ', '-', $form_title));
    $form_data = [];
    $exclude_fields = ['form_title', 'subscribe'];
    foreach ($_POST as $key => $value) {
        if (!in_array($key, $exclude_fields)) {
            $form_data[$key] = htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
        }
    }
    $form_data_json = json_encode($form_data);
    // Insert data into the database
    $sql = "INSERT INTO rachanaatulsyan_form_data (form_name, form_data, created_at) VALUES (?, ?, NOW())";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("ss", $form_title, $form_data_json);

    if ($stmt->execute()) {
        // Send Email
        $emailContent = "";
        $exclude_fields = ['form_title', 'subscribe'];
        foreach ($_POST as $key => $value) {
            if (!in_array($key, $exclude_fields)) {
                $key_clean = htmlspecialchars($key, ENT_QUOTES, 'UTF-8');
                $value_clean = nl2br(htmlspecialchars($value, ENT_QUOTES, 'UTF-8'));
                $emailContent .= "<div style='font-family: Arial, sans-serif; font-size: 14px; color: #333;'>
                <h2 style='background: #0073aa; padding: 10px 20px; margin-bottom: 0; width: 600px; text-align: center; color: #fff; font-size: 18px;'>Subscribed Email!</h2>
                <table style='border-collapse: collapse; width: 100%; max-width: 600px; margin: 0px 0; border: 1px solid #ddd;'>
                    <tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>{$key_clean}</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>{$value_clean}</td>
                    </tr>
                </table>
            </div>";
            }
        }
        $emailContent .= "<p>Best regards,<br>rachanaatulsyan Team</p>";

        $email = new Mail();
        $email->setFrom("ramakrushna.kreative@gmail.com", "rachanaatulsyan");
        $email->setSubject("Newsletter Submission");
        $email->addTo("ramakrushna.kreative@gmail.com");
        $email->addContent("text/html", $emailContent);

        $sendgrid = new \SendGrid('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');

        try {
            $response = $sendgrid->send($email);
            if ($response->statusCode() >= 200 && $response->statusCode() < 300) {
                echo "Post published and email sent successfully!";
                echo "<script>
                    alert('Thank You for Contact us.');
                    window.location.href = 'https://www.rachanaatulsyan.com/newsletter.php';
                  </script>";
                exit();
            } else {
                echo "Failed to send email. Response code: " . $response->statusCode();
            }
        } catch (Exception $e) {
            echo "Email could not be sent. Error: " . $e->getMessage();
        }
    } else {
        echo "Database Error: " . $stmt->error;
    }

    $stmt->close();

}
?>
<style>
    .newsletter-section {
        padding: 60px 20px;
        text-align: center;
        background-color: #f8f8f8;
    }

    .newsletter-section .container {
        max-width: 600px;
        margin: 0 auto;
    }

    .newsletter-section h2 {
        font-size: 28px;
        color: #2c2c2c;
        margin-bottom: 10px;
    }

    .newsletter-section p {
        font-size: 16px;
        color: #555;
        margin-bottom: 25px;
    }

    .newsletter-form {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .newsletter-form input[type="email"] {
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 16px;
    }

    .newsletter-form button {
        padding: 12px;
        background-color: #e3ac24;
        color: #fff;
        border: none;
        border-radius: 4px;
        font-size: 16px;
        cursor: pointer;
    }

    .newsletter-form button:hover {
        background-color: #c8971f;
    }
</style>
<section>
    <div class="progress"></div>
    <input type="checkbox" id="myInput">
    <label for="myInput"> <span class="bar top"></span> <span class="bar middle"></span> <span
            class="bar bottom"></span> </label>
    <aside>

        <div class="aside-section aside-left">
            <div class="aside-content"> </div>
        </div>
        <div class="aside-section aside-right">
            <?php include("include-file/menu-content.php") ?>
        </div>
    </aside>

    <!--End Menu-->
</section>
<section>
    <div class="service-inner-header relative">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="inner-heading w-100" data-aos="fade-down">
                        <h1 class="w-100 text-center">Support and Guidance for Family Court Matters</h1>
                        <h4 class="text-center yellow">Receive compassionate and actionable strategies to navigate the
                            family court
                            system.</h4>
                    </div>
                </div>

            </div>
        </div>

        <div class="inner-page-tr_bg"></div>

    </div>
</section>
<section class="newsletter-section">
    <!--<div class="container ">
     <div class="row">
      <div class="col-sm-12 static-heading">
      <div class="inner-heading w-full" data-aos="fade-down">
        <h1 class="text-center">Coaching/Services</h1>
        <h4 class="text-center">Empowering Your Rights</h4>
      </div></div>
      
     </div>
    </div>-->
    <div class="box-container" data-aos="fade-down">

        <div class="container service-container">
            <h3 class="overview-heading mb-4"><span>Subscribe to Our Newsletter</span>
            </h3>
            <p>Stay informed with the latest updates and guidance from Rachanaa Tulsyan.</p>
            <div class="row">
                <div class="col-sm-12">
                    <form action="" method="post" enctype="multipart/form-data" class="newsletter-form">
                        <input type="hidden" name="form_title" value="newsletter form">
                        <input type="email" name="email" placeholder="Enter your email" required>
                        <button type="submit" name="subscribe" value="subscribe">Subscribe</button>
                    </form>

                </div>
            </div>


        </div>
    </div>
</section>
<div class="inner-footer"><?php include("include-file/footer.php") ?></div>
<?php include("include-file/footer-js.php") ?>