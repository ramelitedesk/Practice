<?php

session_start();

$server = "localhost";

$user = "rachnatulsyan_blogs";

$password = "rghdKHWxMUxi";

$db_name = "rachnatulsyan_blogs";



$conn = mysqli_connect($server, $user, $password, $db_name);

if (!$conn) {

    die("Connection Failed: " . mysqli_connect_error());

}
//  else {

//     echo "Database Connected Successfully!";

// }



function pr($dt)
{

    echo "<pre>";

    print_r($dt);

    echo "</pre>";

}


?>