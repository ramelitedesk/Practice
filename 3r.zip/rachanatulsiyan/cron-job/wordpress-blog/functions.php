<?php
/**
 * numbertree functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package numbertree
 */

if (!defined('_S_VERSION')) {
	// Replace the version number of the theme on each release.
	define('_S_VERSION', '1.0.0');
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function numbertree_setup()
{
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on numbertree, use a find and replace
	 * to change 'numbertree' to the name of your theme in all the template files.
	 */
	load_theme_textdomain('numbertree', get_template_directory() . '/languages');

	// Add default posts and comments RSS feed links to head.
	add_theme_support('automatic-feed-links');

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support('title-tag');

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support('post-thumbnails');

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__('Primary', 'numbertree'),
		)
	);

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'numbertree_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support('customize-selective-refresh-widgets');

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height' => 250,
			'width' => 250,
			'flex-width' => true,
			'flex-height' => true,
		)
	);
}
add_action('after_setup_theme', 'numbertree_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function numbertree_content_width()
{
	$GLOBALS['content_width'] = apply_filters('numbertree_content_width', 640);
}
add_action('after_setup_theme', 'numbertree_content_width', 0);

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function numbertree_widgets_init()
{
	register_sidebar(
		array(
			'name' => esc_html__('Sidebar', 'numbertree'),
			'id' => 'sidebar-1',
			'description' => esc_html__('Add widgets here.', 'numbertree'),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget' => '</section>',
			'before_title' => '<h2 class="widget-title">',
			'after_title' => '</h2>',
		)
	);
}
add_action('widgets_init', 'numbertree_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function numbertree_scripts()
{
	wp_enqueue_style('numbertree-style', get_stylesheet_uri(), array(), _S_VERSION);
	wp_style_add_data('numbertree-style', 'rtl', 'replace');

	wp_enqueue_script('numbertree-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);

	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}
}
add_action('wp_enqueue_scripts', 'numbertree_scripts');

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
	require get_template_directory() . '/inc/jetpack.php';
}

function theme_setup()
{
	add_theme_support('post-thumbnails');
}
add_action('after_setup_theme', 'theme_setup');

function theme_scripts()
{
	wp_enqueue_style('theme-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'theme_scripts');

function register_theme_menus()
{
	register_nav_menus(array(
		'primary' => __('Header Menu', 'textdomain'),
	));
}
add_action('after_setup_theme', 'register_theme_menus');

//pagination
function custom_pagination($query = null)
{
	if ($query === null) {
		global $wp_query;
		$query = $wp_query;
	}

	$total_pages = $query->max_num_pages;

	if ($total_pages > 1) {
		$current_page = max(1, get_query_var('paged'));

		echo paginate_links(array(
			'base' => get_pagenum_link(1) . '%_%',
			'format' => '/page/%#%',
			'current' => $current_page,
			'total' => $total_pages,
			'prev_text' => __('« prev'),
			'next_text' => __('next »'),
		));
	}
}
function register_header_menu()
{
	register_nav_menu('header', 'Header Menu');
}
add_action('after_setup_theme', 'register_header_menu');

function register_my_menu()
{
	register_nav_menu('footer', 'Footer Menu');
}
add_action('after_setup_theme', 'register_my_menu');

function custom_menu_icons($menu, $args)
{
	if ($args->theme_location === 'footer') {
		$menu = preg_replace('/<a(.*?)<\/a>/', '<a$1</a><i class="far fa-star"></i>', $menu);
	}
	return $menu;
}
add_filter('wp_nav_menu_items', 'custom_menu_icons', 10, 2);



function add_additional_class_on_a($classes, $item, $args)
{
	if (isset($args->add_a_class)) {
		$classes['class'] = $args->add_a_class;
	}
	return $classes;
}

add_filter('nav_menu_link_attributes', 'add_additional_class_on_a', 1, 3);



function custom_admin_styles($hook)
{
	// Check if we are on the 'form-data' admin page
	if ($hook != 'toplevel_page_leads') {
		return;
	}
	wp_enqueue_style('rj-all-css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css', array(), '6.7.2');
	wp_enqueue_style('rj-dataTables-bootstrap-css', 'https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/css/dataTables.bootstrap.min.css', array(), '1.10.21');
	wp_enqueue_style('rj-dataTables-jqueryui-css', 'https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/css/dataTables.jqueryui.min.css', array(), '1.10.21');
	wp_enqueue_style('rj-jqueryui-css', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.14.1/themes/cupertino/jquery-ui.min.css', array(), '1.10.21');

	wp_enqueue_script('rj-jquery-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js', array(), '3.7.1', false);
	wp_enqueue_script('rj-dataTables-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/jquery.dataTables.min.js', array(), '1.10.21', true);
	wp_enqueue_script('rj-dataTables-jqueryui-js-js', 'https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/dataTables.jqueryui.min.js', array(), '1.10.21', true);
	wp_enqueue_script('rj-ajax-js', get_template_directory_uri() . '/assets/js/ajax.js', array(), '1.0.0', true);
	wp_localize_script('rj-ajax-js', 'ajax_object', array(
		'ajax_url' => admin_url('admin-ajax.php'),
	));
}

add_action('admin_enqueue_scripts', 'custom_admin_styles');

function theme_options_page()
{
	add_menu_page(
		'Leads',
		'Leads',
		'manage_options',
		'leads',
		'show_lead__fn',
		'dashicons-media-default',
		5
	);
}
add_action('admin_menu', 'theme_options_page');

function show_lead__fn()
{
	?>
	<style>
		.frm_container {
			position: absolute;
			top: 8%;
			left: 20%;
			transform: translate(-50%, -50%);
		}

		div#emailTable_wrapper {
			margin-top: 130px;
			padding: 1rem;

		}

		table.dataTable thead th div.DataTables_sort_wrapper span {
			display: none;
		}

		table.dataTable tbody td {
			font-weight: 400;
		}

		p {
			color: #fff;
			margin-bottom: 0.5rem;
			font-size: 1.4rem;
			text-align: center
		}

		select {
			width: 350px;
			outline: none;
			border: 1px solid #fff;
			padding: 1rem;
			font-size: 1.1rem;
			border-radius: 0.5rem;
			box-shadow: 0 1px 4px rgb(146 161 176 / 15%);
			cursor: pointer;
		}

		select:focus,
		select:hover {
			outline: none;
			border: 1px solid rgba(0, 0, 0, 0.329);
		}
	</style>
	<?php
	global $wpdb;
	$frm_nm = 'newsletter form';
	$table_name = 'rachanaatulsyan_form_data';

	$query = $wpdb->prepare("SELECT * FROM $table_name WHERE form_name = %s ORDER BY id DESC", $frm_nm);
	$results = $wpdb->get_results($query, ARRAY_A);


	// Collect all possible keys from form_data
	$all_keys = [];
	foreach ($results as $row) {
		$form_data = json_decode($row['form_data'], true);
		if (is_array($form_data)) {
			$all_keys = array_merge($all_keys, array_keys($form_data));
		}
	}
	$all_keys = array_unique($all_keys);
	echo '<table id="emailTable" class="display" style="color: #4A4A4A;background-color: #D9EDF7;font-family:Poppins,sans-serif;font-size: 14px;font-weight: 100;">';
	echo "<thead>
    <tr style='background: #f9f9f9;'>
        <th style='border: 1px solid #ccc;'>ID</th>";

	foreach ($all_keys as $key) {
		echo "<th style='border: 1px solid #ccc;'>" . esc_html(ucfirst($key)) . "</th>";
	}

	echo "<th style='border: 1px solid #ccc;'>Date</th>
    <th style='border: 1px solid #ccc;'>Action</th>
    </tr>
    </thead>";
	echo '<tbody>';
	foreach ($results as $row) {
		$form_data = json_decode($row['form_data'], true);
		$form_nm = $row['form_name'];
		$iid = $row['id'];
		$created_at = $row['created_at'];
		$formatted_data = '';
		foreach ($form_data as $key => $value) {
			$formatted_data .= "<strong>" . esc_html($key) . "</strong>: " . esc_html($value) . "<br>";
		}

		echo "<tr>
            <td style='border: 1px solid #ccc;'>{$iid}</td>";

		foreach ($all_keys as $key) {
			$value = isset($form_data[$key]) ? esc_html($form_data[$key]) : '';
			echo "<td style='border: 1px solid #ccc;'>{$value}</td>";
		}

		echo "<td style='border: 1px solid #ccc;'>" . esc_html($created_at ?? '') . "</td>
       <td><button class='remove-email' data-Order-id='{$iid}' style='cursor:pointer;'><i class='fa-solid fa-trash'></i></button></td>
          </tr>";
	}

	echo '</tbody>';
	echo '</table>';
	?>
	<!-- <script type="text/javascript">$('#emailTable').DataTable();</script> -->
	<script>
		jQuery(document).ready(function () {
			jQuery('#emailTable').DataTable({
			});
		});
	</script>
	<?php
}
function handle_remove_email()
{
	$order_id = isset($_POST['removeId']) ? intval($_POST['removeId']) : 0;

	if (!$order_id || !is_numeric($order_id)) {
		$response = array(
			'success' => false,
			'data' => array(
				'message' => 'Invalid order ID',
			),
		);
		wp_send_json($response);
	}

	global $wpdb;
	$table_name = 'rachanaatulsyan_form_data';

	$result = $wpdb->delete(
		$table_name,
		array('id' => $order_id),
		array('%d')
	);

	if ($result !== false) {
		$response = array(
			'success' => true,
			'data' => array(
				'message' => 'Data removed successfully',
			),
		);
	} else {
		$response = array(
			'success' => false,
			'data' => array(
				'message' => 'Error removing data from the database',
			),
		);
		error_log('Database deletion failed: ' . $wpdb->last_error);
	}

	wp_send_json($response);
}

add_action('wp_ajax_remove_email', 'handle_remove_email');
add_action('wp_ajax_nopriv_remove_email', 'handle_remove_email');

//send notification on publish
function notify_subscribers_on_blog_event($post_ID, $post = null) {
    // Only for blog posts
    if (get_post_type($post_ID) !== 'post') return;

    // Only if post is published
    if ($post->post_status !== 'publish') return;

    $title = get_the_title($post_ID);
    $link  = get_permalink($post_ID);

    $subject = "New Blog Post: $title";
     $message = "
     <div style='font-family: Arial, sans-serif; font-size: 14px; color: #333;'>
                <h2 style='background: #0073aa; padding: 10px 20px; margin-bottom: 0; width: 600px; text-align: center; color: #fff; font-size: 18px;'>A new blog post has been published</h2>
                <table style='border-collapse: collapse; width: 100%; max-width: 600px; margin: 0px 0; border: 1px solid #ddd;'>
                    <tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>$title</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'><a href='$link'>$link</a></td>
                    </tr>
                </table>
            </div>
    ";

    // Send POST request to core PHP notification script
    wp_remote_post('https://www.rachanaatulsyan.com/notifications.php', [
        'method'    => 'POST',
        'body'      => [
            'subject' => $subject,
            'message' => $message
        ],
        'timeout'   => 15
    ]);
}
add_action('publish_post', 'notify_subscribers_on_blog_event', 10, 2);
function notify_on_blog_post_edit($post_ID, $post, $update) {
    // Only for 'post' post type
    if ($post->post_type !== 'post') return;

    // Skip if it's not an update (i.e., a new post creation)
    if (!$update) return;

    // Skip autosaves and revisions
    if (wp_is_post_autosave($post_ID) || wp_is_post_revision($post_ID)) return;

    // Only notify if post is published
    if ($post->post_status !== 'publish') return;

    $title = get_the_title($post_ID);
    $link  = get_permalink($post_ID);

    $subject = "Blog Post Updated: $title";
    $message = "
    <div style='font-family: Arial, sans-serif; font-size: 14px; color: #333;'>
        <h2 style='background: #d9534f; padding: 10px 20px; margin-bottom: 0; width: 600px; text-align: center; color: #fff; font-size: 18px;'>A blog post has been updated</h2>
        <table style='border-collapse: collapse; width: 100%; max-width: 600px; margin: 0px 0; border: 1px solid #ddd;'>
            <tr>
                <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f9f9f9;'>$title</td>
                <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'><a href='$link'>$link</a></td>
            </tr>
        </table>
    </div>
    ";

    wp_remote_post('https://www.rachanaatulsyan.com/notifications.php', [
        'method'    => 'POST',
        'body'      => [
            'subject' => $subject,
            'message' => $message
        ],
        'timeout'   => 15
    ]);
}
add_action('save_post', 'notify_on_blog_post_edit', 10, 3);
