<?php
include "db_config.php";
error_reporting(E_ALL);
ini_set('display_errors', 1);

use SendGrid\Mail\Mail;

require 'include-file/vendor/autoload.php';
// Fetch 20 pending emails
$sql = "SELECT * FROM rachanaatulsyan_email_queue WHERE status = 'pending' LIMIT 1";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
while ($email = mysqli_fetch_assoc($result)) {
    $emailData = new Mail();
    $emailData->setFrom("ramakrushna.kreative@gmail.com", "rachanaatulsyan");
    $emailData->setSubject($email['subject']);
    $emailData->addTo($email['email']);
    $emailData->addContent("text/html", $email['message']);

    $sendgrid = new \SendGrid('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');

    try {
        $response = $sendgrid->send($emailData);
        if ($response->statusCode() == 202) {
            $status = 'sent';
        } else {
            $status = 'failed';
            // Optional: log error body for debugging
            error_log(print_r($response->body(), true));
        }
    } catch (Exception $e) {
        $status = 'failed';
        error_log('Caught exception: ' . $e->getMessage());
    }
    // Update status in the database
    $id = intval($email['id']);
    $update_sql = "UPDATE rachanaatulsyan_email_queue SET status = '$status', sent_at = NOW() WHERE id = $id";
    mysqli_query($conn, $update_sql);
}

mysqli_close($conn);