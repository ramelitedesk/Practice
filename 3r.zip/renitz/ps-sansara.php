<?php
session_start();
include "./db_config.php";
require_once 'Forms/ps-sansara-form.php';
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Renitz Properties</title>
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico">

    <!--Font Style-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&display=swap"
        rel="stylesheet">
    <!--    owl-carousel-css-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"
        integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"
        integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!--Popup Comming Start-->
    <link href="assets/css/cust-popup.css" rel="stylesheet">
    <!--Popup Comming End-->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" id="fancybox-css-css"
        href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css?ver=3.5.7" media="all">

    <!-- Custom CSS -->
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/styles.css" rel="stylesheet">
    <link href="assets/css/custom-new.css" rel="stylesheet">
    <link href="assets/css/custom-ps.css" rel="stylesheet">
    <link href="assets/css/custom-landing.css" rel="stylesheet">

</head>

<body>
    <nav class="pssansara__header navbar navbar-expand-lg">
        <div class="container">
            <!-- Brand -->
            <div class="pssansara__header-wrap">
                <a class="nav-brand me-0 static-logo" href="index.php"><img src="assets/img/logo-header.png"
                        class="logo" alt=""></a>

                <button class="navbar-toggler collapsed" type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar2"
                    aria-labelledby="offcanvasNavbar2Label">
                    <div class="offcanvas-header">
                        <button type="button" class="btn-close " data-bs-dismiss="offcanvas"
                            aria-label="Close"></button>
                    </div>
                    <!-- Navbar links -->
                    <div class="offcanvas-body">
                        <ul class="navbar-nav align-items-center">
                            <li class="nav-item">
                                <a class="nav-link nav-link-custom" href="#overview">Overview</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link nav-link-custom" href="#highlights">Highlights</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link nav-link-custom" href="#price">Price</a>
                            </li>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link nav-link-custom" href="#gallery">Gallery</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link nav-link-custom" href="#location">Location</a>

                            <li class="nav-item">
                                <a class="nav-link" href="#contact">Contact Us</a>
                            </li>
                            <li class="nav-item" style="margin-top:5px;">
                                <a href="tel:8420994555" class="btn btn-primary"><b><i class="fa fa-phone"
                                            aria-hidden="true"></i>
                                        +918420994555</b></a>
                            </li>
                            <li class="nav-item" style="margin-top:5px;">
                                <a href="#" class="btn btn-primary text-uppercase  rounded-0" data-toggle="modal"
                                    data-target="#modal1">DOWNLOAD
                                    BROCHURE
                                </a>

                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- end of sansara__header -->
    <section class="banner banner--project-details"
        style="background:url('../assets/img/across-theGanges.jpg') no-repeat center center;background-size: cover;overflow: hidden;">
        <div class="hero-clouds"></div>
        <div class="container cloud-overlay">
            <div class="row">
                <div class="col-sm-12">
                    <div class="text-bg aos-init aos-animate" data-aos="background-expand">
                        <div class="text-bg__inner slt-inner-border">
                            <h1>Sansara <span
                                    style="font-family:Poppins-Medium;color: #fff!important; font-size:14px; display:block; letter-spacing: 0.5px;font-family: 'Poppins-Regular'; line-height: 30px;">
                                    Riverfront Luxury Residences in Howrah</span>
                            </h1>
                        </div>
                    </div>
                    <!--<span class="banner__sub-content">-->

                    <span class="highlight-txt"><!--+--></span>
                    <!--? php// echo ($post_title=='Abacus')||($post_title=='The-Volt') ? 'Units' : 'Families have' ?-->
                    <span class="highlight-txt"></span>
                </div>
            </div>
        </div>
    </section>
    <div class="p-menu-wrapper top-0" id="project-nav">
        <nav>
            <ul class="p-menu__list">
                <li class="p-menu__item p-active"><a class="p-menu__link" href="#p-overview">Overview</a></li>

                <li class="p-menu__item"><a class="p-menu__link" href="#p-gallery">Gallery</a></li>

                <!--<li class="p-menu__item"><a class="p-menu__link" href="#p-specification">Specifications</a></li>-->
                <li class="p-menu__item"><a class="p-menu__link" href="#p-amenities">Highlights</a></li>
                <li class="p-menu__item"><a class="p-menu__link" href="#p-site-plan">Site Plan</a></li>
                <li class="p-menu__item"><a class="p-menu__link" href="#p-floor-plans">Unit Plans</a></li>
                <li class="p-menu__item"><a class="p-menu__link" href="#p-location">Location</a></li>
                <li class="p-menu__item"><a class="p-menu__link" href="#p-enquiry">Enquiry</a></li>
            </ul>
        </nav>
    </div>
    <section class="bg-white-layout scrollto" id="p-overview">
        <div class="bg-patter-top"></div>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="text-center">
                        <div class="text-bg text-bg__blue-patch aos-init aos-animate" data-aos="background-expand">
                            <div class="text-bg__inner bg-white-layout__article  gal-ph ">
                                <h2>Overview</h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-10 col-sm-push-1 over-view col-md-10 ">
                    <div class="row">
                        <div class="col-sm-4 col-md-3">
                            <ul class="overview-menu">
                                <li class="overview-menu__list">
                                    <h3 class="overview-menu__title rtrt">17.4</h3>
                                    <span class="overview-menu__info">Acres</span>
                                </li>
                                <li class="overview-menu__list">
                                    <h3 class="overview-menu__title rtrt">5</h3>
                                    <span class="overview-menu__info">Towers</span>
                                </li>
                                <li class="overview-menu__list">
                                    <h3 class="overview-menu__title rtrt">G+40</h3>
                                    <span class="overview-menu__info">Storey</span>
                                </li>
                                <li class="overview-menu__list">
                                    <h3 class="overview-menu__title rtrt">70%</h3>
                                    <span class="overview-menu__info">Open-to-Sky</span>
                                </li>
                                <li class="overview-menu__list">
                                    <h3 class="overview-menu__title rtrt">2.5</h3>
                                    <span class="overview-menu__info">Acres of Elevated Landscape </span>
                                </li>
                                <li class="overview-menu__list">
                                    <h3 class="overview-menu__title rtrt">1000</h3>
                                    <span class="overview-menu__info">Ft. Riverfront Boulevard</span>
                                </li>
                            </ul>
                        </div>
                        <div class="col-sm-8 col-md-9 overview-content">
                            <p class="overview-content__info"
                                style="padding: 0px; border: 0px; font-variant-numeric: inherit;font-stretch: inherit; line-height: 26px; vertical-align: baseline;">
                                <font face="Poppins-Regular" color="#999999" size="3">
                                </font>
                            </p>
                            <p>
                                <font face="Poppins-Regular" color="#999999" size="3">Discover Sansara, the tallest
                                    riverfront luxury residences on the banks of the Ganges. The first of its kind in
                                    Howrah where every home is thoughtfully designed to be east-facing, offering
                                    stunning river views. With the iconic Howrah Bridge as its backdrop, it blends
                                    nature, family-friendly spaces, and community living. Here, luxury and simplicity
                                    come together to create a peaceful retreat for those who appreciate the finer things
                                    in life.</font>
                            </p>
                            <font face="Poppins-Regular" color="#999999" size="3">

                                <p>&nbsp;</p>
                            </font>
                            <p></p>
                            <p class="overview-content__info"
                                style="padding: 0px; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; line-height: 26px; vertical-align: baseline;">
                                <font face="PlayfairDisplay-Regular" color="#003471">
                                    <span style="font-size: 22px;">It’s more than a place to live. It’s a world of its
                                        own.&nbsp; &nbsp; &nbsp;

                                        &nbsp;

                                        &nbsp;
                                    </span>
                                </font>
                            </p>
                            <p
                                style="padding: 0px; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; line-height: 26px; vertical-align: baseline;">
                                <font face="Poppins-Regular" color="#999999" size="3"></font>
                            </p>
                            <p>
                                <font face="Poppins-Regular" color="#999999" size="3">&nbsp;</font>
                            </p>
                            <font face="Poppins-Regular" color="#999999" size="3">

                                <p>A world where every detail is crafted for comfort and joy. From a neighbourhood mall
                                    for everyday conveniences to a sports area for champions, from a culinary retreat by
                                    the water to the temple and ghat offering a sacred riverfront experience, from a
                                    private jetty and serene water features to lush landscaped spaces, Sansara is
                                    designed for the life you aspire to.</p>

                                <p><br>
                                    Here, every day begins and ends with the calm beauty of the Ganges. Seamlessly
                                    designed and elegantly curated, Sansara is where the river’s rhythm sets the pace
                                    for a life well-lived.</p>

                                <p>&nbsp;</p>

                                <p>It is a world built to celebrate life, where fulfillment meets desire and serenity
                                    meets vibrance.</p>
                            </font>
                            <p></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="bg-white-layout  scrollto pt-0 pb-5" id="">
        <div class="bg-patter-top"></div>
        <div class="container">
            <div class="row">

                <div class="col-sm-8 col-md-9 overview-content pdleft mx-auto">
                    <div class="text-bg text-bg__blue-patch aos-init aos-animate w-100" data-aos="background-expand">
                        <div class="text-bg__inner  bg-white-layout__article  ps__article  text-center w-100">
                            <h2>Pricing (Inclusive of GST &amp; extra charges)</h2>
                            <div class="padd mt-4">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="noline text-start">3BHK</p>
                                        <p>
                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="noline text-center">Rs. 3.11 Cr - 3.50 Cr</p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="noline text-start">4BHK</p>
                                        <p>
                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="noline text-center">Rs. 3.96 Cr - 4.35 Cr</p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="noline text-start">4.5BHK</p>
                                        <p>
                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="noline text-center">Rs. 4.08 Cr - 4.49 Cr</p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="noline text-start">5BHK Duplex</p>
                                        <p>
                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="noline text-center">Rs. 6.17 Cr - 6.38 Cr</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>

    <section id="p-gallery" class="text-center bg-grey-layout scrollto">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div data-aos="background-expand" class="text-bg text-bg__blue-patch aos-init aos-animate">
                        <div class="text-bg__inner bg-white-layout__article gal-ph">
                            <p>Gallery</p>
                            <h2>Residential Project Images</h2>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Desktop-project-gallery-->
            <div class="row  mt-4" style="justify-content: center;display: flex;">
                <div class="col-xs-6">
                    <div class="gallery-slider-img">
                        <img src="assets/img/sansara1.PNG" class="" alt="">
                        <div style="background:rgba(32, 78, 129, 0)" class="overlay verticle-flex-center">
                            <a class=" playGalleryVideo"
                                href="https://www.youtube.com/watch?v=vJDc7jU945o?autoplay=1&amp;rel=0&amp;showinfo=0"
                                data-fancybox="gallery class="><i class="fa-solid fa-play"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-xs-6">
                    <div class="row" role="toolbar">
                        <div class="col-12">
                            <div class="swiper gallery-slider-container">
                                <div class="swiper-wrapper ">

                                    <div class="swiper-slide">
                                        <ul type="none" class="d-flex flex-wrap">
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="13"
                                                        src="https://psgroup.in/uploads/Gallery/The-River-(Infinity-Pool).jpg"
                                                        class="img-responsive" alt="Sansara - The River (Infinity Pool)"
                                                        title="Sansara - The River (Infinity Pool)">
                                                    <span class="hover-effect hover-effect-sm galleryContent">The River
                                                        (Infinity Pool)</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="14"
                                                        src="https://psgroup.in/uploads/Gallery/Boulevard.jpg"
                                                        class="img-responsive" alt="Sansara - Boulevard"
                                                        title="Sansara - Boulevard">
                                                    <span
                                                        class="hover-effect hover-effect-sm galleryContent">Boulevard</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul type="none" class="d-flex flex-wrap">
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="1"
                                                        src="https://psgroup.in/uploads/Gallery/Elevation-Day-View.jpg"
                                                        class="img-responsive" alt="Elevation Day View"
                                                        title="Elevation Day View">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Elevation
                                                        Day View</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="2"
                                                        src="https://psgroup.in/uploads/Gallery/Podium-side-walkway.jpg"
                                                        class="img-responsive" alt="Podium Side Walkway"
                                                        title="Podium Side Walkway">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Podium
                                                        Side Walkway</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="3"
                                                        src="https://psgroup.in/uploads/Gallery/Open-lawn-Amphithetare.jpg"
                                                        class="img-responsive" alt="Open Lawn and Amphitheatre"
                                                        title="Open Lawn and Amphitheatre">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Open Lawn
                                                        and Amphitheatre</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="4"
                                                        src="https://psgroup.in/uploads/Gallery/Elevation-across-the-Ganges.jpg"
                                                        class="img-responsive" alt="Elevation across the Ganges"
                                                        title="Elevation across the Ganges">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Elevation
                                                        across the Ganges</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul type="none" class="d-flex flex-wrap">
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="5"
                                                        src="https://psgroup.in/uploads/Gallery/Elevation-across-the-Ghats.jpg"
                                                        class="img-responsive" alt="Elevation across the Ghats"
                                                        title="Elevation across the Ghats">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Elevation
                                                        across the Ghats</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="6"
                                                        src="https://psgroup.in/uploads/Gallery/Stepped-Garden.jpg"
                                                        class="img-responsive" alt="Stepped Garden"
                                                        title="Stepped Garden">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Stepped
                                                        Garden</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="7"
                                                        src="https://psgroup.in/uploads/Gallery/Floating-Deck.jpg"
                                                        class="img-responsive" alt="Floating Deck"
                                                        title="Floating Deck">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Floating
                                                        Deck</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="8"
                                                        src="https://psgroup.in/uploads/Gallery/Family-Lounge.jpg"
                                                        class="img-responsive" alt="Family Lounge"
                                                        title="Family Lounge">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Family
                                                        Lounge</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul type="none" class="d-flex flex-wrap">
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="9"
                                                        src="https://psgroup.in/uploads/Gallery/The-River-and-water-Cascade.jpg"
                                                        class="img-responsive" alt="The River and Water Cascade"
                                                        title="The River and Water Cascade">
                                                    <span class="hover-effect hover-effect-sm galleryContent">The River
                                                        and Water Cascade</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="10"
                                                        src="https://psgroup.in/uploads/Gallery/Senior-Citizens-Recreation-Area.jpg"
                                                        class="img-responsive" alt="Senior Citizens Recreation Area"
                                                        title="Senior Citizens Recreation Area">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Senior
                                                        Citizens Recreation Area</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="11"
                                                        src="https://psgroup.in/uploads/Gallery/Podium View.jpg"
                                                        class="img-responsive" alt="Podium View" title="Podium View">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Podium
                                                        View</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="12"
                                                        src="https://psgroup.in/uploads/Gallery/Parent-Deck.jpg"
                                                        class="img-responsive" alt="Parent Deck" title="Parent Deck">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Parent
                                                        Deck</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul type="none" class="d-flex flex-wrap">
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="13"
                                                        src="https://psgroup.in/uploads/Gallery/The-River-(Infinity-Pool).jpg"
                                                        class="img-responsive" alt="Sansara - The River (Infinity Pool)"
                                                        title="Sansara - The River (Infinity Pool)">
                                                    <span class="hover-effect hover-effect-sm galleryContent">The River
                                                        (Infinity Pool)</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="14"
                                                        src="https://psgroup.in/uploads/Gallery/Boulevard.jpg"
                                                        class="img-responsive" alt="Sansara - Boulevard"
                                                        title="Sansara - Boulevard">
                                                    <span
                                                        class="hover-effect hover-effect-sm galleryContent">Boulevard</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul type="none" class="d-flex flex-wrap">
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="1"
                                                        src="https://psgroup.in/uploads/Gallery/Elevation-Day-View.jpg"
                                                        class="img-responsive" alt="Elevation Day View"
                                                        title="Elevation Day View">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Elevation
                                                        Day View</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="2"
                                                        src="https://psgroup.in/uploads/Gallery/Podium-side-walkway.jpg"
                                                        class="img-responsive" alt="Podium Side Walkway"
                                                        title="Podium Side Walkway">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Podium
                                                        Side Walkway</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="3"
                                                        src="https://psgroup.in/uploads/Gallery/Open-lawn-Amphithetare.jpg"
                                                        class="img-responsive" alt="Open Lawn and Amphitheatre"
                                                        title="Open Lawn and Amphitheatre">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Open Lawn
                                                        and Amphitheatre</span>
                                                </div>
                                            </li>
                                            <li class="col-xs-6 gallery-slider-sm">
                                                <div class="gallery-slider-img">
                                                    <img data-img="4"
                                                        src="https://psgroup.in/uploads/Gallery/Elevation-across-the-Ganges.jpg"
                                                        class="img-responsive" alt="Elevation across the Ganges"
                                                        title="Elevation across the Ganges">
                                                    <span class="hover-effect hover-effect-sm galleryContent">Elevation
                                                        across the Ganges</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        </div>
    </section>
    <section class="bg-white-layout text-center scrollto" id="p-amenities">
        <div class="bg-patter-top"></div>
        <div class="container">
            <div class="row" style="padding-top:40px;">
                <div class="col-12">
                    <div class="text-bg text-bg__blue-patch aos-init aos-animate" data-aos="background-expand">
                        <div class="text-bg__inner bg-white-layout__article gal-ph">
                            <p>Highlights</p>
                            <h2>Residential Flats Features</h2>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 our-journey__fileds">
                    <ul class="ametenities-menu">

                        <li class="col-lg-3 col-md-4 col-sm-6 col-xs-6 ametenities-menu__list aos-init aos-animate"
                            data-aos="fade-up">
                            <a data-toggle="modal" data-target="#myModal1" data-section="section-1">
                                <figure><img class="img-responsive"
                                        src="https://psgroup.in/uploads/Amenitie_Category/Safety-Security.png"
                                        alt="Garden">

                                    <figcaption><span class="text-uppercase ametenities-menu__title">Safety and
                                            Security</span>
                                        <p class="ametenities-menu__info"></p>
                                    </figcaption>
                                </figure>
                            </a>
                        </li>
                        <li class="col-lg-3 col-md-4 col-sm-6 col-xs-6 ametenities-menu__list aos-init aos-animate"
                            data-aos="fade-up">
                            <a data-toggle="modal" data-target="#myModal1" data-section="section-2">
                                <figure><img class="img-responsive"
                                        src="https://psgroup.in/uploads/Amenitie_Category/occupational-health-and-comfort.png"
                                        alt="Garden">

                                    <figcaption><span class="text-uppercase ametenities-menu__title">Occupational Health
                                            &amp; Comfort</span>
                                        <p class="ametenities-menu__info"></p>
                                    </figcaption>
                                </figure>
                            </a>
                        </li>
                        <li class="col-lg-3 col-md-4 col-sm-6 col-xs-6 ametenities-menu__list aos-init aos-animate"
                            data-aos="fade-up">
                            <a data-toggle="modal" data-target="#myModal1" data-section="section-3">
                                <figure><img class="img-responsive"
                                        src="https://psgroup.in/uploads/Amenitie_Category/solid-waste-management.png"
                                        alt="Garden">

                                    <figcaption><span class="text-uppercase ametenities-menu__title">Solid Waste
                                            Management</span>
                                        <p class="ametenities-menu__info"></p>
                                    </figcaption>
                                </figure>
                            </a>
                        </li>
                        <li class="col-lg-3 col-md-4 col-sm-6 col-xs-6 ametenities-menu__list aos-init aos-animate"
                            data-aos="fade-up">
                            <a data-toggle="modal" data-target="#myModal1" data-section="section-4">
                                <figure><img class="img-responsive"
                                        src="https://psgroup.in/uploads/Amenitie_Category/Other-services.png"
                                        alt="Garden">

                                    <figcaption><span class="text-uppercase ametenities-menu__title">Services</span>
                                        <p class="ametenities-menu__info"></p>
                                    </figcaption>
                                </figure>
                            </a>
                        </li>
                        <li class="col-lg-3 col-md-4 col-sm-6 col-xs-6 ametenities-menu__list aos-init aos-animate"
                            data-aos="fade-up">
                            <a data-toggle="modal" data-target="#myModal1" data-section="section-5">
                                <figure><img class="img-responsive"
                                        src="https://psgroup.in/uploads/Amenitie_Category/fitness.svg" alt="Garden">

                                    <figcaption><span class="text-uppercase ametenities-menu__title">Health &amp;
                                            Fitness</span>
                                        <p class="ametenities-menu__info"></p>
                                    </figcaption>
                                </figure>
                            </a>
                        </li>
                        <li class="col-lg-3 col-md-4 col-sm-6 col-xs-6 ametenities-menu__list aos-init aos-animate"
                            data-aos="fade-up">
                            <a data-toggle="modal" data-target="#myModal1" data-section="section-6">
                                <figure><img class="img-responsive"
                                        src="https://psgroup.in/uploads/Amenitie_Category/kids.svg" alt="Garden">

                                    <figcaption><span class="text-uppercase ametenities-menu__title">Kids</span>
                                        <p class="ametenities-menu__info"></p>
                                    </figcaption>
                                </figure>
                            </a>
                        </li>
                        <li class="col-lg-3 col-md-4 col-sm-6 col-xs-6 ametenities-menu__list aos-init aos-animate"
                            data-aos="fade-up">
                            <a data-toggle="modal" data-target="#myModal1" data-section="section-7">
                                <figure><img class="img-responsive"
                                        src="https://psgroup.in/uploads/Amenitie_Category/green.svg" alt="Garden">

                                    <figcaption><span class="text-uppercase ametenities-menu__title">Green
                                            Therapy</span>
                                        <p class="ametenities-menu__info"></p>
                                    </figcaption>
                                </figure>
                            </a>
                        </li>
                        <li class="col-lg-3 col-md-4 col-sm-6 col-xs-6 ametenities-menu__list aos-init aos-animate"
                            data-aos="fade-up">
                            <a data-toggle="modal" data-target="#myModal1" data-section="section-8">
                                <figure><img class="img-responsive"
                                        src="https://psgroup.in/uploads/Amenitie_Category/therapy.png" alt="Garden">

                                    <figcaption><span class="text-uppercase ametenities-menu__title">Blue Therapy</span>
                                        <p class="ametenities-menu__info"></p>
                                    </figcaption>
                                </figure>
                            </a>
                        </li>
                        <li class="col-lg-3 col-md-4 col-sm-6 col-xs-6 ametenities-menu__list aos-init aos-animate"
                            data-aos="fade-up">
                            <a data-toggle="modal" data-target="#myModal1" data-section="section-9">
                                <figure><img class="img-responsive"
                                        src="https://psgroup.in/uploads/Amenitie_Category/therapy.png" alt="Garden">

                                    <figcaption><span class="text-uppercase ametenities-menu__title">Boulevard</span>
                                        <p class="ametenities-menu__info"></p>
                                    </figcaption>
                                </figure>
                            </a>
                        </li>
                        <li class="col-lg-3 col-md-4 col-sm-6 col-xs-6 ametenities-menu__list aos-init aos-animate"
                            data-aos="fade-up">
                            <a data-toggle="modal" data-target="#myModal1" data-section="section-10">
                                <figure><img class="img-responsive"
                                        src="https://psgroup.in/uploads/Amenitie_Category/Indoor-Amenities.png"
                                        alt="Garden">

                                    <figcaption><span class="text-uppercase ametenities-menu__title">Podium</span>
                                        <p class="ametenities-menu__info"></p>
                                    </figcaption>
                                </figure>
                            </a>
                        </li>
                        <li class="col-lg-3 col-md-4 col-sm-6 col-xs-6 ametenities-menu__list aos-init aos-animate"
                            data-aos="fade-up">
                            <a data-toggle="modal" data-target="#myModal1" data-section="section-11">
                                <figure><img class="img-responsive"
                                        src="https://psgroup.in/uploads/Amenitie_Category/Indoor-Amenities.png"
                                        alt="Garden">

                                    <figcaption><span class="text-uppercase ametenities-menu__title">Other Indoor
                                            Amenities (At Podium Level)</span>
                                        <p class="ametenities-menu__info"></p>
                                    </figcaption>
                                </figure>
                            </a>
                        </li>
                        <li class="col-lg-3 col-md-4 col-sm-6 col-xs-6 ametenities-menu__list aos-init aos-animate"
                            data-aos="fade-up">
                            <a data-toggle="modal" data-target="#myModal1" data-section="section-12">
                                <figure><img class="img-responsive"
                                        src="https://psgroup.in/uploads/Amenitie_Category/landscape.svg" alt="Garden">

                                    <figcaption><span class="text-uppercase ametenities-menu__title">Green
                                            Features</span>
                                        <p class="ametenities-menu__info"></p>
                                    </figcaption>
                                </figure>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="bg-white-layout text-center scrollto pt-0 pb-0" id="p-site-plan">
        <div class="container">
            <div class="row ">
                <div class="col-12 text-center">
                    <div class="text-bg text-bg__blue-patch aos-init aos-animate" data-aos="background-expand">
                        <div class="text-bg__inner bg-white-layout__article gal-ph">
                            <p>Site Plan</p>
                            <h2>Know Your Home</h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="family-slider-wrapperFamily w-100 padding-top90">
                        <div class="demo-gallery" data-pswp-uid="1">
                            <div class="slick-img-slideFamily ">


                                <a href="https://psgroup.in/uploads/Siteplan/site-plan_1653X946.jpg"
                                    data-size="1600x1600"
                                    data-med="https://psgroup.in/uploads/Siteplan/site-plan_1653X946.jpg"
                                    data-med-size="1024x1024" class="demo-gallery__img--main" tabindex="0">
                                    <img style="object-fit:contain;" class="img-responsive pointer-events"
                                        src="https://psgroup.in/uploads/Siteplan/site-plan_1653X946.jpg" alt="Site Plan"
                                        title="Site Plan">
                                    <div class="slider-content-slide__inner">
                                        <p class="site-plan-para">Site Plan</p>
                                    </div>
                                </a>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="bg-white-layout text-center scrollto" id="p-floor-plans">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="text-bg text-bg__blue-patch aos-init aos-animate" data-aos="background-expand">
                        <div class="text-bg__inner bg-white-layout__article gal-ph">
                            <p>Unit Plans</p>
                            <h2>3, 4 and 5 BHK homes</h2>
                        </div>
                    </div>
                </div>
                <div class="col-12 mt-5">
                    <div class="tabbable boxed parentTabs text-center">
                        <div class="primary-tabs">
                            <button class="primary-tab active" data-primary="3bhk">3BHK</button>
                            <button class="primary-tab" data-primary="4bhk-study">4BHK + Study</button>
                            <button class="primary-tab" data-primary="4bhk">4BHK</button>
                            <button class="primary-tab" data-primary="5bhk-duplex">5BHK Duplex</button>
                        </div>
                        <!-- Child Tabs Container -->
                        <div class="child-tabs-container">
                            <!-- 3BHK Child Tabs -->
                            <div class="child-tabs active" data-parent="3bhk">
                                <button class="child-tab active" data-unit="3bhk-unit-a">Unit A - 2515 sqft</button>
                                <button class="child-tab" data-unit="3bhk-unit-c">Unit C - 2580 sqft</button>
                            </div>

                            <!-- 4BHK + Study Child Tabs -->
                            <div class="child-tabs" data-parent="4bhk-study">
                                <button class="child-tab" data-unit="4bhk-study-unit-b">Unit D - 3364 sqft</button>

                            </div>

                            <!-- 4BHK Child Tabs -->
                            <div class="child-tabs" data-parent="4bhk">
                                <button class="child-tab" data-unit="4bhk-unit-e">Unit B - 3272 sqft</button>

                            </div>

                            <!-- 5BHK Duplex Child Tabs -->
                            <div class="child-tabs" data-parent="5bhk-duplex">
                                <button class="child-tab" data-unit="5bhk-duplex-unit-g">Unit C Lower - 2585
                                    sqft</button>
                                <button class="child-tab" data-unit="5bhk-duplex-unit-h">Unit C upper - 2300
                                    sqft</button>
                            </div>
                        </div>
                        <!-- Content Area -->
                        <div class="content-area">
                            <!-- 3BHK Units -->
                            <div class="unit-content active" data-content="3bhk-unit-a">
                                <div class=" padding-top90">
                                    <a href="https://psgroup.in/uploads/Floorplan/unit-A-3BHK-desktop.jpg"
                                        data-size="2000x806"
                                        data-med="https://psgroup.in/uploads/Floorplan/unit-A-3BHK-desktop.jpg"
                                        data-med-size="">
                                        <img style="max-width: 1000px" class="img-responsive pointer-events"
                                            src="https://psgroup.in/uploads/Floorplan/unit-A-3BHK-desktop.jpg"
                                            alt="2515 sqft" title="2515 sqft">
                                    </a>
                                </div>
                            </div>

                            <div class="unit-content" data-content="3bhk-unit-c">
                                <div class=" padding-top90">
                                    <a href="https://psgroup.in/uploads/Floorplan/unit-B-4bhk-desktop.jpg"
                                        data-size="2000x806"
                                        data-med="https://psgroup.in/uploads/Floorplan/unit-B-4bhk-desktop.jpg"
                                        data-med-size="">
                                        <img style="max-width: 1000px" class="img-responsive pointer-events"
                                            src="https://psgroup.in/uploads/Floorplan/unit-B-4bhk-desktop.jpg"
                                            alt="Unit B - 3272 sqft" title="Unit B - 3272 sqft">
                                    </a>
                                </div>
                            </div>


                            <div class="unit-content" data-content="4bhk-study-unit-b">
                                <div class=" padding-top90">
                                    <a href="https://psgroup.in/uploads/Floorplan/unit-D-4BHK-study.jpg"
                                        data-size="2000x806"
                                        data-med="https://psgroup.in/uploads/Floorplan/unit-D-4BHK-study.jpg"
                                        data-med-size="">
                                        <img style="max-width: 1000px" class="img-responsive pointer-events"
                                            src="https://psgroup.in/uploads/Floorplan/unit-D-4BHK-study.jpg"
                                            alt="Unit D - 3364 sqft" title="Unit D - 3364 sqft">
                                    </a>

                                </div>
                            </div>


                            <!-- 4BHK Units -->
                            <div class="unit-content" data-content="4bhk-unit-e">
                                <div class=" padding-top90">
                                    <a href="https://psgroup.in/uploads/Floorplan/unit-D-4BHK-study.jpg"
                                        data-size="2000x806"
                                        data-med="https://psgroup.in/uploads/Floorplan/unit-D-4BHK-study.jpg"
                                        data-med-size="">
                                        <img style="max-width: 1000px" class="img-responsive pointer-events"
                                            src="https://psgroup.in/uploads/Floorplan/unit-D-4BHK-study.jpg"
                                            alt="Unit D - 3364 sqft" title="Unit D - 3364 sqft">
                                    </a>

                                </div>
                            </div>


                            <!-- 5BHK Duplex Units -->
                            <div class="unit-content" data-content="5bhk-duplex-unit-g">
                                <div class=" padding-top90">
                                    <a href="https://psgroup.in/uploads/Floorplan/unit-A-3BHK-desktop.jpg"
                                        data-size="2000x806"
                                        data-med="https://psgroup.in/uploads/Floorplan/unit-A-3BHK-desktop.jpg"
                                        data-med-size="">
                                        <img style="max-width: 1000px" class="img-responsive pointer-events"
                                            src="https://psgroup.in/uploads/Floorplan/unit-A-3BHK-desktop.jpg"
                                            alt="2515 sqft" title="2515 sqft">
                                    </a>
                                </div>
                            </div>

                            <div class="unit-content" data-content="5bhk-duplex-unit-h">
                                <div class="tab-pane tab-content " id="tab10">
                                    <div class=" padding-top90">
                                        <a href="https://psgroup.in/uploads/Floorplan/unit-B-4bhk-desktop.jpg"
                                            data-size="2000x806"
                                            data-med="https://psgroup.in/uploads/Floorplan/unit-B-4bhk-desktop.jpg"
                                            data-med-size="">
                                            <img style="max-width: 1000px" class="img-responsive pointer-events"
                                                src="https://psgroup.in/uploads/Floorplan/unit-B-4bhk-desktop.jpg"
                                                alt="Unit B - 3272 sqft" title="Unit B - 3272 sqft">
                                        </a>
                                    </div>

                                </div>
                            </div>
                        </div>



                    </div>
                </div>
            </div>

        </div>
        </div>

    </section>
    <!--START: Contact-->
    <section class="text-center bg-white-layout contact-section scrollto pt-0" id="p-location">
        <div class="container-fluid">
            <div class="row">
                <div class="text-bg text-bg__blue-patch" data-aos="background-expand">
                    <div class="text-bg__inner bg-white-layout__article gal-ph">
                        <p></p>
                        <h2></h2>
                    </div>
                </div>

                <div class="map-container">
                    <div id="map"><iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d117890.78511859369!2d88.36745721304786!3d22.575847893781994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1748348284156!5m2!1sen!2sin"
                            style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe></div>
                    <div class="our-location-container">
                        <div class="place">
                            <h2 class="place__heading">Sansara</h2>
                            <address class="place__info">Howrah</address>
                        </div>
                        <ul class="our-places">
                            <li class="our-places__list col-xs-6" id="Healthcare">
                                <input class="with-gap" id="hospitals" name="place_type" type="radio" value="hospitals"
                                    checked="" style="display: inline;"> <img class="loc-img"
                                    src="https://psgroup.in/assets/img/project-details/healthcare.svg"
                                    alt="Health care icon" />
                                <p class="our-places__info">Healthcare</p>
                            </li>
                            <li class="our-places__list col-xs-6" id="Education">
                                <input class="with-gap" id="education" name="place_type" type="radio" value="education"
                                    style="display: inline;"><img class="loc-img"
                                    src="https://psgroup.in/assets/img/project-details/education.svg" alt="Education" />
                                <p class="our-places__info">Education</p>
                            </li>
                            <li class="our-places__list col-xs-6" id="Restaurants">
                                <input class="with-gap" id="restaurants" name="place_type" type="radio"
                                    value="restaurants" style="display: inline;"><img class="loc-img"
                                    src="https://psgroup.in/assets/img/project-details/resto.svg" alt="Education" />
                                <p class="our-places__info">Leisure</p>
                            </li>
                            <li class="our-places__list col-xs-6" id="Metro">
                                <input class="with-gap" id="metro" name="place_type" type="radio" value="metro"
                                    style="display: inline;"><img class="loc-img"
                                    src="https://psgroup.in/assets/img/project-details/metro.svg" alt="metro icon" />
                                <p class="our-places__info">Commute</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--START: Slider-->
    <section id="p-enquiry" class="newsletter-wrapper bg-blue-layout scrollto p-enquiryForm">
        <div class="blue-pattern"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <form data-toggle="validator" action="" method="post" enctype="multipart/form-data"
                        class="content-wrapper enqForm enqForms" id="sansara-form" novalidate="true">
                        <input id="e-first-name" name="project_title" value="Sansara" type="hidden">
                        <input id="e-first-name" name="pid" value="2324" type="hidden">
                        <h2 class="form-title pa-L">Interested in enquiring about
                            Sansara?</h2>
                        <input id="page_url" name="page_url" value="https://psgroup.in/sansara" type="hidden">
                        <div class="row">
                            <div class="col-sm-6 paddin0">
                                <div class="form-group"><span class="input input--sae">
                                        <input type="email" name="honeypot_field" class="honeypot_field"
                                            id="honeypot_field" style="display:none">

                                        <input id="e-first-name" name="full_name" type="text"
                                            data-required-error="This field is required" pattern="^[A-Za-z\s]*$"
                                            required="required" class="input__field input__field--sae"
                                            placeholder="Name">
                                    </span>
                                    <div class="help-block with-errors margin15 text-orange"> </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group"><span class="input input--sae">
                                        <input id="e-email-address" type="email" name="email"
                                            pattern="^[a-zA-Z0-9.!#$%&amp;�*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:.[a-zA-Z0-9-]+)*$"
                                            data-error="Please enter a valid email address"
                                            data-required-error="This field is required"
                                            data-patten-error="Sorry! That's not corret email" required="required"
                                            class="input__field input__field--sae" placeholder="Email address">
                                    </span>
                                    <div class="help-block with-errors margin15 text-orange"> </div>
                                </div>
                            </div>
                        </div>
                        <div class="row india">
                            <div class="col-sm-6 paddin0">
                                <div style="margin: 0;padding: 2.0em 0em .5em 0;" class="form-group"><span
                                        class="input input--sae">
                                        <div class="project-enquery-info panel__sticky">

                                            <select id="property" data-error="select country" required="required"
                                                class="select-area p-23 select2-hidden-accessible" name="country_Code"
                                                style="background-color: transparent !important;border-bottom: 1px solid #fff;border-top: none;border-left: none;border-right: none;"
                                                tabindex="-1" aria-hidden="true">
                                                <option value="" data-code="" data-dial="">Select Country</option>
                                                <option value="+91" data-code="IN" data-dial="+91">India(+91)</option>
                                                <option value="+1" data-code="US" data-dial="+1">United States(+1)
                                                </option>
                                                <option value="+966" data-code="SA" data-dial="+966">Saudi Arabia(+966)
                                                </option>
                                                <option value="+971" data-code="AE" data-dial="+971">United Arab
                                                    Emirates(+971)</option>
                                                <option value="+65" data-code="SG" data-dial="+65">Singapore(+65)
                                                </option>
                                                <option value="+965" data-code="KW" data-dial="+965">Kuwait(+965)
                                                </option>
                                                <option value="+44" data-code="GB" data-dial="+44">United Kingdom(+44)
                                                </option>
                                                <option value="+1" data-code="CA" data-dial="+1">Canada(+1)</option>
                                                <option value="+974" data-code="QA" data-dial="+974">Qatar(+974)
                                                </option>
                                                <option value="+61" data-code="AU" data-dial="+61">Australia(+61)
                                                </option>
                                                <option value="+968" data-code="OM" data-dial="+968">Oman(+968)</option>
                                                <option disabled="disabled" value="-1">-----------</option>
                                                <option value="+93" data-code="AF" data-dial="+93">Afghanistan(+93)
                                                </option>
                                                <option value="+355" data-code="AL" data-dial="+355">Albania(+355)
                                                </option>
                                                <option value="+213" data-code="DZ" data-dial="+213">Algeria(+213)
                                                </option>
                                                <option value="+1684" data-code="AS" data-dial="+1684">
                                                    AmericanSamoa(+1684)</option>
                                                <option value="+376" data-code="AD" data-dial="+376">Andorra(+376)
                                                </option>
                                                <option value="+244" data-code="AO" data-dial="+244">Angola(+244)
                                                </option>
                                                <option value="+1264" data-code="AI" data-dial="+1264">Anguilla(+1264)
                                                </option>
                                                <option value="+1268" data-code="AG" data-dial="+1268">Antigua and
                                                    Barbuda(+1268)</option>
                                                <option value="+672" data-code="AQ" data-dial="+672">Antarctica(+672)
                                                </option>
                                                <option value="+54" data-code="AR" data-dial="+54">Argentina(+54)
                                                </option>
                                                <option value="+374" data-code="AM" data-dial="+374">Armenia(+374)
                                                </option>
                                                <option value="+297" data-code="AW" data-dial="+297">Aruba(+297)
                                                </option>
                                                <option value="+43" data-code="AT" data-dial="+43">Austria(+43)</option>
                                                <option value="+994" data-code="AZ" data-dial="+994">Azerbaijan(+994)
                                                </option>
                                                <option value="+1242" data-code="BS" data-dial="+1242">Bahamas(+1242)
                                                </option>
                                                <option value="+973" data-code="BH" data-dial="+973">Bahrain(+973)
                                                </option>
                                                <option value="+880" data-code="BD" data-dial="+880">Bangladesh(+880)
                                                </option>
                                                <option value="+1246" data-code="BB" data-dial="+1246">Barbados(+1246)
                                                </option>
                                                <option value="+375" data-code="BY" data-dial="+375">Belarus(+375)
                                                </option>
                                                <option value="+32" data-code="BE" data-dial="+32">Belgium(+32)</option>
                                                <option value="+501" data-code="BZ" data-dial="+501">Belize(+501)
                                                </option>
                                                <option value="+229" data-code="BJ" data-dial="+229">Benin(+229)
                                                </option>
                                                <option value="+1441" data-code="BM" data-dial="+1441">Bermuda(+1441)
                                                </option>
                                                <option value="+975" data-code="BT" data-dial="+975">Bhutan(+975)
                                                </option>
                                                <option value="+591" data-code="BO" data-dial="+591">Bolivia,
                                                    Plurinational State of(+591)
                                                </option>
                                                <option value="+387" data-code="BA" data-dial="+387">Bosnia and
                                                    Herzegovina(+387)</option>
                                                <option value="+267" data-code="BW" data-dial="+267">Botswana(+267)
                                                </option>
                                                <option value="+55" data-code="BR" data-dial="+55">Brazil(+55)</option>
                                                <option value="+246" data-code="IO" data-dial="+246">British Indian
                                                    Ocean Territory(+246)
                                                </option>
                                                <option value="+673" data-code="BN" data-dial="+673">Brunei
                                                    Darussalam(+673)</option>
                                                <option value="+359" data-code="BG" data-dial="+359">Bulgaria(+359)
                                                </option>
                                                <option value="+226" data-code="BF" data-dial="+226">Burkina Faso(+226)
                                                </option>
                                                <option value="+257" data-code="BI" data-dial="+257">Burundi(+257)
                                                </option>
                                                <option value="+855" data-code="KH" data-dial="+855">Cambodia(+855)
                                                </option>
                                                <option value="+237" data-code="CM" data-dial="+237">Cameroon(+237)
                                                </option>
                                                <option value="+238" data-code="CV" data-dial="+238">Cape Verde(+238)
                                                </option>
                                                <option value="+345" data-code="KY" data-dial="+345">Cayman
                                                    Islands(+345)</option>
                                                <option value="+236" data-code="CF" data-dial="+236">Central African
                                                    Republic(+236)</option>
                                                <option value="+235" data-code="TD" data-dial="+235">Chad(+235)</option>
                                                <option value="+56" data-code="CL" data-dial="+56">Chile(+56)</option>
                                                <option value="+86" data-code="CN" data-dial="+86">China(+86)</option>
                                                <option value="+61" data-code="CX" data-dial="+61">Christmas Island(+61)
                                                </option>
                                                <option value="+61" data-code="CC" data-dial="+61">Cocos (Keeling)
                                                    Islands(+61)</option>
                                                <option value="+57" data-code="CO" data-dial="+57">Colombia(+57)
                                                </option>
                                                <option value="+269" data-code="KM" data-dial="+269">Comoros(+269)
                                                </option>
                                                <option value="+242" data-code="CG" data-dial="+242">Congo(+242)
                                                </option>
                                                <option value="+243" data-code="CD" data-dial="+243">Congo, The
                                                    Democratic Republic of
                                                    the(+243)</option>
                                                <option value="+682" data-code="CK" data-dial="+682">Cook Islands(+682)
                                                </option>
                                                <option value="+506" data-code="CR" data-dial="+506">Costa Rica(+506)
                                                </option>
                                                <option value="+225" data-code="CI" data-dial="+225">Cote d'Ivoire(+225)
                                                </option>
                                                <option value="+385" data-code="HR" data-dial="+385">Croatia(+385)
                                                </option>
                                                <option value="+53" data-code="CU" data-dial="+53">Cuba(+53)</option>
                                                <option value="+537" data-code="CY" data-dial="+537">Cyprus(+537)
                                                </option>
                                                <option value="+420" data-code="CZ" data-dial="+420">Czech
                                                    Republic(+420)</option>
                                                <option value="+45" data-code="DK" data-dial="+45">Denmark(+45)</option>
                                                <option value="+253" data-code="DJ" data-dial="+253">Djibouti(+253)
                                                </option>
                                                <option value="+1767" data-code="DM" data-dial="+1767">Dominica(+1767)
                                                </option>
                                                <option value="+1849" data-code="DO" data-dial="+1849">Dominican
                                                    Republic(+1849)</option>
                                                <option value="+593" data-code="EC" data-dial="+593">Ecuador(+593)
                                                </option>
                                                <option value="+20" data-code="EG" data-dial="+20">Egypt(+20)</option>
                                                <option value="+503" data-code="SV" data-dial="+503">El Salvador(+503)
                                                </option>
                                                <option value="+240" data-code="GQ" data-dial="+240">Equatorial
                                                    Guinea(+240)</option>
                                                <option value="+291" data-code="ER" data-dial="+291">Eritrea(+291)
                                                </option>
                                                <option value="+372" data-code="EE" data-dial="+372">Estonia(+372)
                                                </option>
                                                <option value="+251" data-code="ET" data-dial="+251">Ethiopia(+251)
                                                </option>
                                                <option value="+298" data-code="FO" data-dial="+298">Faroe Islands(+298)
                                                </option>
                                                <option value="+500" data-code="FK" data-dial="+500">Falkland Islands
                                                    (Malvinas)(+500)
                                                </option>
                                                <option value="+679" data-code="FJ" data-dial="+679">Fiji(+679)</option>
                                                <option value="+358" data-code="FI" data-dial="+358">Finland(+358)
                                                </option>
                                                <option value="+33" data-code="FR" data-dial="+33">France(+33)</option>
                                                <option value="+594" data-code="GF" data-dial="+594">French Guiana(+594)
                                                </option>
                                                <option value="+689" data-code="PF" data-dial="+689">French
                                                    Polynesia(+689)</option>
                                                <option value="+241" data-code="GA" data-dial="+241">Gabon(+241)
                                                </option>
                                                <option value="+220" data-code="GM" data-dial="+220">Gambia(+220)
                                                </option>
                                                <option value="+995" data-code="GE" data-dial="+995">Georgia(+995)
                                                </option>
                                                <option value="+49" data-code="DE" data-dial="+49">Germany(+49)</option>
                                                <option value="+233" data-code="GH" data-dial="+233">Ghana(+233)
                                                </option>
                                                <option value="+350" data-code="GI" data-dial="+350">Gibraltar(+350)
                                                </option>
                                                <option value="+30" data-code="GR" data-dial="+30">Greece(+30)</option>
                                                <option value="+299" data-code="GL" data-dial="+299">Greenland(+299)
                                                </option>
                                                <option value="+1473" data-code="GD" data-dial="+1473">Grenada(+1473)
                                                </option>
                                                <option value="+590" data-code="GP" data-dial="+590">Guadeloupe(+590)
                                                </option>
                                                <option value="+1671" data-code="GU" data-dial="+1671">Guam(+1671)
                                                </option>
                                                <option value="+502" data-code="GT" data-dial="+502">Guatemala(+502)
                                                </option>
                                                <option value="+44" data-code="GG" data-dial="+44">Guernsey(+44)
                                                </option>
                                                <option value="+224" data-code="GN" data-dial="+224">Guinea(+224)
                                                </option>
                                                <option value="+245" data-code="GW" data-dial="+245">Guinea-Bissau(+245)
                                                </option>
                                                <option value="+595" data-code="GY" data-dial="+595">Guyana(+595)
                                                </option>
                                                <option value="+509" data-code="HT" data-dial="+509">Haiti(+509)
                                                </option>
                                                <option value="+504" data-code="HN" data-dial="+504">Honduras(+504)
                                                </option>
                                                <option value="+379" data-code="VA" data-dial="+379">Holy See (Vatican
                                                    City State)(+379)
                                                </option>
                                                <option value="+852" data-code="HK" data-dial="+852">Hong Kong(+852)
                                                </option>
                                                <option value="+36" data-code="HU" data-dial="+36">Hungary(+36)</option>
                                                <option value="+354" data-code="IS" data-dial="+354">Iceland(+354)
                                                </option>
                                                <option value="+91" data-code="IN" data-dial="+91">India(+91)</option>
                                                <option value="+62" data-code="ID" data-dial="+62">Indonesia(+62)
                                                </option>
                                                <option value="+964" data-code="IQ" data-dial="+964">Iraq(+964)</option>
                                                <option value="+98" data-code="IR" data-dial="+98">Iran, Islamic
                                                    Republic of(+98)</option>
                                                <option value="+353" data-code="IE" data-dial="+353">Ireland(+353)
                                                </option>
                                                <option value="+972" data-code="IL" data-dial="+972">Israel(+972)
                                                </option>
                                                <option value="+44" data-code="IM" data-dial="+44">Isle of Man(+44)
                                                </option>
                                                <option value="+39" data-code="IT" data-dial="+39">Italy(+39)</option>
                                                <option value="+1876" data-code="JM" data-dial="+1876">Jamaica(+1876)
                                                </option>
                                                <option value="+81" data-code="JP" data-dial="+81">Japan(+81)</option>
                                                <option value="+44" data-code="JE" data-dial="+44">Jersey(+44)</option>
                                                <option value="+962" data-code="JO" data-dial="+962">Jordan(+962)
                                                </option>
                                                <option value="+77" data-code="KZ" data-dial="+77">Kazakhstan(+77)
                                                </option>
                                                <option value="+254" data-code="KE" data-dial="+254">Kenya(+254)
                                                </option>
                                                <option value="+686" data-code="KI" data-dial="+686">Kiribati(+686)
                                                </option>
                                                <option value="+850" data-code="KP" data-dial="+850">Korea, Democratic
                                                    People's Republic
                                                    of(+850)</option>
                                                <option value="+82" data-code="KR" data-dial="+82">Korea, Republic
                                                    of(+82)</option>
                                                <option value="+996" data-code="KG" data-dial="+996">Kyrgyzstan(+996)
                                                </option>
                                                <option value="+500" data-code="AX" data-dial="+500">land Islands(+500)
                                                </option>
                                                <option value="+856" data-code="LA" data-dial="+856">Lao People's
                                                    Democratic Republic(+856)
                                                </option>
                                                <option value="+371" data-code="LV" data-dial="+371">Latvia(+371)
                                                </option>
                                                <option value="+961" data-code="LB" data-dial="+961">Lebanon(+961)
                                                </option>
                                                <option value="+266" data-code="LS" data-dial="+266">Lesotho(+266)
                                                </option>
                                                <option value="+231" data-code="LR" data-dial="+231">Liberia(+231)
                                                </option>
                                                <option value="+218" data-code="LY" data-dial="+218">Libyan Arab
                                                    Jamahiriya(+218)</option>
                                                <option value="+423" data-code="LI" data-dial="+423">Liechtenstein(+423)
                                                </option>
                                                <option value="+370" data-code="LT" data-dial="+370">Lithuania(+370)
                                                </option>
                                                <option value="+352" data-code="LU" data-dial="+352">Luxembourg(+352)
                                                </option>
                                                <option value="+853" data-code="MO" data-dial="+853">Macao(+853)
                                                </option>
                                                <option value="+389" data-code="MK" data-dial="+389">Macedonia, The
                                                    Former Yugoslav Republic
                                                    of(+389)</option>
                                                <option value="+261" data-code="MG" data-dial="+261">Madagascar(+261)
                                                </option>
                                                <option value="+265" data-code="MW" data-dial="+265">Malawi(+265)
                                                </option>
                                                <option value="+60" data-code="MY" data-dial="+60">Malaysia(+60)
                                                </option>
                                                <option value="+960" data-code="MV" data-dial="+960">Maldives(+960)
                                                </option>
                                                <option value="+223" data-code="ML" data-dial="+223">Mali(+223)</option>
                                                <option value="+356" data-code="MT" data-dial="+356">Malta(+356)
                                                </option>
                                                <option value="+692" data-code="MH" data-dial="+692">Marshall
                                                    Islands(+692)</option>
                                                <option value="+596" data-code="MQ" data-dial="+596">Martinique(+596)
                                                </option>
                                                <option value="+222" data-code="MR" data-dial="+222">Mauritania(+222)
                                                </option>
                                                <option value="+230" data-code="MU" data-dial="+230">Mauritius(+230)
                                                </option>
                                                <option value="+262" data-code="YT" data-dial="+262">Mayotte(+262)
                                                </option>
                                                <option value="+52" data-code="MX" data-dial="+52">Mexico(+52)</option>
                                                <option value="+691" data-code="FM" data-dial="+691">Micronesia,
                                                    Federated States of(+691)
                                                </option>
                                                <option value="+373" data-code="MD" data-dial="+373">Moldova, Republic
                                                    of(+373)</option>
                                                <option value="+377" data-code="MC" data-dial="+377">Monaco(+377)
                                                </option>
                                                <option value="+976" data-code="MN" data-dial="+976">Mongolia(+976)
                                                </option>
                                                <option value="+382" data-code="ME" data-dial="+382">Montenegro(+382)
                                                </option>
                                                <option value="+1664" data-code="MS" data-dial="+1664">Montserrat(+1664)
                                                </option>
                                                <option value="+212" data-code="MA" data-dial="+212">Morocco(+212)
                                                </option>
                                                <option value="+258" data-code="MZ" data-dial="+258">Mozambique(+258)
                                                </option>
                                                <option value="+95" data-code="MM" data-dial="+95">Myanmar(+95)</option>
                                                <option value="+264" data-code="NA" data-dial="+264">Namibia(+264)
                                                </option>
                                                <option value="+674" data-code="NR" data-dial="+674">Nauru(+674)
                                                </option>
                                                <option value="+977" data-code="NP" data-dial="+977">Nepal(+977)
                                                </option>
                                                <option value="+31" data-code="NL" data-dial="+31">Netherlands(+31)
                                                </option>
                                                <option value="+599" data-code="AN" data-dial="+599">Netherlands
                                                    Antilles(+599)</option>
                                                <option value="+687" data-code="NC" data-dial="+687">New Caledonia(+687)
                                                </option>
                                                <option value="+64" data-code="NZ" data-dial="+64">New Zealand(+64)
                                                </option>
                                                <option value="+505" data-code="NI" data-dial="+505">Nicaragua(+505)
                                                </option>
                                                <option value="+227" data-code="NE" data-dial="+227">Niger(+227)
                                                </option>
                                                <option value="+234" data-code="NG" data-dial="+234">Nigeria(+234)
                                                </option>
                                                <option value="+683" data-code="NU" data-dial="+683">Niue(+683)</option>
                                                <option value="+672" data-code="NF" data-dial="+672">Norfolk
                                                    Island(+672)</option>
                                                <option value="+1670" data-code="MP" data-dial="+1670">Northern Mariana
                                                    Islands(+1670)
                                                </option>
                                                <option value="+47" data-code="NO" data-dial="+47">Norway(+47)</option>
                                                <option value="+92" data-code="PK" data-dial="+92">Pakistan(+92)
                                                </option>
                                                <option value="+680" data-code="PW" data-dial="+680">Palau(+680)
                                                </option>
                                                <option value="+970" data-code="PS" data-dial="+970">Palestinian
                                                    Territory, Occupied(+970)
                                                </option>
                                                <option value="+507" data-code="PA" data-dial="+507">Panama(+507)
                                                </option>
                                                <option value="+675" data-code="PG" data-dial="+675">Papua New
                                                    Guinea(+675)</option>
                                                <option value="+595" data-code="PY" data-dial="+595">Paraguay(+595)
                                                </option>
                                                <option value="+51" data-code="PE" data-dial="+51">Peru(+51)</option>
                                                <option value="+63" data-code="PH" data-dial="+63">Philippines(+63)
                                                </option>
                                                <option value="+872" data-code="PN" data-dial="+872">Pitcairn(+872)
                                                </option>
                                                <option value="+48" data-code="PL" data-dial="+48">Poland(+48)</option>
                                                <option value="+351" data-code="PT" data-dial="+351">Portugal(+351)
                                                </option>
                                                <option value="+1939" data-code="PR" data-dial="+1939">Puerto
                                                    Rico(+1939)</option>
                                                <option value="+262" data-code="RE" data-dial="+262">R�union(+262)
                                                </option>
                                                <option value="+40" data-code="RO" data-dial="+40">Romania(+40)</option>
                                                <option value="+7" data-code="RU" data-dial="+7">Russia(+7)</option>
                                                <option value="+250" data-code="RW" data-dial="+250">Rwanda(+250)
                                                </option>
                                                <option value="+590" data-code="BL" data-dial="+590">Saint
                                                    Barth�lemy(+590)</option>
                                                <option value="+290" data-code="SH" data-dial="+290">Saint Helena,
                                                    Ascension and Tristan Da
                                                    Cunha(+290)</option>
                                                <option value="+1869" data-code="KN" data-dial="+1869">Saint Kitts and
                                                    Nevis(+1869)</option>
                                                <option value="+1758" data-code="LC" data-dial="+1758">Saint
                                                    Lucia(+1758)</option>
                                                <option value="+590" data-code="MF" data-dial="+590">Saint Martin(+590)
                                                </option>
                                                <option value="+508" data-code="PM" data-dial="+508">Saint Pierre and
                                                    Miquelon(+508)</option>
                                                <option value="+1784" data-code="VC" data-dial="+1784">Saint Vincent and
                                                    the Grenadines(+1784)
                                                </option>
                                                <option value="+685" data-code="WS" data-dial="+685">Samoa(+685)
                                                </option>
                                                <option value="+378" data-code="SM" data-dial="+378">San Marino(+378)
                                                </option>
                                                <option value="+239" data-code="ST" data-dial="+239">Sao Tome and
                                                    Principe(+239)</option>
                                                <option value="+966" data-code="SA" data-dial="+966">Saudi Arabia(+966)
                                                </option>
                                                <option value="+221" data-code="SN" data-dial="+221">Senegal(+221)
                                                </option>
                                                <option value="+381" data-code="RS" data-dial="+381">Serbia(+381)
                                                </option>
                                                <option value="+248" data-code="SC" data-dial="+248">Seychelles(+248)
                                                </option>
                                                <option value="+232" data-code="SL" data-dial="+232">Sierra Leone(+232)
                                                </option>
                                                <option value="+421" data-code="SK" data-dial="+421">Slovakia(+421)
                                                </option>
                                                <option value="+386" data-code="SI" data-dial="+386">Slovenia(+386)
                                                </option>
                                                <option value="+677" data-code="SB" data-dial="+677">Solomon
                                                    Islands(+677)</option>
                                                <option value="+252" data-code="SO" data-dial="+252">Somalia(+252)
                                                </option>
                                                <option value="+27" data-code="ZA" data-dial="+27">South Africa(+27)
                                                </option>
                                                <option value="+500" data-code="GS" data-dial="+500">South Georgia and
                                                    the South Sandwich
                                                    Islands(+500)</option>
                                                <option value="+34" data-code="ES" data-dial="+34">Spain(+34)</option>
                                                <option value="+94" data-code="LK" data-dial="+94">Sri Lanka(+94)
                                                </option>
                                                <option value="+249" data-code="SD" data-dial="+249">Sudan(+249)
                                                </option>
                                                <option value="+597" data-code="SR" data-dial="+597">Suriname(+597)
                                                </option>
                                                <option value="+47" data-code="SJ" data-dial="+47">Svalbard and Jan
                                                    Mayen(+47)</option>
                                                <option value="+268" data-code="SZ" data-dial="+268">Swaziland(+268)
                                                </option>
                                                <option value="+46" data-code="SE" data-dial="+46">Sweden(+46)</option>
                                                <option value="+41" data-code="CH" data-dial="+41">Switzerland(+41)
                                                </option>
                                                <option value="+963" data-code="SY" data-dial="+963">Syrian Arab
                                                    Republic(+963)</option>
                                                <option value="+886" data-code="TW" data-dial="+886">Taiwan, Province of
                                                    China(+886)</option>
                                                <option value="+992" data-code="TJ" data-dial="+992">Tajikistan(+992)
                                                </option>
                                                <option value="+255" data-code="TZ" data-dial="+255">Tanzania, United
                                                    Republic of(+255)
                                                </option>
                                                <option value="+66" data-code="TH" data-dial="+66">Thailand(+66)
                                                </option>
                                                <option value="+670" data-code="TL" data-dial="+670">Timor-Leste(+670)
                                                </option>
                                                <option value="+228" data-code="TG" data-dial="+228">Togo(+228)</option>
                                                <option value="+690" data-code="TK" data-dial="+690">Tokelau(+690)
                                                </option>
                                                <option value="+676" data-code="TO" data-dial="+676">Tonga(+676)
                                                </option>
                                                <option value="+1868" data-code="TT" data-dial="+1868">Trinidad and
                                                    Tobago(+1868)</option>
                                                <option value="+216" data-code="TN" data-dial="+216">Tunisia(+216)
                                                </option>
                                                <option value="+90" data-code="TR" data-dial="+90">Turkey(+90)</option>
                                                <option value="+993" data-code="TM" data-dial="+993">Turkmenistan(+993)
                                                </option>
                                                <option value="+1649" data-code="TC" data-dial="+1649">Turks and Caicos
                                                    Islands(+1649)
                                                </option>
                                                <option value="+688" data-code="TV" data-dial="+688">Tuvalu(+688)
                                                </option>
                                                <option value="+256" data-code="UG" data-dial="+256">Uganda(+256)
                                                </option>
                                                <option value="+380" data-code="UA" data-dial="+380">Ukraine(+380)
                                                </option>
                                                <option value="+971" data-code="AE" data-dial="+971">United Arab
                                                    Emirates(+971)</option>
                                                <option value="+44" data-code="GB" data-dial="+44">United Kingdom(+44)
                                                </option>
                                                <option value="+1" data-code="US" data-dial="+1">United States(+1)
                                                </option>
                                                <option value="+598" data-code="UY" data-dial="+598">Uruguay(+598)
                                                </option>
                                                <option value="+998" data-code="UZ" data-dial="+998">Uzbekistan(+998)
                                                </option>
                                                <option value="+678" data-code="VU" data-dial="+678">Vanuatu(+678)
                                                </option>
                                                <option value="+58" data-code="VE" data-dial="+58">Venezuela, Bolivarian
                                                    Republic of(+58)
                                                </option>
                                                <option value="+84" data-code="VN" data-dial="+84">Viet Nam(+84)
                                                </option>
                                                <option value="+1284" data-code="VG" data-dial="+1284">Virgin Islands,
                                                    British(+1284)</option>
                                                <option value="+1340" data-code="VI" data-dial="+1340">Virgin Islands,
                                                    U.S.(+1340)</option>
                                                <option value="+681" data-code="WF" data-dial="+681">Wallis and
                                                    Futuna(+681)</option>
                                                <option value="+967" data-code="YE" data-dial="+967">Yemen(+967)
                                                </option>
                                                <option value="+260" data-code="ZM" data-dial="+260">Zambia(+260)
                                                </option>
                                                <option value="+263" data-code="ZW" data-dial="+263">Zimbabwe(+263)
                                                </option>
                                            </select>
                                        </div>
                                </div>
                            </div>
                            <div class="col-sm-6 paddin0">
                                <div class="form-group"><span class="input input--sae">
                                        <!-- onkeyup="project_sendOTP(event)" -->
                                        <input autocomplete="off" id="e-phone-number" type="number" name="phone_no"
                                            placeholder="Phone number" maxlength="10" pattern="" data-minlength="10"
                                            data-maxlength="14" data-error="Enter a valid phone number"
                                            required="required" class="input__field input__field--sae">
                                    </span>
                                    <div class="help-block with-errors margin15 text-orange"
                                        id="project_status_message"> </div>
                                </div>
                            </div>

                            <!-- <div class="col-sm-6" id="project_resend_div" style="display: none">
                                <div class="form-group">

                                    <a href="javascript:void(0)" onclick="project_resendOTP()" class="cbdle"
                                        style="background-color: #fff;color: #22438a;font-size: 10px;margin: 52px 0 0 0;border: none;padding: 3px 10px;">Resend
                                        OTP</a>
                                </div>
                            </div> -->
                        </div>

                        <div class="row">
                            <div class="col-sm-6 paddin0">
                                <div style="margin: 0;padding: 2.0em 0em .5em 0;" class="form-group"><span
                                        class="input input--sae">
                                        <div class="project-enquery-info panel__sticky">

                                            <select id="property-area"
                                                class="select-area p-23 select2-hidden-accessible"
                                                onchange="getBudget(2324,this.value);" name="projecttype"
                                                style="background-color: transparent !important;border-bottom: 1px solid #fff;border-top: none;border-left: none;border-right: none;"
                                                tabindex="-1" aria-hidden="true">
                                                <option value="BHK">Select Unit Type</option>
                                                <option value="3BHK">3BHK</option>
                                                <option value="4BHK">4BHK</option>
                                                <option value="4.5BHK">4.5BHK</option>
                                                <option value="5BHK Duplex">5BHK Duplex</option>

                                            </select>
                                        </div>
                                </div>
                            </div>
                            <div class="col-sm-6 ">
                                <div style="margin: 0;padding: 2.0em 0em .5em 0;" class="form-group"><span
                                        class="input input--sae">
                                        <div class="project-enquery-info panel__sticky">
                                            <!--  style="background-color: transparent !important;border-bottom: 1px solid #fff;border-top: none;border-left: none;border-right: none;" -->
                                            <select id="area" class="select-area p-23 select2-hidden-accessible"
                                                name="budget" tabindex="-1" aria-hidden="true">
                                                <option value="">Select Budget</option>

                                                <option value="Rs. 3.11 Cr - 3.50 Cr">Rs. 3.11 Cr - 3.50 Cr</option>
                                                <option value="Rs. 3.96 Cr - 4.35 Cr">Rs. 3.96 Cr - 4.35 Cr</option>
                                                <option value="Rs. 4.08 Cr - 4.49 Cr">Rs. 4.08 Cr - 4.49 Cr</option>
                                                <option value="Rs. 6.17 Cr - 6.38 Cr">Rs. 6.17 Cr - 6.38 Cr</option>

                                            </select>
                                        </div>
                                </div>
                            </div>
                            <div class="col-sm-12 checksss "
                                style=" align-items: start; display:flex; margin-top: 1em;">
                                <input type="checkbox" class="" name="chkbox" value="1" checked id="exampleCheckbox"
                                    style="margin: 3px; padding: 0;" required="required" />
                                <label for="exampleCheckbox" style="margin-left: 8px;">
                                    I agree that by clicking on 'Submit,' I am explicitly soliciting a call or message
                                    from 'PS Group' or its associates on my mobile number to assist me. I also agree to
                                    the
                                    <a href="https://psgroup.in/terms-of-use"
                                        style="text-decoration: underline;text-decoration-color: white;color: white;">Terms
                                        &amp; Conditions</a> and
                                    <a href="https://psgroup.in/privacy-policy"
                                        style="text-decoration: underline;text-decoration-color: white;color: white;">Privacy
                                        Policy</a>.
                                </label>
                            </div>



                        </div>
                        <div class="row marg0 pa-L">
                            <div i="" agree="" to="" ps="" groupclass="form-group"><span id="message_status"
                                    style="color: green"></span>
                                <button type="submit" name="submit" id="wait"
                                    class="btn btn--default button--submit btn--submitEnq">submit</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-lg-5">
                    <div class="newsletter__footer">
                        <div class=" footer__contact">
                            <div class="text-bg__inner"><img src="assets/img/contact-img1.png" alt=""></span>
                                <p class="footer__contact-info"> Poddar Court, 18 Rabindra sarani,5th Floor ,Office No -
                                    527 Kolkata :700001, West Bengal, India </p>
                            </div>

                            <div class=" footer__contact">
                                <div class="text-bg__inner"><img src="assets/img/contact-img3.png" alt=""></span>
                                    <a class="footer__contact-info" href="mailto: sales@psgroup.in">sales@psgroup.in</a>
                                </div>
                                <div class="footer__contact">


                                    <div class="text-bg__inner"><span><img src="assets/img/contact-img1.png"
                                                alt=""></span>

                                        <a class="footer__contact-info" href="tel:+9103367676785">+91 033 6767 6785</a>

                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
    </section>
    <footer class="dark-footer skin-dark-footer"
        style="background: var(--primary-color);border-top: 1px solid var(--primary-color);">
        <div class="footer-overlay"></div>
        <div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-12 text-center">
                        <div class="footer-widget">
                            <img src="assets/img/logo-header.png" class="img-footer" alt="">
                            <div class="footer-add">
                                <p><i class="fa fa-map-marker" aria-hidden="true" style="padding-right: 7px;"></i>
                                    Poddar
                                    Court, 18 Rabindra sarani,5th Floor ,Office No - 527 Kolkata :700001, West Bengal,
                                    India
                                </p>
                                <p><a href="tel:+918420994555"><i class="fa fa-phone" aria-hidden="true"
                                            style="padding-right: 7px;"></i> +91 8420994555</a></p>
                                <p><a href="mailto:enquiry@renitzproperties.com"><i class="fa fa-envelope"
                                            aria-hidden="true" style="padding-right: 7px;"></i>
                                        enquiry@renitzproperties.com</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 text-center">
                        <div class="footer-widget">
                            <h4 class="widget-title pt-lg-3 pt-sm-1">Quick Links</h4>
                            <ul class="footer-menu">
                                <li><a href="about.php">About Us</a></li>

                                <li><a href="residential-apartment.php">Find Properties</a></li>

                                <li><a href="event.php">Events</a></li>
                                <li><a href="luxurious.php">Luxurious Property</a></li>
                                <li><a href="contact-us.php">Contact Us</a></li>



                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-12 text-center">
                        <div class="footer-widget">
                            <h4 class="widget-title pt-lg-3 pt-sm-1">Useful Links</h4>
                            <ul class="footer-menu">
                                <li><a href="residential-apartment.php">Residential Apartment</a></li>
                                <li><a href="luxurious.php">Luxury Apartment</a></li>
                                <li><a href="resale.php">Resale Property</a></li>
                                <li><a href="sell-property.php">Sell Property</a></li>

                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="footer-bottom" style="background-color: #ffffff;">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12 col-md-12">
                        <p class="mb-0">© 2025 <a class="bottom-footer-link" href="index.php">RENITZ
                                PROPERTIES</a> All Rights Reserved.

                    </div>
                </div>
            </div>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <!-- <script src="assets/js/bootstrap.min.js"></script> -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js?ver=3.5.7"
        id="fancybox-js-js"></script>

    <script src="assets/js/rangeslider.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/lightbox.js"></script>
    <script src="assets/js/imagesloaded.js"></script>
    <script src="assets/js/dropzone.js"></script>
    <script src="assets/js/datedropper-javascript.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/custom2.js"></script>
    <!--Popup Comming Start-->
    <script src="assets/js/cust-popup.js"></script>
    <script>
        document.getElementById("sansara-form").addEventListener("submit", function (e) {
            const checkbox = document.getElementById("exampleCheckbox");

            if (!checkbox.checked) {
                alert("You must agree to the terms before submitting.");
                e.preventDefault(); // Prevent form submission
            }
        });
    </script>
    <script>
        var swiper = new Swiper(".gallery-slider-container", {
            slidesPerView: 1,
            loop: true,
            spaceBetween: 20,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false
            },
            pagination: {
                el: ".swiper-pagination",
                clickable: true
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev"
            }
        });
    </script>
    <script>

        $(window).on('scroll', function () {
            if ($(this).scrollTop() > 0) {
                $(".pssansara__header").addClass("fixed-top");

            }
        });
    </script>

    <script>
        // Get all elements
        const primaryTabs = document.querySelectorAll('.primary-tab');
        const childTabsContainers = document.querySelectorAll('.child-tabs');
        const childTabs = document.querySelectorAll('.child-tab');
        const unitContents = document.querySelectorAll('.unit-content');

        // Handle primary tab clicks
        primaryTabs.forEach(tab => {
            tab.addEventListener('click', function () {
                const primaryType = this.dataset.primary;

                // Remove active class from all primary tabs
                primaryTabs.forEach(t => t.classList.remove('active'));
                // Add active class to clicked tab
                this.classList.add('active');

                // Hide all child tabs containers
                childTabsContainers.forEach(container => {
                    container.classList.remove('active');
                });

                // Show the corresponding child tabs container
                const targetChildTabs = document.querySelector(`[data-parent="${primaryType}"]`);
                if (targetChildTabs) {
                    targetChildTabs.classList.add('active');

                    // Activate the first child tab
                    const firstChildTab = targetChildTabs.querySelector('.child-tab');
                    if (firstChildTab) {
                        // Remove active from all child tabs
                        childTabs.forEach(ct => ct.classList.remove('active'));
                        // Activate first child tab
                        firstChildTab.classList.add('active');

                        // Show corresponding content
                        const unitType = firstChildTab.dataset.unit;
                        showUnitContent(unitType);
                    }
                }
            });
        });

        // Handle child tab clicks
        childTabs.forEach(tab => {
            tab.addEventListener('click', function () {
                const unitType = this.dataset.unit;
                const parentContainer = this.closest('.child-tabs');

                // Remove active from sibling child tabs
                const siblingTabs = parentContainer.querySelectorAll('.child-tab');
                siblingTabs.forEach(t => t.classList.remove('active'));

                // Add active to clicked child tab
                this.classList.add('active');

                // Show corresponding content
                showUnitContent(unitType);
            });
        });

        // Function to show unit content
        function showUnitContent(unitType) {
            // Hide all unit contents
            unitContents.forEach(content => {
                content.classList.remove('active');
            });

            // Show target content
            const targetContent = document.querySelector(`[data-content="${unitType}"]`);
            if (targetContent) {
                targetContent.classList.add('active');
            }
        }
    </script>
    <script type="text/javascript" src="admin/js/plugins/select2.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#property').select2();
            $('#unit-property').select2();
            $('#area').select2();
            $('#property-area').select2();
        });
    </script>

</body>



</html>