<?php
session_start();
include "./db_config.php";
require_once 'Forms/crown-form.php';
?>
<!doctype html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>Renitz Properties</title>
   <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico">

   <!--Font Style-->
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link
      href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&display=swap"
      rel="stylesheet">
   <!--    owl-carousel-css-->
   <link rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
   <link rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
   <!-- fancybox cdn -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" />
   <!--Popup Comming Start-->
   <link href="assets/css/cust-popup.css" rel="stylesheet">
   <!--Popup Comming End-->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

   <link href="assets/css/magnific-popup.css" rel="stylesheet">
   <!-- Custom CSS -->
   <link href="assets/css/styles.css" rel="stylesheet">
   <link href="assets/css/custom-new.css" rel="stylesheet">
   <link href="assets/css/custom-landing.css" rel="stylesheet">

</head>

<body>
   <!-- start header -->
   <nav class="sansara__header navbar navbar-expand-lg">
      <div class="container">
         <!-- Brand -->

         <a class="nav-brand me-0 static-logo" href="index.php"><img src="assets/img/logo-header.png" class="logo"
               alt=""></a>

         <button class="navbar-toggler collapsed" type="button" data-bs-toggle="offcanvas"
            data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
         </button>
         <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar2"
            aria-labelledby="offcanvasNavbar2Label">
            <div class="offcanvas-header">
               <button type="button" class="btn-close " data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <!-- Navbar links -->
            <div class="offcanvas-body">
               <ul class="navbar-nav align-items-center">
                  <li class="nav-item">
                     <a class="nav-link nav-link-custom" href="#overview">Overview</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link nav-link-custom" href="#highlights">Highlights</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link nav-link-custom" href="#price">Price</a>
                  </li>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link nav-link-custom" href="#gallery">Gallery</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link nav-link-custom" href="#location">Location</a>

                  <li class="nav-item">
                     <a class="nav-link" href="#contact">Contact Us</a>
                  </li>
                  <li class="nav-item" style="margin-top:5px;">
                     <a href="tel:8420994555" class="btn btn-primary"><b><i class="fa fa-phone" aria-hidden="true"></i>
                           +918420994555</b></a>
                  </li>
                  <li class="nav-item" style="margin-top:5px;">
                     <a href="javascript:void(0)" class="btn btn-primary text-uppercase  rounded-0"
                        title="download brochure" data-toggle="modal" data-target="#modal1">DOWNLOAD
                        BROCHURE
                     </a>

                  </li>
               </ul>
            </div>
         </div>
      </div>
   </nav>
   <!-- end of sansara__header -->
   <!-- start banner section -->
   <div class="banner_section">

      <div class="carousel-item active">
         <img src="assets/img/banner1.jpg" class="img-fluid " />
      </div>
      <div class="banner_outer">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="banner_content">
                     <div class="content">


                        <h1 class="heading" style="color: #001949;">
                           <center><b>New Launch Projects</b></center>
                        </h1>
                        <h2 class="price" style="color: #001949;">
                           <center>📍 Mahisbathan, off Sector V Kolkata
                        </h2>

                        <div class="curved-rectangle">
                           <p>◆&emsp; Facing 1000 Acre of Lake<br>◆&emsp; 3 & 4 BHK Luxury Apartments<br>◆&emsp;
                              Exclusive
                              CLP Payment Plan<br>◆&emsp; No. of floors : G+29<br>◆&emsp; Total Flats : 528</p>
                        </div>

                        <div class="curved-rectangle">
                           <center>
                              <h3 class="price" style="color: #fff;">PRICE STARTS AT<br><span>₹ 1.78 Cr*</span>ONWARDS
                              </h3>
                           </center>
                        </div><br>


                        <!-- <center><button class="btn btn_yellow" data-toggle="modal" data-target="#modal1"><b>DOWNLOAD BROCHURE</b></button></center> -->
                     </div>
                     <div class="form banner-form">
                        <form id="enq_form" action="" method="post" enctype="multipart/form-data">
                           <input type="hidden" name="form_title" value="Enquire Form">
                           <div class="animated_form">
                              <div class="form-head">
                                 <center>
                                    <h4 class="form_heading">Enquire Now!</h4>
                                 </center>
                              </div>
                              <div class="form-content">
                                 <div class="form-group">
                                    <input id="qSenderNamemodal1" name="name" class="form-input" placeholder="Your Name"
                                       type="text" required />
                                 </div>
                                 <div class="form-group">
                                    <input id="qEmailIDmodal1" name="email" class="form-input email-address"
                                       placeholder="Your Email" type="email" required />
                                 </div>
                                 <div class="form-group ">
                                    <input id="qMobileNomodal1" name="phone" class="form-input numberText number-only"
                                       placeholder="Mobile Number" type="number" required />
                                 </div><br>
                                 <div class="checkbox-section"
                                    style="display: flex; justify-content: space-between; align-items: baseline;">
                                    <input type="checkbox" name="consent_checkbox" id="consent_checkbox" value="1"
                                       checked style="position: relative;top: 6px;">
                                    <p class="text"
                                       style="font-size: 10px; padding: 10px; margin: 0;line-height: unset; padding-bottom: 0;">
                                       I authorize website owner and its representatives to Call, <br>SMS, Email or
                                       WhatsApp me about its products and offers.This consent overrides any registration
                                       for DNC/NDNC.</p>
                                 </div>

                                 <button class="btn btn_yellow" type="submit" name="submit" value="Submit Now"
                                    style="background-color:#144b8e; color: #fff !important;">Submit Now</button>
                              </div>

                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>

   <!-- start about section -->
   <section class="about_section " id="overview">
      <div class="container">
         <div class="row">
            <div class="col-md-6 left_col">
               <figure>
                  <img src="assets/img/gallery3.jpg" class="img-fluid " alt="About Image" />
               </figure>
            </div>
            <div class="col-md-6 right_col">
               <div class="content">
                  <center>
                     <h3 class="heading custom_heading">OVERVIEW<span class="bottom"><i></i><i></i><i></i></span></h3>
                  </center><br>
                  <p style="text-align: justify;">
                     <b>​New Launch Projects in Mahisbathan, Off Sector V, Kolkata</b> <br>

                     Discover the epitome of luxury living with our latest residential project in Mahisbathan,
                     strategically located off Sector V, Kolkata. This premium development offers 3 & 4 BHK luxury
                     apartments, designed to meet the highest standards of comfort and sophistication.<br>

                     <b>🏢 Project Highlights:</b><br>

                     Exclusive CLP Payment Plan: Enjoy a hassle-free buying experience with our convenient Construction
                     Linked Payment Plan.<br>

                     Spacious Layouts: The project features G+29 floors, providing ample space and breathtaking
                     views.<br>

                     Total Flats: With 528 meticulously designed flats, residents will experience a vibrant and dynamic
                     community.<br>

                     <b> ✨ Price Starts At: ₹ 1.78 Cr* Onwards</b>

                     This project seamlessly blends modern architecture with premium amenities, making it an ideal
                     choice for discerning homebuyers and investors. Located close to major IT hubs, educational
                     institutions, and entertainment zones, it offers unmatched connectivity and convenience.<br>

                     Don’t miss the chance to own a piece of luxury in Kolkata’s most sought-after locality. Your dream
                     home awaits in Mahisbathan!
                  </p><br>

                  <center>
                     <a href="#" class="btn btn-primary text-uppercase  rounded-0" data-toggle="modal"
                        data-target="#modal1">ownload
                        Brochure
                        <i class="fa fa-angle-right ml-3 arrow-btn "></i></a>

                  </center>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- end of about section -->
   <!-- start highlights section -->
   <section class="highlights_section" id="highlights">
      <!-- <h3 class="section_heading">Highlights</h3> -->
      <div class="container">
         <div class="row">
            <div class="col-md-6 left_col">
               <div class="content">
                  <h3 class="heading custom_heading">HIGHLIGHTS<span class="bottom"><i></i><i></i><i></i></span></h3>
                  <ul>
                     <li><span>1</span> 3 & 4 BHK Luxury Apartments.</li>
                     <li><span>2</span> Total Flats : 528</li>
                     <li><span>3</span> Location : Mahisbathan, off Sector V, Kolkata</li>
                     <li><span>4</span>Pre-Launch scheme: Rs. 1.78 to 2.85 Cr (including 1 parking)</li>
                     <li><span>5</span> Handover of first 3 Towers– 5 years + 6 months grace period</li>
                     <li><span>6</span> No. of floors : G+29(4 Towers), G+30(1 Tower)</li>

                  </ul>
               </div>
            </div>
            <div class="col-md-6 right_col">
               <div class="content">
                  <figure>
                     <img src="assets/img/gallery2.jpg" alt="Highlight" class="img-fluid " />
                  </figure>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- end of highlights  ection -->

   <!-- start price section -->
   <section class="price_section" id="price">
      <div class="container">
         <center>
            <h3 class="heading custom_heading mb-4">PRICE<span class="bottom"><i></i><i></i><i></i></span></h3>
         </center>
         <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-6 col-12 mb_30 mb_md_20 px_md_10 px_xs_5 mb_xs_10">
               <div class="box">
                  <div class="content">
                     <center>
                        <h3 class="title">3 BHK + 2T</h3>
                        <h4 class="size"><span><strong>Size</strong></span>1572 -1601 sq.ft.</h4>
                        <h2 class="price"><span><strong>Price</strong></span>₹ 1.78 Cr*</h2>
                        <button class="btn btn_yellow" data-toggle="modal" data-target="#modal1">ENQUIRE NOW</button>
                     </center>
                  </div>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-12 mb_30 mb_md_20 px_md_10 px_xs_5 mb_xs_10">
               <div class="box">
                  <div class="content">
                     <center>
                        <h3 class="title">3 BHK + 3T</h3>
                        <h4 class="size"><span><strong>Size</strong></span>1815 -1853 sq.ft.</h4>
                        <h2 class="price"><span><strong>Price</strong></span>₹On Request*</h2>
                        <button class="btn btn_yellow" data-toggle="modal" data-target="#modal1">ENQUIRE NOW</button>
                     </center>
                  </div>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-12 mb_30 mb_md_20 px_md_10 px_xs_5 mb_xs_10">
               <div class="box">
                  <div class="content">
                     <center>
                        <h3 class="title">4 BHK + 3T</h3>
                        <h4 class="size"><span><strong>Size</strong></span>2099 -2269 sq.ft.</h4>
                        <h2 class="price"><span><strong>Price</strong></span>₹On Request*</h2>
                        <button class="btn btn_yellow" data-toggle="modal" data-target="#modal1">ENQUIRE NOW</button>
                     </center>
                  </div>
               </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-6 col-12 mb_30 mb_md_20 px_md_10 px_xs_5 mb_xs_10">
               <div class="box">
                  <div class="content">
                     <center>
                        <h3 class="title">4 BHK + 4T</h3>
                        <h4 class="size"><span><strong>Size</strong></span>2236 -2268 sq.ft.</h4>
                        <h2 class="price"><span><strong>Price</strong></span>₹On Request*</h2>
                        <button class="btn btn_yellow" data-toggle="modal" data-target="#modal1">ENQUIRE NOW</button>
                     </center>
                  </div>
               </div>
            </div>

         </div>
      </div>
      </div>
   </section>
   <!-- end of price section -->
   <!-- end of floor plan section -->


   <!-- start gallery section -->
   <section class="floor_plan_section gallery_section" id="gallery">
      <div class="container">
         <center>
            <h3 class=" custom_heading">Gallery<span class="bottom"><i></i><i></i><i></i></span></h3>
         </center>
         <div class="floor_content">

            <div class="item">
               <a href="assets/img/gallery2.jpg" class="with-caption image-link" title="">
                  <img src="assets/img/gallery2.jpg" alt="Gallery Image" class="img-fluid gallery-img">
               </a>
            </div>
            <div class="item">
               <a href="assets/img/banner.jpg" class="with-caption image-link" title="">
                  <img src="assets/img/banner.jpg" alt="Gallery Image" class="img-fluid gallery-img">
               </a>
            </div>
            <div class="item">
               <a href="assets/img/gallery.jpg" class="with-caption image-link" title="">
                  <img src="assets/img/gallery.jpg" alt="Gallery Image" class="img-fluid gallery-img">
               </a>
            </div>
            <div class="item">
               <a href="assets/img/gallery1.jpg" class="with-caption image-link" title="">
                  <img src="assets/img/gallery1.jpg" alt="Gallery Image" class="img-fluid gallery-img">
               </a>
            </div>
            <div class="item">
               <a href="assets/img/gallery4.jpg" class="with-caption image-link" title="">
                  <img src="assets/img/gallery4.jpg" alt="Gallery Image" class="img-fluid gallery-img">
               </a>
            </div>
            <div class="item">
               <a href="assets/img/gallery3.jpg" class="with-caption image-link" title="">
                  <img src="assets/img/gallery3.jpg" alt="Gallery Image" class="img-fluid gallery-img">
               </a>
            </div>

         </div>
      </div>
   </section>

   <!-- start location map -->
   <section class="highlights_section pt-0" id="location">

      <div class="container">
         <div class="row">
            <div class="col-md-6 left_col">
               <div class="content">
                  <h3 class="heading custom_heading">Location Map<span class="bottom"><i></i><i></i><i></i></span></h3>
                  <ul>
                     <li><span>1</span> The Newtown School – 2.6 kms</li>
                     <li><span>2</span> Salt Lake Siksha Niketan – 1.1 kms</li>
                     <li><span>3</span> Salt Lake Sec V Metro Station – 3.1 kms</li>
                     <li><span>4</span> Kolkata Railway Station – 10.5 kms
                     </li>
                     <li><span>5</span> Mani Square – 6.8 kms</li>
                     <li><span>5</span> Ohio Hospital – 3.6 kms</li>
                     <li><span>5</span> Techno India – 3.4 kms</li>
                     <li><span>5</span> Presidency University – 4.2 kms</li>
                     <li><span>5</span> St. Xavier’s University – 5.8 kms</li>
                  </ul>
               </div>
            </div>
            <!--<div class="col-md-6 right_col">
            <div class="content">-->
            <!--<figure>
                  <a href="images/location.webp" class="with-caption image-link" title="Location Map">
                  <img src="images/location.webp" alt="Location Map" class="img-fluid gallery-img "  >
                  </a>
               </figure>-->
            <div class="col-lg-5 location-img">
               <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14736.933506066323!2d88.4394257026345!3d22.5703731718898!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a027505aebe05d9%3A0xf28c634044b1c7d1!2sMahish%20Bathan%2C%20Mohisbathan%2C%20Dhapa%2C%20Kolkata%2C%20West%20Bengal!5e0!3m2!1sen!2sin!4v1743917369915!5m2!1sen!2sin"
                  width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                  referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            <!--</div>-->
         </div>
      </div>
      </div>
   </section>
   <!-- end of location map -->

   <section class="query_section" id="contact">
      <div class="container">
         <div class="row ">
            <div class="col-md-8 left_col">
               <form id="enq_form1" action="" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="form_title" value="Schedule Form">
                  <div class="animated_form">
                     <div class="form-head">
                        <h4 class="form_heading">
                           <center>Schedule A Site Visit
                        </h4>
                        </center>
                     </div>
                     <div class="form-group">
                        <input id="qSenderNamemodal2" name="name" class="form-input" type="text" placeholder="Your Name"
                           required>
                        <span class="error"><?php echo $nameErr; ?></span>
                     </div>
                     <div class="form-group">
                        <input id="qEmailIDmodal2" name="email" class="form-input email-address" type="email"
                           placeholder="Your Email" required>
                        <span class="error"><?php echo $emailErr; ?></span>
                     </div>
                     <div class="form-group">
                        <input id="qMobileNomodal2" name="phone" class="form-input number-only" type="number"
                           placeholder="Mobile Number" required>
                        <span class="error"><?php echo $phoneErr; ?></span>
                     </div>
                     <button class="btn form-control mt_lg_10" type="submit" name="submit" value="Submit Now"
                        style="background-color:#144b8e; color: #fff !important;">Submit Now</button>
                  </div>
               </form>
            </div>
            <div class="col-md-4 right_col">
               <div class="footer-widget">
                  <img src="assets/img/logo-header.png" class="img-footer" alt="">
                  <div class="footer-add">
                     <p><i class="fa fa-map-marker" aria-hidden="true" style="padding-right: 7px;"></i> Poddar
                        Court, 18 Rabindra sarani,5th Floor ,Office No - 527 Kolkata :700001, West Bengal, India
                     </p>
                     <p><a href="tel:+918420994555" style="color: #fff;"><i class="fa fa-phone" aria-hidden="true"
                              style="padding-right: 7px;"></i> +91 8420994555</a></p>
                     <p><a href="mailto:enquiry@renitzproperties.com" style="color: #fff;"><i class="fa fa-envelope"
                              aria-hidden="true" style="padding-right: 7px;"></i>
                           enquiry@renitzproperties.com</a></p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- end of query section -->
   <!-- start footer section -->
   <footer class="footer-section">
      <div class="footer-container container">


         <div class="row"><br>
         </div>
      </div>
   </footer>
   <!-- end of footer section -->
   <!-- start mobile section -->
   <div class="mobile-section">
      <a href="javascript:void(0)" class="btn btn_yellow" title="Enquire Now" data-toggle="modal" data-target="#modal1">
         <b> <i class="fas fa-question-circle"></i> Enquire Now</b></a>
      <a href="https://api.whatsapp.com/send?phone=+918583856503%20&amp;text=I'm%20interested%20in%20New%20Launch%20Projects%20In%20Kolkata.%20Kindly%20share%20project%20details%20&amp;%20brochure."
         class="btn btn_yellow"><b> <i class="fab fa-whatsapp" aria-hidden="true"></i> WhatsApp</b></a>
      <a href="tel:+91-8583856503" class="btn btn_yellow"><b><i class="fa fa-phone"
               aria-hidden="true"></i>+918583856503</b></a>
   </div>
   <!-- end of mobile section -->
   <!-- Modal -->
   <div class="modal fade" id="modal1" tabindex="-1" aria-labelledby="exampleModalLabel" style="display: none;"
      aria-hidden="true">
      <div class="modal-dialog  modal-dialog-centered modal-lg">
         <div class="modal-content">
            <div class="modal-body">
               <div class="left_col">
                  <div class="content">
                     <button class="close" data-dismiss="modal" aria-label="Close">×</button>
                     <!-- <img src="images/m3m-logo.png" alt="project logo" class="img-fluid" /> -->
                     <h1 class="form-logo" style="color:#000;">New Launch Projects</h1>
                     <h4 class="mb-4" style="color:#000;">Mahisbathan, off Sector V, Kolkata</h4>

                  </div>
               </div>
               <div class="right_col">
                  <form id="enq_form1" action="" method="post" enctype="multipart/form-data">
                     <input type="hidden" name="form_title" value="download brochure Form">
                     <div class="animated_form">
                        <div class="form-head">
                           <center>
                              <h4 class="form_heading">DOWNLOAD BROCHURE</h4>
                           </center>
                        </div>
                        <div class="form-group">
                           <input class="form-input" name="name" type="text" placeholder="Your Name" required
                              id="qSenderNamemodal">
                        </div>
                        <div class="form-group">
                           <input class="form-input email-address" type="email" name="email" placeholder="Your Email"
                              required id="qEmailIDmodal">
                        </div>
                        <div class="form-group ">
                           <input id="qMobileNomodal1" name="phone" class="form-input numberText number-only"
                              placeholder="Mobile Number" type="number" required />
                        </div>
                        <button class="btn form-control mt_lg_10" type="submit" name="submit" value="Submit Now"
                           style="background-color:#144b8e; color: #fff !important;">Submit Now</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- Modal -->
   <div class="modal fade" id="onload" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <button class="close" data-dismiss="modal" aria-label="Close">×</button>
      <div class="modal-dialog  modal-dialog-centered modal-lg">
         <div class="modal-content">
            <div class="modal-body">
               <div class="left_col">
                  <div class="content">

                  </div>
               </div>
               <div class="right_col">
                  <form id="enq_form1" action="" method="post" enctype="multipart/form-data">
                     <input type="hidden" name="form_title" value="">
                     <div class="animated_form">
                        <div class="form-head">
                           <center>
                              <h4 class="form_heading">Send Us A Message!</h4>
                           </center>
                        </div>
                        <div class="form-group">
                           <input class="form-input" name="name" type="text" placeholder="Your Name" required
                              id="qSenderNamemodal3">
                        </div>
                        <div class="form-group">
                           <input class="form-input email-address" type="email" name="email" placeholder="Your Email"
                              required id="qEmailIDmodal3">
                        </div>
                        <div class="form-group">
                           <input id="qMobileNomodal3" class="form-input numberText number-only" type="number"
                              name="phone" placeholder="Mobile Number" required>
                        </div>
                        <!--<div class="form-group">
               <input id="qMessagemodal3" class="form-input" type="text" name="message" placeholder="Comment"
                 required>
             </div>-->
                        <button class="btn form-control mt_lg_10" type="submit" name="submit" value="Submit Now">Submit
                           Now</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>



   <script src="assets/js/jquery.min.js"></script>
   <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
   <script src="assets/js/popper.min.js"></script>
   <!-- <script src="assets/js/bootstrap.min.js"></script> -->
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
   <script src="assets/js/rangeslider.js"></script>
   <script src="assets/js/jquery.nice-select.min.js"></script>
   <script src="assets/js/jquery.magnific-popup.min.js"></script>
   <script src="assets/js/slick.js"></script>
   <script src="assets/js/lightbox.js"></script>
   <script src="assets/js/imagesloaded.js"></script>
   <script src="assets/js/dropzone.js"></script>
   <script src="assets/js/datedropper-javascript.js"></script>
   <script src="assets/js/custom.js"></script>
   <script src="assets/js/custom2.js"></script>
   <!--Popup Comming Start-->
   <script src="assets/js/cust-popup.js"></script>
   <script>
      document.getElementById("enq_form").addEventListener("submit", function (e) {
         const checkbox = document.getElementById("consent_checkbox");

         if (!checkbox.checked) {
            alert("You must agree to the terms before submitting.");
            e.preventDefault(); // Prevent form submission
         }
      });
   </script>

   <script type="text/javascript" language="javascript">
      var versionUpdate = (new Date()).getTime();
      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "scripts/queryform.min.ssl.js" + versionUpdate;
      document.body.appendChild(script);
      var AgentInfo = {
         "vAgentID": "2288",
         "vProject": "The Omaxe State Delhi",
         "vURL": "https://theomaxestate-dwarka.com/",
         "thankspageurl": "thanks.html",
      };
      //Needs to be duplicate in the case of multiple forms on the same page
      //--------------------------------------------------------------------------------------//
      $('#preferedtime').hide();
      $("#SubmitQuerymodal").click(function () {
         var FormInfo = {
            "SenderControlID": "qSenderNamemodal",
            "SenderControlMobileID": "qMobileNomodal",
            "SenderControlEmailID": "qEmailIDmodal",
            "SenderControlMsgID": "qMessagemodal"
         };
         SubmitQueryData(AgentInfo, FormInfo);
      });
      $("#SubmitQuerymodal1").click(function () {
         var FormInfo = {
            "SenderControlID": "qSenderNamemodal1",
            "SenderControlMobileID": "qMobileNomodal1",
            "SenderControlEmailID": "qEmailIDmodal1",
            "SenderControlMsgID": "qMessagemodal1"
         };
         SubmitQueryData(AgentInfo, FormInfo);
      });
      $("#SubmitQuerymodal2").click(function () {
         var FormInfo = {
            "SenderControlID": "qSenderNamemodal2",
            "SenderControlMobileID": "qMobileNomodal2",
            "SenderControlEmailID": "qEmailIDmodal2",
            "SenderControlMsgID": "qMessagemodal2"
         };
         SubmitQueryData(AgentInfo, FormInfo);
      });
      $("#SubmitQuerymodal3").click(function () {
         var FormInfo = {
            "SenderControlID": "qSenderNamemodal3",
            "SenderControlMobileID": "qMobileNomodal3",
            "SenderControlEmailID": "qEmailIDmodal3",
            "SenderControlMsgID": "qMessagemodal3"
         };
         SubmitQueryData(AgentInfo, FormInfo);
      });
      $(document).ready(function () {
         $('input[type=submit]').on('click', function () {
            $(this).closest('.animated_form').find('.form-group').removeClass('focused')
         })
         $('.sansara__header .navbar-toggler').on('click', function () {
            const backdrop = '<div class="backdrop"></div>';
            const close = '<div class="close">&times;</div>';
            $('.sansara__header .navbar-collapse').append(backdrop);
            $('.sansara__header .navbar-collapse').append(close);
         })
         $('.sansara__header .navbar-collapse .nav-link').on('click', function () {
            if (window.matchMedia('(max-width: 991px)').matches) {
               $(this).closest('.navbar-collapse').removeClass('show');
               $(this).closest('.navbar-collapse').find('.backdrop').remove();
               $(this).closest('.navbar-collapse').find('.close').remove();
            }
         })
         $(document).on('click', function (e) {
            if ($(e.target).hasClass('backdrop')) {
               $('.navbar-collapse').removeClass('show');
               $(e.target).remove();
               $('.sansara__header .navbar-collapse .close').remove();
            }
            if ($(e.target).hasClass('close')) {
               $(e.target).closest('.navbar-collapse').removeClass('show')
               $(e.target).closest('.navbar-collapse').find('.backdrop').remove();
               $(e.target).closest('.navbar-collapse').find('.close').remove();
            }
         })
      })
      $(document).ready(function () {
         setTimeout(function () {
            $('#modal1').modal('show')
         }, 4000)
      })
      $(document).ready(function () {
         $('.sansara__header .navbar-collapse .nav-link').on('click', function () {
            $(this).closest('.nav-item').siblings().removeClass('active');
            $(this).closest('.nav-item').addClass('active');
         })
         // animated form label
         $('input').focus(function () {
            $(this).parents('.form-group').addClass('focused');
         });
         $('input').blur(function () {
            var inputValue = $(this).val();
            if (inputValue == "") {
               $(this).removeClass('filled');
               $(this).parents('.form-group').removeClass('focused');
            } else {
               $(this).addClass('filled');
            }
         });
         $('.without-caption').magnificPopup({
            type: 'image',
            closeOnContentClick: true,
            closeBtnInside: false,
            mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
            image: {
               verticalFit: true
            },
            zoom: {
               enabled: true,
               duration: 300 // don't foget to change the duration also in CSS
            }
         });
         $('.with-caption').magnificPopup({
            type: 'image',
            closeOnContentClick: true,
            closeBtnInside: false,
            mainClass: 'mfp-with-zoom mfp-img-mobile',
            image: {
               verticalFit: true,
               titleSrc: function (item) {
                  return item.el.attr('title') + ' &middot; <a class="image-source-link" href="' + item.el.attr('data-source') + '" target="_blank"></a>';
               }
            },
            zoom: {
               enabled: true
            }
         });
         // sansara__header
         $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
               $('.sansara__header').addClass('active');
            } else {
               $('.sansara__header').removeClass('active');
            }
         });
      });
      // link-target
      $('.nav-link-custom').on('click', function (e) {
         var target = this.hash,
            $target = $(target);
         $('html, body').stop().animate({
            'scrollTop': $target.offset().top - 50
         }, 100, 'swing', function () {
            window.location.hash = target;
         });
      });
   </script>
</body>

</html>