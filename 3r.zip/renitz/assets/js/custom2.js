$(document).ready(function () {
    $(".show-anchor").click(function () {
        $("p.hidden-text").show(0);
        $(".show-anchor").hide(0);
        $(".hide-span").hide(0);
    });
});

$(document).ready(function () {
    $(".show-anchor2").click(function () {
        $("p.hidden-text2").show(0);
        $(".show-anchor2").hide(0);
        $(".hide-span2").hide(0);
    });
});

$(document).ready(function () {
    $(".show-anchor3").click(function () {
        $("p.hidden-text3").show(0);
        $(".show-anchor3").hide(0);
        $(".hide-span3").hide(0);
    });
});

$(document).ready(function () {
    $(".show-anchor4").click(function () {
        $("p.hidden-text4").show(0);
        $("p.hide-anchor4").show(0);
        $(".show-anchor4").hide(0);
        $(".hide-span4").hide(0);
    });
});

$(document).ready(function () {
    $(".hide-anchor4").click(function () {
        $(".show-anchor4").show(0);
        $(".hide-span4").show(0);
        $("p.hidden-text4").hide(0);
        $("p.hide-anchor4").hide(0);
    });
});

$(document).ready(function () {
    $(".show-anchor5").click(function () {
        $("p.hidden-text5").show(0);
        $(".show-anchor5").hide(0);
        $(".hide-span5").hide(0);
    });
});

$(document).ready(function () {
    $(".show-anchor6").click(function () {
        $("p.hidden-text6").show(0);
        $(".show-anchor6").hide(0);
        $(".hide-span6").hide(0);
    });
});

$(document).ready(function () {
    $(".show-anchor7").click(function () {
        $("p.hidden-text7").show(0);
        $(".show-anchor7").hide(0);
        $(".hide-span7").hide(0);
    });
});


$(document).ready(function () {
    $(".show-anchor11").click(function () {
        $("p.hidden-text11").show(0);
        $("p.hide-anchor11").show(0);
        $(".show-anchor11").hide(0);
        $(".hide-span11").hide(0);
    });
});

$(document).ready(function () {
    $(".hide-anchor11").click(function () {
        $(".show-anchor11").show(0);
        $(".hide-span11").show(0);
        $("p.hidden-text11").hide(0);
        $("p.hide-anchor11").hide(0);
    });
});