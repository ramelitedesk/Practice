document.addEventListener("DOMContentLoaded", function () {
    // Function to collect form data (for both desktop and mobile views)
    function collectFormData() {
        let category, bhk, city, search;

        // Check if it's desktop view (d-md-block)
        if (window.innerWidth >= 768) {
            // Desktop search bar
            category = document.querySelector('#category').value;
            bhk = document.querySelector('#bhk').value;
            city = document.querySelector('#city').value;
            search = document.querySelector('#search').value;
        } else {
            // Mobile search bar
            category = document.querySelector('#mobile_category').value;
            bhk = document.querySelector('#mobile_bhk').value;
            city = document.querySelector('#mobile_city').value;
            search = document.querySelector('#mobile_search').value;
        }
        return {
            category: category,
            bhk: bhk,
            city: city,
            search: search
        };
    }

    // Get all elements with the class 'searchButton'
    const searchButtons = document.getElementsByClassName("searchButton");

    // Loop through each button and add an event listener
    for (let i = 0; i < searchButtons.length; i++) {
        searchButtons[i].addEventListener("click", function (event) {
            event.preventDefault(); // Prevent page reload

            
            
            let category, bhk, city, search;

            // Check if it's desktop view (d-md-block)
            if (window.innerWidth >= 768) {
                // Desktop search bar
                category = document.querySelector('#category').value;
                bhk = document.querySelector('#bhk').value;
                city = document.querySelector('#city').value;
                search = document.querySelector('#search').value;
            } else {
                // Mobile search bar
                category = document.querySelector('#mobile_category').value;
                bhk = document.querySelector('#mobile_bhk').value;
                city = document.querySelector('#mobile_city').value;
                search = document.querySelector('#mobile_search').value;
            }

            // Create a request payload
            const data = {
                category: category,
                bhk: bhk,
                city: city,
                search: search
            };

            console.log('Category:', category); // Preferred syntax for debugging
            if (!category) {
                console.warn("Category is undefined or empty!");
            }
            // Send data to the server using Fetch API
            fetch("search.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(data)
            })
                .then((response) => response.json())
                .then((result) => {
                    // Clear existing property cards
                    const propertyCards = document.getElementById("property_cards");
                    const container = document.querySelector("#property_cards .container");
                    container.innerHTML = "";

                // Check if results exist
                    if (result.length > 0) {
                        // Create a wrapper for the slider
                        const sliderWrapper = document.createElement('div');
                        sliderWrapper.classList.add('property-slider');
                        // Loop through results and create property cards
                        result.forEach((property) => {
                            const card = `
                                <div class="">
                                    <div class="property-card mx-auto">
                                        <div class="image-container" onclick="navigateToProperty('${encodeURIComponent(property.title)}')">
                                            <img src="${property.image}" alt="${property.title}" class="property-image">
                                            <div class="signature-dev">${property.label}</div>
                                        </div>
                                        <div class="property-content" onclick="navigateToProperty('${encodeURIComponent(property.title)}')">
                                            <div class="property-price">
                                                ₹${property.price}
                                            </div>
                                            <div class="property-name">
                                                ${property.title}
                                            </div>
                                            <div class="property-location">
                                                <svg class="location-icon" viewBox="0 0 24 24">
                                                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                                                </svg>
                                                ${property.address}, ${property.state}, ${property.country}
                                            </div>
                                            <div class="property-details">
                                                <div class="detail-item">
                                                    <svg class="detail-icon" viewBox="0 0 24 24">
                                                        <path d="M21 13v10h-6v-6h-6v6h-6v-10h-3l12-12 12 12h-3zm-1-5.907v-5.093h-3v2.093l3 3z"/>
                                                    </svg>
                                                    Baths: ${property.bathrooms}
                                                </div>
                                                <div class="detail-item">
                                                    <svg class="detail-icon" viewBox="0 0 24 24">
                                                        <path d="M19 9.3V4h-3v2.6L12 3 2 12h3v8h5v-6h4v6h5v-8h3l-3-2.7zM10 10c0-1.1.9-2 2-2s2 .9 2 2h-4z"/>
                                                    </svg>
                                                    Rooms: ${property.bhk}
                                                </div>
                                                <div class="detail-item">
                                                    <svg class="detail-icon" viewBox="0 0 24 24">
                                                        <path d="M15 3l2.3 2.3-2.89 2.87 1.42 1.42L18.7 6.7 21 9V3zM3 9l2.3-2.3 2.87 2.89 1.42-1.42L6.7 5.3 9 3H3zm6 12l-2.3-2.3 2.89-2.87-1.42-1.42L5.3 17.3 3 15v6zm12-6l-2.3 2.3-2.87-2.89-1.42 1.42 2.89 2.87L15 21h6z"/>
                                                    </svg>
                                                    Area: ${property.area_size} sq. ft.
                                                </div>
                                            </div>
                                        </div>
                                        <!-- agent section -->
                                        ${
                                            property.agent_name && property.agent_code
                                                ? `
                                                <div class="agent-section">
                                                    <div class="agent-info">
                                                        <img src="admin/upload_agent_photos/${property.agent_photo}" alt="Agent" class="rounded-circle me-2" width="40" height="40" />
                                                        <div class="agent-details">
                                                            <div class="agent-name">
                                                                ${property.agent_name}
                                                            </div>
                                                            <div class="agent-id text-muted small">
                                                                ${property.agent_code}</div>
                                                        </div>
                                                    </div>
                                                    <div class="dropdown">
                                                        <button class="btn btn-light btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown"
                                                            data-bs-placement="bottom-end">
                                                            <i class="fa fa-commenting"></i><i class="pl-1 fa fa-chevron-down"
                                                                aria-hidden="true"></i>
                                                        </button>
                                                        <ul class="dropdown-menu dropdown-menu-start">
                                                            <li><a class="dropdown-item" href="https://wa.me/+91${property.agent_wapp}?text="><i class="fa fa-whatsapp"></i> WhatsApp</a></li>
                                                            <li><a class="dropdown-item" href="tel:+91${property.agent_mob}"><i class="fa fa-phone"></i> Call</a></li>
                                                            <li><a class="dropdown-item" href="mailto:${property.agent_mail}"><i class="fa fa-envelope"></i> Email</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                `
                                                : ""
                                        }
                                    </div>
                                </div>
                            `;
                            // Append the card to the container
                            sliderWrapper.innerHTML += `<div class="slider-item">${card}</div>`;
                        });
                        // Append the slider wrapper to the container
                        container.appendChild(sliderWrapper);

                        // Initialize the Slick slider
                        $(sliderWrapper).slick({
                            slidesToShow: 3, // Number of cards visible at a time
                            slidesToScroll: 1, // Number of cards to scroll at a time
                            autoplay: false, // Enable auto-play
                            responsive: [
                                {
                                    breakpoint: 1920,
                                    settings: {
                                        slidesToShow: 3
                                    }
                                },
                                {
                                    breakpoint: 1024,
                                    settings: {
                                        slidesToShow: 2
                                    }
                                },
                                {
                                    breakpoint: 768,
                                    settings: {
                                        slidesToShow: 1
                                    }
                                }
                            ]
                        });
                    } else {
                    // If no results, display the message in the container
                        // Find the HTML structure cleared at line 212
                        const container = document.querySelector("#property_cards .container .row");
                        container.innerHTML = "<div class='col-12 error_page-container mb-3'><div class='error_page-row justify-content-center mt-5'><div class='error_page-col text-center'><!-- No data illustration --><img src='assets/img/error.jpg' alt='No data found' class='error_page-img img-fluid mb-4' style='max-width: 300px;'><!-- Error message --><h3 class='error_page-title text-secondary mb-3'>No Properties Found</h3><p class='error_page-message text-muted mb-4'>We could not find any properties matching your search criteria. Please go back to the Home Page.</p><!-- Action buttons --><div class='error_page-buttons d-flex justify-content-center gap-3'><a href='index.php' class='error_page-home-btn btn btn-primary px-4 mr-3'>Home</a></div></div></div></div>";
                    }
                })
                .catch((error) => console.error("Error:", error));

                // Select the nav element inside #property_cards > div and remove it
                const navElement = document.querySelector('#property_cards > nav');
                if (navElement) {
                    navElement.remove();
                }
        });
        
    }
});
// card tag
/* <div class="featured-tag text-center">${property.status}</div> */