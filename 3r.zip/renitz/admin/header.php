<?php
// session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta name="description"
      content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
   <!-- Twitter meta-->
   <meta property="twitter:card" content="summary_large_image">
   <meta property="twitter:site" content="@pratikborsadiya">
   <meta property="twitter:creator" content="@pratikborsadiya">
   <!-- Open Graph Meta-->
   <meta property="og:type" content="website">
   <meta property="og:site_name" content="Vali Admin">
   <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
   <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
   <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
   <meta property="og:description"
      content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
   <title>Renitz Properties Private Limited</title>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="icon" type="image/x-icon" href="images/favicon.ico">
   <!-- Main CSS-->
   <link rel="stylesheet" type="text/css" href="css/main.css">
   <!-- Font-icon css-->
   <link rel="stylesheet" type="text/css"
      href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
   <script type="text/javascript" src="featchData.js"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
   <script src="ckeditor/ckeditor.js"></script>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
   <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>

<body class="app sidebar-mini">
   <!-- Navbar-->
   <header class="app-header">
      <a class="app-header__logo" href="index.php" style="font-size: 21px;">Renitz Property</a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar"
         aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">


         <!-- User Menu-->
         <li class="dropdown">
            <a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i
                  class="fa fa-user fa-lg"></i></a>
            <ul class="dropdown-menu settings-menu dropdown-menu-right">
               <li><a class="dropdown-item" href="profile.php"><i class="fa fa-user fa-lg"></i> Profile</a></li>
               <!--<li><form action="main_code.php" method="POST"><button type="submit" name="logoutbtn"><a class="dropdown-item"><i class="fa fa-sign-out fa-lg"></i> Logout</a></button></form></li>-->
               <li><a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
            </ul>
         </li>
      </ul>
   </header>
   <!-- Sidebar menu-->
   <!--Quary Name Or Image Featch Section Start-->
   <?php $usernameName = $_SESSION['username'];
   // echo "$usernameName";
   include "include/db_config.php";
   $query123 = "SELECT * FROM mm_tellecalling WHERE tell_username='$usernameName'";
   $query_run123 = mysqli_query($connection, $query123);
   if (mysqli_num_rows($query_run123) > 0) {

      while ($row123 = mysqli_fetch_assoc($query_run123)) {

         $tellecalling_name = $row123['tellecalling_name'];
         $tellecalling_image = $row123['image'];

      }
   }
   ?>
   <!--Name Or Image Section End-->

   <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
   <aside class="app-sidebar">
      <div class="app-sidebar__user">
         <?php
         if ($tellecalling_image != '') {

            ?>
            <img class="app-sidebar__user-avatar" src="upload_banner_file/<?php echo $tellecalling_image; ?>"
               alt="User Image" style="height: 57px;">

            <?php

         } else {
            ?>
            <img class="app-sidebar__user-avatar" src="images/thambil-user.png" alt="User Image" style="height: 57px;">

            <?php
         }
         ?>
         <div>
            <p class="app-sidebar__user-name">Admin</p>

            <p class="app-sidebar__user-designation" style="font-size:13px"><?php echo $tellecalling_name; ?></p>


         </div>
      </div>
      <ul class="app-menu">
         <li><a class="app-menu__item active" href="index.php"><i class="app-menu__icon fa fa-dashboard"></i><span
                  class="app-menu__label">Dashboard</span></a></li>
         <!--<li class="treeview">
               <a class="app-menu__item" href="#" data-toggle="treeview" style="background: #07137e;"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Lead Center</span><i class="treeview-indicator fa fa-angle-right"></i></a>
               <ul class="treeview-menu">
                  <li><a class="treeview-item" href="lead-add.php" style="background: #07137e;"><i class="icon fa fa-circle-o"></i>Create Lead</a></li>
                  <li><a class="treeview-item" href="lead-data.php" style="background: #07137e;"><i class="icon fa fa-circle-o"></i>Lead Data</a></li>
         -->
         <!--<li><a class="treeview-item" href="gallery.php" rel="noopener"><i class="icon fa fa-circle-o"></i> Gallery Add</a></li>
                  <li><a class="treeview-item" href="product.php"><i class="icon fa fa-circle-o"></i>Product Add</a></li>-->
         <!--</ul>
            </li>-->
         <li class="treeview">
            <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span
                  class="app-menu__label">Project</span><i class="treeview-indicator fa fa-angle-right"></i></a>
            <ul class="treeview-menu">
               <li><a class="treeview-item" href="project-add.php"><i class="icon fa fa-circle-o"></i>Add New
                     Project</a></li>
               <li><a class="treeview-item" href="agent-new-add.php"><i class="icon fa fa-circle-o"></i>Add New
                     Agent</a></li>
               <li><a class="treeview-item" href="project-media-add.php"><i class="icon fa fa-circle-o"></i>Add Project
                     Media</a></li>
               <li><a class="treeview-item" href="project-aminities-add.php"><i class="icon fa fa-circle-o"></i>Add
                     Project Amenities</a></li>
               <li><a class="treeview-item" href="master-plan-add.php"><i class="icon fa fa-circle-o"></i>Add Master
                     Plan</a></li>
               <li><a class="treeview-item" href="floor-plan-add.php"><i class="icon fa fa-circle-o"></i>Add Floor
                     Plan</a></li>
               <!--<li><a class="treeview-item" href="sublisting-project-add.php" style="background: #07137e;"><i class="icon fa fa-circle-o"></i>Add Sub Listing</a></li>-->
               <li><a class="treeview-item" href="location-add.php"><i class="icon fa fa-circle-o"></i>Add Location</a>
               </li>
               <li><a class="treeview-item" href="agent-add.php"><i class="icon fa fa-circle-o"></i>Assign Agent</a>
               </li>
               <li><a class="treeview-item" href="project-list.php"><i class="icon fa fa-circle-o"></i>Project List</a>
               </li>
               <!--<li><a class="treeview-item" href="gallery.php" rel="noopener"><i class="icon fa fa-circle-o"></i> Gallery Add</a></li>
                  <li><a class="treeview-item" href="product.php"><i class="icon fa fa-circle-o"></i>Product Add</a></li>-->
            </ul>
         </li>
         <li class="treeview">
            <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-user-o"></i><span
                  class="app-menu__label">Agent</span><i class="treeview-indicator fa fa-angle-right"></i></a>
            <ul class="treeview-menu">
               <li><a class="treeview-item" href="agent-new-add.php"><i class="icon fa fa-circle-o"></i>Add New
                     Agent</a></li>
               <li><a class="treeview-item" href="agent-add.php"><i class="icon fa fa-circle-o"></i>Assign Agent</a>
               </li>
               <li><a class="treeview-item" href="agent-list.php"><i class="icon fa fa-circle-o"></i>Agent List</a></li>
            </ul>
         </li>
         <li class="treeview">
            <a class="app-menu__item" href="#url" data-toggle="treeview"><i
                  class="app-menu__icon fa fa-user-o"></i><span class="app-menu__label">Forms</span><i
                  class="treeview-indicator fa fa-angle-right"></i></a>
            <ul class="treeview-menu">
               <li><a class="treeview-item" href="form-leads.php"><i class="icon fa fa-circle-o"></i>Crown Page
                     Forms</a></li>
            </ul>
         </li>
         <!-- <li><a class="app-menu__item" href="customer_dtls.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Pickup Date Update</span></a></li>
            <li><a class="app-menu__item" href="today_pickup_request.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Today Pickup Date</span></a></li>
            <li><a class="app-menu__item" href="send_cust_address.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Allocate Boy</span></a></li>
            <li class="treeview">
               <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Pickup Boy Add</span><i class="treeview-indicator fa fa-angle-right"></i></a>
               <ul class="treeview-menu">
                  <li><a class="treeview-item" href="pickup-boy-add.php"><i class="icon fa fa-circle-o"></i> Pickup Boy Add</a></li>
                  </ul>
            </li>
            <li class="treeview">
               <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Billing Page</span><i class="treeview-indicator fa fa-angle-right"></i></a>
               <ul class="treeview-menu">
               <li><a class="app-menu__item" href="bill-list.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Today Due Bill List</span></a></li>
            <li><a class="app-menu__item" href="paid-list.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Paid Bill List</span></a></li>
                  </ul>
            </li>
            <li class="treeview">
               <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Earning Request Page</span><i class="treeview-indicator fa fa-angle-right"></i></a>
               <ul class="treeview-menu">
               <li><a class="app-menu__item" href="earn-bill-list.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Earn Due Bill List</span></a></li>
            <li><a class="app-menu__item" href="earn-paid-list.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Paid Earn Bill List</span></a></li>
                  </ul>
            </li>-->
         <!--<li class="treeview">
               <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-edit"></i><span class="app-menu__label">Forms</span><i class="treeview-indicator fa fa-angle-right"></i></a>
               <ul class="treeview-menu">
                  <li><a class="treeview-item" href="form-components.html"><i class="icon fa fa-circle-o"></i> Form Components</a></li>
                  <li><a class="treeview-item" href="form-custom.html"><i class="icon fa fa-circle-o"></i> Custom Components</a></li>
                  <li><a class="treeview-item" href="form-samples.html"><i class="icon fa fa-circle-o"></i> Form Samples</a></li>
                  <li><a class="treeview-item" href="form-notifications.html"><i class="icon fa fa-circle-o"></i> Form Notifications</a></li>
               </ul>
            </li>
            <li class="treeview">
               <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-th-list"></i><span class="app-menu__label">Tables</span><i class="treeview-indicator fa fa-angle-right"></i></a>
               <ul class="treeview-menu">
                  <li><a class="treeview-item" href="table-basic.html"><i class="icon fa fa-circle-o"></i> Basic Tables</a></li>
                  <li><a class="treeview-item" href="table-data-table.html"><i class="icon fa fa-circle-o"></i> Data Tables</a></li>
               </ul>
            </li>
            <li class="treeview">
               <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-file-text"></i><span class="app-menu__label">Pages</span><i class="treeview-indicator fa fa-angle-right"></i></a>
               <ul class="treeview-menu">
                  <li><a class="treeview-item" href="blank-page.html"><i class="icon fa fa-circle-o"></i> Blank Page</a></li>
                  <li><a class="treeview-item" href="page-login.html"><i class="icon fa fa-circle-o"></i> Login Page</a></li>
                  <li><a class="treeview-item" href="page-lockscreen.html"><i class="icon fa fa-circle-o"></i> Lockscreen Page</a></li>
                  <li><a class="treeview-item" href="page-user.html"><i class="icon fa fa-circle-o"></i> User Page</a></li>
                  <li><a class="treeview-item" href="page-invoice.html"><i class="icon fa fa-circle-o"></i> Invoice Page</a></li>
                  <li><a class="treeview-item" href="page-calendar.html"><i class="icon fa fa-circle-o"></i> Calendar Page</a></li>
                  <li><a class="treeview-item" href="page-mailbox.html"><i class="icon fa fa-circle-o"></i> Mailbox</a></li>
                  <li><a class="treeview-item" href="page-error.html"><i class="icon fa fa-circle-o"></i> Error Page</a></li>
               </ul>
            </li>
            <li><a class="app-menu__item" href="docs.html"><i class="app-menu__icon fa fa-file-code-o"></i><span class="app-menu__label">Docs</span></a></li>-->
      </ul>
   </aside>