<?php include "security.php"; ?>
<?php include "header.php"; ?>
<style>
    .frm_container {
        margin: 20px 0;
        max-width: 300px;
        padding: 10px;
    }

    #menu-items {
        width: 100%;
        padding: 10px 12px;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 6px;
        background-color: #fff;
        color: #333;
        appearance: none;
        -webkit-appearance: none;
        -moz-appearance: none;
        transition: border-color 0.3s ease;
    }

    #menu-items:focus {
        border-color: #007BFF;
        outline: none;
        box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.2);
    }
</style>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-edit"></i>Sansara Form Leads</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item">Sansara Form Leads</li>
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
        </ul>
    </div>
    <div class="row">
        <?php
        if (isset($_SESSION['success']) && $_SESSION['success'] != '') {
            echo ' <div class="bs-component"><div class="alert alert-dismissible alert-success"><button class="close" type="button" data-dismiss="alert">×</button><h4>Success!</h4><p><a class="alert-link" href="#">' . $_SESSION['success'] . '</a>.</p></div></div>';
            unset($_SESSION['success']);
        }
        if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
            echo ' <div class="bs-component"><div class="alert alert-dismissible alert-warning"><button class="close" type="button" data-dismiss="alert">×</button><h4>Warning!</h4><p><a class="alert-link" href="#">' . $_SESSION['status'] . '</a>.</p></div></div>';
            unset($_SESSION['status']);
        }
        ?>
    </div>
    <?php
    // $frm = isset($_GET['frm']) ? $_GET['frm'] : '';
    // $frm_nm = '';
    
    // if ($frm == '1') {
    //     $frm_nm = 'Enquire Form';
    // } elseif ($frm == '2') {
    //     $frm_nm = 'Schedule Form';
    // } elseif ($frm == '3') {
    //     $frm_nm = 'download brochure Form';
    // }
    ?>
    <!-- <div class="frm_container"> -->
    <!-- <label for="menu-items">Form Lists</label> -->
    <!-- <select id="menu-items">
            <option value="">Select Form</option>
            <option value="1" <?php echo ($frm == '1') ? 'selected' : ''; ?>>Enquire Form</option>
            <option value="2" <?php echo ($frm == '2') ? 'selected' : ''; ?>>Schedule Form</option>
            <option value="3" <?php echo ($frm == '3') ? 'selected' : ''; ?>>Download Brochure Form</option>

        </select> -->
    <!-- </div> -->
    <!--Table Section Start-->
    <?php
    include "include/db_config.php";
    $frm_nm = 'Sansara';
    if (!empty($frm_nm)) {
        $query = "SELECT * FROM renitz_form_data WHERE form_name = ?";
        // $query = "SELECT * FROM renitz_form_data";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, 's', $frm_nm);
        mysqli_stmt_execute($stmt);
        $results = mysqli_stmt_get_result($stmt);
        ?>

        <div class="row">
            <div class="col-md-12">
                <div class="tile">
                    <div class="tile-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered" id="sampleTable">
                                <?php
                                $all_keys = [];
                                $exclude_fields = ['project_title', 'page_url', 'pid', 'honeypot_field', 'chkbox', 'submit'];
                                foreach ($results as $row) {
                                    $form_data = json_decode($row['form_data'], true);
                                    if (is_array($form_data)) {
                                        $all_keys = array_merge($all_keys, array_keys($form_data));
                                    }
                                }
                                $all_keys = array_unique($all_keys);
                                ?>
                                <thead>
                                    <tr>
                                        <th>id</th>
                                        <?php
                                        foreach ($all_keys as $key) {
                                            if (!in_array($key, $exclude_fields) && $key !== 'country_Code') {
                                                ?>
                                                <th><?php echo htmlspecialchars($key, ENT_QUOTES, 'UTF-8'); ?></th>
                                                <?php
                                            }
                                        }
                                        ?>
                                        <th>Date</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (!empty($results)) {
                                        foreach ($results as $row) {
                                            $form_data = json_decode($row['form_data'], true);
                                            $form_nm = $row['form_name'];
                                            $iid = $row['id'];
                                            $created_at = $row['created_at'];
                                            ?>
                                            <tr>
                                                <td><?= $iid; ?></td>
                                                <?php
                                                foreach ($all_keys as $key) {
                                                    if (!in_array($key, $exclude_fields) && $key !== 'country_Code') {
                                                        if ($key === 'country_Code') {
                                                            continue; // skip individual country_Code display
                                                        }
                                                        if ($key === 'phone_no') {
                                                            $combined = (isset($form_data['country_Code']) ? $form_data['country_Code'] . ' ' : '') . $form_data['phone_no'];
                                                            echo '<td>' . htmlspecialchars($combined, ENT_QUOTES, 'UTF-8') . '</td>';
                                                        } else {
                                                            $value = isset($form_data[$key]) ? $form_data[$key] : '';
                                                            echo '<td>' . nl2br(htmlspecialchars($value, ENT_QUOTES, 'UTF-8')) . '</td>';
                                                        }
                                                        ?>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                                <td><?= $created_at; ?></td>
                                                <td>
                                                    <a href="javascript:sansara_form_delete_id(<?= $iid; ?>)">
                                                        <button class="btn btn-danger" type="button">Delete</button>
                                                    </a>
                                                </td>

                                            </tr>
                                            <?php
                                        }
                                    } else {
                                        echo "<tr><td colspan='5'>No Record Found</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    ?>
    <!--Table Section End-->
</main>

<script type="text/javascript">
    function sansara_form_delete_id(id, frm_nm) {
        if (confirm('Sure To Remove This Form Detail?')) {
            window.location.href = 'main_code.php?sansara_form_delete_id=' + id;
        }
    }
</script>

<?php include "footer.php"; ?>