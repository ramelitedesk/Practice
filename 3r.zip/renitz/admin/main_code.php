<?php
session_start();

include "include/db_config.php";
/* THIS IS Franchise Login SECTION PART.............. */
if (isset($_POST['logon_dtls'])) {
    $username = mysqli_real_escape_string($connection, $_POST['username']);
    $password = mysqli_real_escape_string($connection, $_POST['userpassword']);

    // Query to fetch the stored hashed password for the given username
    $query = "SELECT tell_username, tell_password FROM mm_tellecalling WHERE tell_username = '$username'";
    $query_run = mysqli_query($connection, $query);

    if ($row = mysqli_fetch_array($query_run)) {
        // Get the hashed password from the database
        $storedPassword = $row['tell_password'];

        // Verify the password
        if (password_verify($password, $storedPassword)) {
            // Password is correct, store username in session
            $_SESSION['username'] = $username;

            // Redirect to index.php
            header('Location: index.php');
        } else {
            // Password is incorrect
            $_SESSION['status'] = 'Username OR Password Invalid';
            header('Location: login.php');
        }
    } else {
        // Username not found
        $_SESSION['status'] = 'Username OR Password Invalid';
        header('Location: login.php');
    }
}

/* Banner Section Entry*/

if (isset($_POST["lead_dts_add"])) {
    $lead_name = mysqli_real_escape_string($connection, $_POST['lead_name']);
    $lead_email = mysqli_real_escape_string($connection, $_POST['lead_email']);
    $lead_phone = mysqli_real_escape_string($connection, $_POST['lead_phone']);
    $lead_requirment = mysqli_real_escape_string($connection, $_POST['lead_requirment']);
    $lead_project = mysqli_real_escape_string($connection, $_POST['lead_project']);
    $lead_location = mysqli_real_escape_string($connection, $_POST['lead_location']);
    $lead_posession = mysqli_real_escape_string($connection, $_POST['lead_posession']);
    $lead_budget = mysqli_real_escape_string($connection, $_POST['lead_budget']);
    $lead_payment = mysqli_real_escape_string($connection, $_POST['lead_payment']);
    $status = "P";
    // Set the new timezone
    date_default_timezone_set('Asia/Kolkata');
    //$date = date('d-m-y h:i:s');
    $Todaydate = date('d/m/Y');
    $MonthTodaydate = date('Y-m-d');
    $newMonthname = date('F', strtotime($MonthTodaydate));
    $CurrentYear = date('Y');
    //$ord_dt=mysqli_real_escape_string($connection,$_POST['banner_img']);
    $query = "INSERT INTO mm_lead(lead_name,lead_email,lead_phone,lead_requirment,lead_project,lead_location,lead_posession,lead_budget,lead_payment,lead_date,status,lead_month,lead_year) values 
             ('$lead_name','$lead_email','$lead_phone','$lead_requirment','$lead_project','$lead_location','$lead_posession','$lead_budget','$lead_payment','$Todaydate','$status','$newMonthname','$CurrentYear')";
    $query_run = mysqli_query($connection, $query);
    if ($query_run) {
        $_SESSION['success'] = "Lead Add Successfull";
        header('location:lead-add.php');
    } else {
        //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
        $_SESSION['status'] = "Lead Not Add";
        header('location:lead-add.php');
    }


}

/* Banner Update Section */

if (isset($_POST['lead_dts_status_update'])) {
    $lead_id = mysqli_real_escape_string($connection, $_POST['lead_id']);
    $lead_status = mysqli_real_escape_string($connection, $_POST['lead_status']);
    //$old_attachment_file= $_POST['old_attachment_file'];
    // Insert image content into database 
    $query = "UPDATE mm_lead SET lead_status='$lead_status' WHERE lead_id='$lead_id'";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) {
        $_SESSION['success'] = "Lead Remarks Update Successfull";
        header('location:lead-search.php');
    } else {
        //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
        $_SESSION['status'] = "Lead Remarks Not Successfull";
        header('location:lead-search.php');
    }

}

/*Banner Delete Section */


if (isset($_GET['lead_delete_id'])) {
    //$sql_query="DELETE FROM users WHERE user_id=".$_GET['delete_id'];
    $query = "DELETE  FROM mm_lead  WHERE lead_id=" . $_GET['lead_delete_id'];

    $query_run = mysqli_query($connection, $query);

    if ($query_run) {

        $_SESSION['success'] = "Lead Details Deleted";
        header('Location: lead-add.php');

    } else {

        $_SESSION['status'] = "Lead Details Not Deleted";
        header('Location: lead-add.php');

    }

}

/*Follow up section */

/* Banner Section Entry*/

if (isset($_POST["follow_up_add_dtls"])) {
    $follow_up = mysqli_real_escape_string($connection, $_POST['follow_up']);
    $lead_id = mysqli_real_escape_string($connection, $_POST['lead_id']);
    $taken_name1 = mysqli_real_escape_string($connection, $_POST['taken_name1']);
    $assign_status = mysqli_real_escape_string($connection, $_POST['assign_status']);
    if ($assign_status == 'A') {
        $assign_status1 = "A";
    } else {
        $assign_status1 = "M";
    }

    // Set the new timezone
    date_default_timezone_set('Asia/Kolkata');
    //$date = date('d-m-y h:i:s');
    $followTodaydate = date('d/m/Y h:i:s');

    //$ord_dt=mysqli_real_escape_string($connection,$_POST['banner_img']);
    $query = "INSERT INTO mm_followup(lead_id,follow_date_time,follow_up_status,taken_by,assign_status) values 
                ('$lead_id','$followTodaydate','$follow_up','$taken_name1','$assign_status')";
    $query_run = mysqli_query($connection, $query);
    if ($query_run) {
        $query1 = "UPDATE mm_lead SET lead_status='$follow_up',status='$assign_status1' WHERE lead_id='$lead_id'";
        $query_run1 = mysqli_query($connection, $query1);
        $_SESSION['success'] = "Lead Status Update Successfully";
        header('location:lead-data.php');
    } else {
        //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
        $_SESSION['status'] = "Lead Not Add";
        header('location:lead-data.php');
    }


}

/* Banner Update Section */

if (isset($_POST['telee_profile_update'])) {
    $telle_id = mysqli_real_escape_string($connection, $_POST['telle_id']);
    $telle_name = mysqli_real_escape_string($connection, $_POST['telle_name']);
    $telle_ph = mysqli_real_escape_string($connection, $_POST['telle_ph']);
    $telle_whatsapp = mysqli_real_escape_string($connection, $_POST['telle_whatsapp']);
    $telle_add = mysqli_real_escape_string($connection, $_POST['telle_add']);
    $old_telle_image = mysqli_real_escape_string($connection, $_POST['old_telle_image']);
    //$old_attachment_file= $_POST['old_attachment_file'];

    if (!empty($_FILES["telle_image"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["telle_image"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG');
        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['telle_image']['tmp_name'];
            $extension = explode('.', $_FILES['telle_image']['name']);
            $image_name = rand(10000, 99999) . '.' . $extension[1];
            $imgContent = addslashes(file_get_contents($image));
            $folder = "upload_banner_file/";
            move_uploaded_file($image, $folder . $image_name);
            // Insert image content into database 
            $query = "UPDATE mm_tellecalling SET tellecalling_name='$telle_name',phone_no='$telle_ph',whatsapp_no='$telle_whatsapp',tellecalling_addrss='$telle_add',image='$image_name' WHERE tell_id='$telle_id'";
            $query_run = mysqli_query($connection, $query);

            if ($query_run) {
                $_SESSION['success'] = "Your Profile Updated";
                header('location:profile.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG, JPEG, PNG files are allowed to upload";
            header('location:profile.php');
        }
    } else {
        if (empty($_FILES["telle_image"]["name"])) {
            $update_file_name1 = $old_telle_image;
        }

        //$query="UPDATE mm SET attachment_file='$update_file_name1' WHERE sl_no='$sl_hid_id'";

        $query = "UPDATE mm_tellecalling SET tellecalling_name='$telle_name',phone_no='$telle_ph',whatsapp_no='$telle_whatsapp',tellecalling_addrss='$telle_add',image='$update_file_name1' WHERE tell_id='$telle_id'";


        $query_run = mysqli_query($connection, $query);
        if ($query_run) {

            $_SESSION['success'] = "Your Profile Updated";
            header('location:profile.php');
        } else {
            $_SESSION['success'] = "Not Successful";
            header('location:profile.php');
        }

    }

}

/*Property Entry Section */

/* Banner Section Entry*/

if (isset($_POST["property_dts_add"])) {
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $prop_type = mysqli_real_escape_string($connection, $_POST['prop_type']);
    $prop_status = mysqli_real_escape_string($connection, $_POST['prop_status']);
    $prop_lebel = mysqli_real_escape_string($connection, $_POST['prop_lebel']);
    $prop_content = mysqli_real_escape_string($connection, $_POST['prop_content']);
    $sale_rent_price = mysqli_real_escape_string($connection, $_POST['sale_rent_price']);
    $second_price = "";
    $prop_after_price = "";
    $prop_price_prefix = "";
    $prop_bedrooms = mysqli_real_escape_string($connection, $_POST['prop_bedrooms']);
    $prop_rooms = mysqli_real_escape_string($connection, $_POST['prop_rooms']);
    $prop_bathrooms = mysqli_real_escape_string($connection, $_POST['prop_bathrooms']);
    $prop_area_size = mysqli_real_escape_string($connection, $_POST['prop_area_size']);
    $prop_postfix = mysqli_real_escape_string($connection, $_POST['prop_postfix']);
    $prop_land_area = mysqli_real_escape_string($connection, $_POST['prop_land_area']);
    $prop_land_size = mysqli_real_escape_string($connection, $_POST['prop_land_size']);
    $prop_car_park = mysqli_real_escape_string($connection, $_POST['prop_car_park']);
    $prop_garage = mysqli_real_escape_string($connection, $_POST['prop_garage']);
    $prop_id = mysqli_real_escape_string($connection, $_POST['prop_id']);
    $prop_year_built = mysqli_real_escape_string($connection, $_POST['prop_year_built']);
    $prop_video = mysqli_real_escape_string($connection, $_POST['prop_video']);
    $prop_active = 'U';
    //$prop_logo_em=mysqli_real_escape_string($connection,$_FILES['prop_logo']);
    //$prop_develop_logo_em=mysqli_real_escape_string($connection,$_FILES['prop_develop_logo']);

    //Image Upload start//
    if (!empty($_FILES["prop_logo"]["name"]) && !empty($_FILES["prop_develop_logo"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["prop_logo"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        $fileName1 = basename($_FILES["prop_develop_logo"]["name"]);
        $fileType1 = pathinfo($fileName1, PATHINFO_EXTENSION);

        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'WEBP', 'webp');
        if (in_array($fileType, $allowTypes) && in_array($fileType1, $allowTypes)) {
            $image = $_FILES['prop_logo']['tmp_name'];
            $extension = explode('.', $_FILES['prop_logo']['name']);
            $image_name = rand(10000, 99999) . '.' . $extension[1];
            $imgContent = addslashes(file_get_contents($image));

            $image1 = $_FILES['prop_develop_logo']['tmp_name'];
            $extension1 = explode('.', $_FILES['prop_develop_logo']['name']);
            $image_name1 = rand(10000, 99999) . '.' . $extension1[1];
            $imgContent1 = addslashes(file_get_contents($image1));

            $folder = "upload_property_file/";
            move_uploaded_file($image, $folder . $image_name);
            move_uploaded_file($image1, $folder . $image_name1);
            // Insert image content into database 
//$query="INSERT INTO mm_floor_plan(prop_title,plan_title,floor_bed_room,floor_bath_room,floor_price,floor_price_post_fix,floor_plan_size,floor_content,plan_imgae) values 
//('$prop_title','$plan_title','$floor_bed_room','$floor_bath_room','$floor_price','$floor_price_post_fix','$floor_plan_size','$floor_content','$image_name')";
            $query = "INSERT INTO mm_property_dtls(prop_title,prop_type,prop_status,prop_lebel,prop_content,sale_rent_price,second_price,prop_after_price,prop_price_prefix,prop_bedrooms,prop_rooms,prop_bathrooms,prop_area_size,prop_postfix,prop_land_area,prop_land_size,prop_car_park,prop_garage,prop_id,prop_year_built,prop_video,prop_logo,prop_develop_logo,prop_active)
values('$prop_title','$prop_type','$prop_status','$prop_lebel','$prop_content','$sale_rent_price','$second_price','$prop_after_price','$prop_price_prefix','$prop_bedrooms','$prop_rooms','$prop_bathrooms','$prop_area_size','$prop_postfix','$prop_land_area','$prop_land_size','$prop_car_park','$prop_garage','$prop_id','$prop_year_built','$prop_video','$image_name','$image_name1','$prop_active')";
            $query_run = mysqli_query($connection, $query);
            if ($query_run) {
                $_SESSION['success'] = "Project Details Add Successfully";
                header('location:project-add.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG-jpg, JPEG-jpeg, PNG-png files are allowed to upload";
            header('location:project-add.php');
        }
    } else if (!empty($_FILES["prop_logo"]["name"]) && empty($_FILES["prop_develop_logo"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["prop_logo"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        //$fileName1 = basename($_FILES["prop_develop_logo"]["name"]); 
        //$fileType1 = pathinfo($fileName1, PATHINFO_EXTENSION);

        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'WEBP', 'webp');
        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['prop_logo']['tmp_name'];
            $extension = explode('.', $_FILES['prop_logo']['name']);
            $image_name = rand(10000, 99999) . '.' . $extension[1];
            $imgContent = addslashes(file_get_contents($image));

            //$image1 = $_FILES['prop_develop_logo']['tmp_name'];
            //$extension1 = explode('.', $_FILES['prop_develop_logo'] ['name']);
            //$image_name1 ="NA";
            //$imgContent1 = addslashes(file_get_contents($image1)); 

            $folder = "upload_property_file/";
            move_uploaded_file($image, $folder . $image_name);
            //move_uploaded_file($image1,$folder.$image_name1);
            // Insert image content into database 
            //$query="INSERT INTO mm_floor_plan(prop_title,plan_title,floor_bed_room,floor_bath_room,floor_price,floor_price_post_fix,floor_plan_size,floor_content,plan_imgae) values 
            //('$prop_title','$plan_title','$floor_bed_room','$floor_bath_room','$floor_price','$floor_price_post_fix','$floor_plan_size','$floor_content','$image_name')";
            $query = "INSERT INTO mm_property_dtls(prop_title,prop_type,prop_status,prop_lebel,prop_content,sale_rent_price,second_price,prop_after_price,prop_price_prefix,prop_bedrooms,prop_rooms,prop_bathrooms,prop_area_size,prop_postfix,prop_land_area,prop_land_size,prop_car_park,prop_garage,prop_id,prop_year_built,prop_video,prop_logo,prop_develop_logo,prop_active)
    values('$prop_title','$prop_type','$prop_status','$prop_lebel','$prop_content','$sale_rent_price','$second_price','$prop_after_price','$prop_price_prefix','$prop_bedrooms','$prop_rooms','$prop_bathrooms','$prop_area_size','$prop_postfix','$prop_land_area','$prop_land_size','$prop_car_park','$prop_garage','$prop_id','$prop_year_built','$prop_video','$image_name','','$prop_active')";
            $query_run = mysqli_query($connection, $query);
            if ($query_run) {
                $_SESSION['success'] = "Project Details Add Successfully";
                header('location:project-add.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG-jpg, JPEG-jpeg, PNG-png files are allowed to upload";
            header('location:project-add.php');
        }
    } else if (empty($_FILES["prop_logo"]["name"]) && !empty($_FILES["prop_develop_logo"]["name"])) {
        // Get file info 
        //$fileName = basename($_FILES["prop_logo"]["name"]); 
        //$fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        $fileName1 = basename($_FILES["prop_develop_logo"]["name"]);
        $fileType1 = pathinfo($fileName1, PATHINFO_EXTENSION);

        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'WEBP', 'webp');
        if (in_array($fileType1, $allowTypes)) {
            //$image = $_FILES['prop_logo']['tmp_name'];
            //$extension = explode('.', $_FILES['prop_logo'] ['name']);
            //$image_name = rand(10000,99999) . '.' . $extension[1];
            //$imgContent = addslashes(file_get_contents($image)); 

            $image1 = $_FILES['prop_develop_logo']['tmp_name'];
            $extension1 = explode('.', $_FILES['prop_develop_logo']['name']);
            $image_name1 = rand(10000, 99999) . '.' . $extension1[1];
            $imgContent1 = addslashes(file_get_contents($image1));

            $folder = "upload_property_file/";
            //move_uploaded_file($image,$folder.$image_name);
            move_uploaded_file($image1, $folder . $image_name1);
            // Insert image content into database 
            //$query="INSERT INTO mm_floor_plan(prop_title,plan_title,floor_bed_room,floor_bath_room,floor_price,floor_price_post_fix,floor_plan_size,floor_content,plan_imgae) values 
            //('$prop_title','$plan_title','$floor_bed_room','$floor_bath_room','$floor_price','$floor_price_post_fix','$floor_plan_size','$floor_content','$image_name')";
            $query = "INSERT INTO mm_property_dtls(prop_title,prop_type,prop_status,prop_lebel,prop_content,sale_rent_price,second_price,prop_after_price,prop_price_prefix,prop_bedrooms,prop_rooms,prop_bathrooms,prop_area_size,prop_postfix,prop_land_area,prop_land_size,prop_car_park,prop_garage,prop_id,prop_year_built,prop_video,prop_logo,prop_develop_logo,prop_active)
        values('$prop_title','$prop_type','$prop_status','$prop_lebel','$prop_content','$sale_rent_price','$second_price','$prop_after_price','$prop_price_prefix','$prop_bedrooms','$prop_rooms','$prop_bathrooms','$prop_area_size','$prop_postfix','$prop_land_area','$prop_land_size','$prop_car_park','$prop_garage','$prop_id','$prop_year_built','$prop_video','','$image_name1','$prop_active')";
            $query_run = mysqli_query($connection, $query);
            if ($query_run) {
                $_SESSION['success'] = "Project Details Add Successfully";
                header('location:project-add.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG-jpg, JPEG-jpeg, PNG-png files are allowed to upload";
            header('location:project-add.php');
        }
    } else {
        // Get file info 
        $query = "INSERT INTO mm_property_dtls(prop_title,prop_type,prop_status,prop_lebel,prop_content,sale_rent_price,second_price,prop_after_price,prop_price_prefix,prop_bedrooms,prop_rooms,prop_bathrooms,prop_area_size,prop_postfix,prop_land_area,prop_land_size,prop_car_park,prop_garage,prop_id,prop_year_built,prop_video,prop_logo,prop_develop_logo,prop_active)
            values('$prop_title','$prop_type','$prop_status','$prop_lebel','$prop_content','$sale_rent_price','$second_price','$prop_after_price','$prop_price_prefix','$prop_bedrooms','$prop_rooms','$prop_bathrooms','$prop_area_size','$prop_postfix','$prop_land_area','$prop_land_size','$prop_car_park','$prop_garage','$prop_id','$prop_year_built','$prop_video','','','$prop_active')";
        $query_run = mysqli_query($connection, $query);
        if ($query_run) {
            $_SESSION['success'] = "Project Details Add Successfully";
            header('location:project-add.php');
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG-jpg, JPEG-jpeg, PNG-png files are allowed to upload";
            header('location:project-add.php');
        }
    }

    //Image Upload End//



}

/*Modification Property Section*/
if (isset($_POST['property_dts_modification'])) {
    $property_id = mysqli_real_escape_string($connection, $_POST['property_id']);
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $prop_type = mysqli_real_escape_string($connection, $_POST['prop_type']);
    $prop_status = mysqli_real_escape_string($connection, $_POST['prop_status']);
    $prop_lebel = mysqli_real_escape_string($connection, $_POST['prop_lebel']);
    $prop_content = mysqli_real_escape_string($connection, $_POST['prop_content']);
    $sale_rent_price = mysqli_real_escape_string($connection, $_POST['sale_rent_price']);
    $second_price = "";
    $prop_after_price = "";
    $prop_price_prefix = "";
    $prop_bedrooms = mysqli_real_escape_string($connection, $_POST['prop_bedrooms']);
    $prop_rooms = mysqli_real_escape_string($connection, $_POST['prop_rooms']);
    $prop_bathrooms = mysqli_real_escape_string($connection, $_POST['prop_bathrooms']);
    $prop_area_size = mysqli_real_escape_string($connection, $_POST['prop_area_size']);
    $prop_postfix = mysqli_real_escape_string($connection, $_POST['prop_postfix']);
    $prop_land_area = mysqli_real_escape_string($connection, $_POST['prop_land_area']);
    $prop_land_size = mysqli_real_escape_string($connection, $_POST['prop_land_size']);
    $prop_car_park = mysqli_real_escape_string($connection, $_POST['prop_car_park']);
    $prop_garage = mysqli_real_escape_string($connection, $_POST['prop_garage']);
    $prop_id = mysqli_real_escape_string($connection, $_POST['prop_id']);
    $prop_year_built = mysqli_real_escape_string($connection, $_POST['prop_year_built']);
    $prop_video = mysqli_real_escape_string($connection, $_POST['prop_video']);
    $old_prop_logo = mysqli_real_escape_string($connection, $_POST['old_prop_logo']);
    $old_prop_develop_logo = mysqli_real_escape_string($connection, $_POST['old_prop_develop_logo']);

    //Image Upload start//
    if (!empty($_FILES["prop_logo"]["name"]) && !empty($_FILES["prop_develop_logo"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["prop_logo"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        $fileName1 = basename($_FILES["prop_develop_logo"]["name"]);
        $fileType1 = pathinfo($fileName1, PATHINFO_EXTENSION);

        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'WEBP', 'webp');
        if (in_array($fileType, $allowTypes) && in_array($fileType1, $allowTypes)) {
            $image = $_FILES['prop_logo']['tmp_name'];
            $extension = explode('.', $_FILES['prop_logo']['name']);
            $image_name = rand(10000, 99999) . '.' . $extension[1];
            $imgContent = addslashes(file_get_contents($image));

            $image1 = $_FILES['prop_develop_logo']['tmp_name'];
            $extension1 = explode('.', $_FILES['prop_develop_logo']['name']);
            $image_name1 = rand(10000, 99999) . '.' . $extension1[1];
            $imgContent1 = addslashes(file_get_contents($image1));

            $folder = "upload_property_file/";
            move_uploaded_file($image, $folder . $image_name);
            move_uploaded_file($image1, $folder . $image_name1);
            // Insert image content into database 
            //$query="INSERT INTO mm_floor_plan(prop_title,plan_title,floor_bed_room,floor_bath_room,floor_price,floor_price_post_fix,floor_plan_size,floor_content,plan_imgae) values 
            //('$prop_title','$plan_title','$floor_bed_room','$floor_bath_room','$floor_price','$floor_price_post_fix','$floor_plan_size','$floor_content','$image_name')";
            $query = "UPDATE mm_property_dtls SET prop_title='$prop_title',prop_type='$prop_type',prop_status='$prop_status',prop_lebel='$prop_lebel',prop_content='$prop_content',sale_rent_price='$sale_rent_price',second_price='$second_price',prop_after_price='$prop_after_price',prop_price_prefix='$prop_price_prefix',prop_bedrooms='$prop_bedrooms',prop_rooms='$prop_rooms',prop_bathrooms='$prop_bathrooms',prop_area_size='$prop_area_size',prop_postfix='$prop_postfix',prop_land_area='$prop_land_area',prop_land_size='$prop_land_size',prop_car_park='$prop_car_park',prop_garage='$prop_garage',prop_id='$prop_id',prop_year_built='$prop_year_built',prop_video='$prop_video',prop_logo='$image_name',prop_develop_logo='$image_name1' WHERE property_id='$property_id'";

            //$query="INSERT INTO mm_property_dtls(prop_title,prop_type,prop_status,prop_lebel,prop_content,sale_rent_price,second_price,prop_after_price,prop_price_prefix,prop_bedrooms,prop_rooms,prop_bathrooms,prop_area_size,prop_postfix,prop_land_area,prop_land_size,prop_car_park,prop_garage,prop_id,prop_year_built,prop_video,prop_logo,prop_develop_logo)
            //values('$prop_title','$prop_type','$prop_status','$prop_lebel','$prop_content','$sale_rent_price','$second_price','$prop_after_price','$prop_price_prefix','$prop_bedrooms','$prop_rooms','$prop_bathrooms','$prop_area_size','$prop_postfix','$prop_land_area','$prop_land_size','$prop_car_park','$prop_garage','$prop_id','$prop_year_built','$prop_video','$image_name','$image_name1')";
            $query_run = mysqli_query($connection, $query);
            if ($query_run) {
                $_SESSION['success'] = "Project Details Update Successfully";
                header('location:property-list.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG-jpg, JPEG-jpeg, PNG-png files are allowed to upload";
            header('location:property-list.php');
        }
    } else if (!empty($_FILES["prop_logo"]["name"]) && empty($_FILES["prop_develop_logo"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["prop_logo"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        //$fileName1 = basename($_FILES["prop_develop_logo"]["name"]); 
        //$fileType1 = pathinfo($fileName1, PATHINFO_EXTENSION);

        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'WEBP', 'webp');
        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['prop_logo']['tmp_name'];
            $extension = explode('.', $_FILES['prop_logo']['name']);
            $image_name = rand(10000, 99999) . '.' . $extension[1];
            $imgContent = addslashes(file_get_contents($image));

            //$image1 = $_FILES['prop_develop_logo']['tmp_name'];
            //$extension1 = explode('.', $_FILES['prop_develop_logo'] ['name']);
            //$image_name1 ="NA";
            //$imgContent1 = addslashes(file_get_contents($image1)); 

            $folder = "upload_property_file/";
            move_uploaded_file($image, $folder . $image_name);
            //move_uploaded_file($image1,$folder.$image_name1);
            // Insert image content into database 
            //$query="INSERT INTO mm_floor_plan(prop_title,plan_title,floor_bed_room,floor_bath_room,floor_price,floor_price_post_fix,floor_plan_size,floor_content,plan_imgae) values 
            //('$prop_title','$plan_title','$floor_bed_room','$floor_bath_room','$floor_price','$floor_price_post_fix','$floor_plan_size','$floor_content','$image_name')";
            //$query="INSERT INTO mm_property_dtls(prop_title,prop_type,prop_status,prop_lebel,prop_content,sale_rent_price,second_price,prop_after_price,prop_price_prefix,prop_bedrooms,prop_rooms,prop_bathrooms,prop_area_size,prop_postfix,prop_land_area,prop_land_size,prop_car_park,prop_garage,prop_id,prop_year_built,prop_video,prop_logo,prop_develop_logo)
            //values('$prop_title','$prop_type','$prop_status','$prop_lebel','$prop_content','$sale_rent_price','$second_price','$prop_after_price','$prop_price_prefix','$prop_bedrooms','$prop_rooms','$prop_bathrooms','$prop_area_size','$prop_postfix','$prop_land_area','$prop_land_size','$prop_car_park','$prop_garage','$prop_id','$prop_year_built','$prop_video','$image_name','')";
            $query = "UPDATE mm_property_dtls SET prop_title='$prop_title',prop_type='$prop_type',prop_status='$prop_status',prop_lebel='$prop_lebel',prop_content='$prop_content',sale_rent_price='$sale_rent_price',second_price='$second_price',prop_after_price='$prop_after_price',prop_price_prefix='$prop_price_prefix',prop_bedrooms='$prop_bedrooms',prop_rooms='$prop_rooms',prop_bathrooms='$prop_bathrooms',prop_area_size='$prop_area_size',prop_postfix='$prop_postfix',prop_land_area='$prop_land_area',prop_land_size='$prop_land_size',prop_car_park='$prop_car_park',prop_garage='$prop_garage',prop_id='$prop_id',prop_year_built='$prop_year_built',prop_video='$prop_video',prop_logo='$image_name',prop_develop_logo='$old_prop_develop_logo' WHERE property_id='$property_id'";

            $query_run = mysqli_query($connection, $query);
            if ($query_run) {
                $_SESSION['success'] = "Project Details Update Successfully";
                header('location:property-list.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG-jpg, JPEG-jpeg, PNG-png files are allowed to upload";
            header('location:property-list.php');
        }
    } else if (empty($_FILES["prop_logo"]["name"]) && !empty($_FILES["prop_develop_logo"]["name"])) {
        // Get file info 
        //$fileName = basename($_FILES["prop_logo"]["name"]); 
        //$fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        $fileName1 = basename($_FILES["prop_develop_logo"]["name"]);
        $fileType1 = pathinfo($fileName1, PATHINFO_EXTENSION);

        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'WEBP', 'webp');
        if (in_array($fileType1, $allowTypes)) {
            //$image = $_FILES['prop_logo']['tmp_name'];
            //$extension = explode('.', $_FILES['prop_logo'] ['name']);
            //$image_name = rand(10000,99999) . '.' . $extension[1];
            //$imgContent = addslashes(file_get_contents($image)); 

            $image1 = $_FILES['prop_develop_logo']['tmp_name'];
            $extension1 = explode('.', $_FILES['prop_develop_logo']['name']);
            $image_name1 = rand(10000, 99999) . '.' . $extension1[1];
            $imgContent1 = addslashes(file_get_contents($image1));

            $folder = "upload_property_file/";
            //move_uploaded_file($image,$folder.$image_name);
            move_uploaded_file($image1, $folder . $image_name1);
            // Insert image content into database 
            //$query="INSERT INTO mm_floor_plan(prop_title,plan_title,floor_bed_room,floor_bath_room,floor_price,floor_price_post_fix,floor_plan_size,floor_content,plan_imgae) values 
            //('$prop_title','$plan_title','$floor_bed_room','$floor_bath_room','$floor_price','$floor_price_post_fix','$floor_plan_size','$floor_content','$image_name')";
            //$query="INSERT INTO mm_property_dtls(prop_title,prop_type,prop_status,prop_lebel,prop_content,sale_rent_price,second_price,prop_after_price,prop_price_prefix,prop_bedrooms,prop_rooms,prop_bathrooms,prop_area_size,prop_postfix,prop_land_area,prop_land_size,prop_car_park,prop_garage,prop_id,prop_year_built,prop_video,prop_logo,prop_develop_logo)
            //values('$prop_title','$prop_type','$prop_status','$prop_lebel','$prop_content','$sale_rent_price','$second_price','$prop_after_price','$prop_price_prefix','$prop_bedrooms','$prop_rooms','$prop_bathrooms','$prop_area_size','$prop_postfix','$prop_land_area','$prop_land_size','$prop_car_park','$prop_garage','$prop_id','$prop_year_built','$prop_video','','$image_name1')";
            $query = "UPDATE mm_property_dtls SET prop_title='$prop_title',prop_type='$prop_type',prop_status='$prop_status',prop_lebel='$prop_lebel',prop_content='$prop_content',sale_rent_price='$sale_rent_price',second_price='$second_price',prop_after_price='$prop_after_price',prop_price_prefix='$prop_price_prefix',prop_bedrooms='$prop_bedrooms',prop_rooms='$prop_rooms',prop_bathrooms='$prop_bathrooms',prop_area_size='$prop_area_size',prop_postfix='$prop_postfix',prop_land_area='$prop_land_area',prop_land_size='$prop_land_size',prop_car_park='$prop_car_park',prop_garage='$prop_garage',prop_id='$prop_id',prop_year_built='$prop_year_built',prop_video='$prop_video',prop_logo='$old_prop_logo',prop_develop_logo='$image_name1' WHERE property_id='$property_id'";

            $query_run = mysqli_query($connection, $query);
            if ($query_run) {
                $_SESSION['success'] = "Project Details Update Successfully";
                header('location:property-list.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG-jpg, JPEG-jpeg, PNG-png files are allowed to upload";
            header('location:property-list.php');
        }
    } else {
        // Get file info 
        //$query="INSERT INTO mm_property_dtls(prop_title,prop_type,prop_status,prop_lebel,prop_content,sale_rent_price,second_price,prop_after_price,prop_price_prefix,prop_bedrooms,prop_rooms,prop_bathrooms,prop_area_size,prop_postfix,prop_land_area,prop_land_size,prop_car_park,prop_garage,prop_id,prop_year_built,prop_video,prop_logo,prop_develop_logo)
        //values('$prop_title','$prop_type','$prop_status','$prop_lebel','$prop_content','$sale_rent_price','$second_price','$prop_after_price','$prop_price_prefix','$prop_bedrooms','$prop_rooms','$prop_bathrooms','$prop_area_size','$prop_postfix','$prop_land_area','$prop_land_size','$prop_car_park','$prop_garage','$prop_id','$prop_year_built','$prop_video','','')";
        $query = "UPDATE mm_property_dtls SET prop_title='$prop_title',prop_type='$prop_type',prop_status='$prop_status',prop_lebel='$prop_lebel',prop_content='$prop_content',sale_rent_price='$sale_rent_price',second_price='$second_price',prop_after_price='$prop_after_price',prop_price_prefix='$prop_price_prefix',prop_bedrooms='$prop_bedrooms',prop_rooms='$prop_rooms',prop_bathrooms='$prop_bathrooms',prop_area_size='$prop_area_size',prop_postfix='$prop_postfix',prop_land_area='$prop_land_area',prop_land_size='$prop_land_size',prop_car_park='$prop_car_park',prop_garage='$prop_garage',prop_id='$prop_id',prop_year_built='$prop_year_built',prop_video='$prop_video',prop_logo='$old_prop_logo',prop_develop_logo='$old_prop_develop_logo' WHERE property_id='$property_id'";

        $query_run = mysqli_query($connection, $query);
        if ($query_run) {
            $_SESSION['success'] = "Project Details Update Successfully";
            header('location:property-list.php');
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG-jpg, JPEG-jpeg, PNG-png files are allowed to upload";
            header('location:property-list.php');
        }
    }

    //Image Upload End//
}

/*Banner Delete Section */


if (isset($_GET['prop_delete_id'])) {
    //$sql_query="DELETE FROM users WHERE user_id=".$_GET['delete_id'];
    $query = "DELETE  FROM mm_property_dtls  WHERE property_id=" . $_GET['prop_delete_id'];

    $query_run = mysqli_query($connection, $query);

    if ($query_run) {

        $_SESSION['success'] = "Property Details Deleted";
        header('Location: property-list.php');

    } else {

        $_SESSION['status'] = "Lead Details Not Deleted";
        header('Location: property-list.php');

    }

}

/* Check Box Entry */

if (isset($_POST["property_aminities_dts_add"])) {
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $aminities_name = $_POST['aminities_name'];
    foreach ($aminities_name as $i) {
        $aminities_name = $i;

        $query = "INSERT INTO mm_aminities(prop_title,aminities_name,prop_active) values 
             ('$prop_title','$aminities_name','U')";
        $query_run = mysqli_query($connection, $query);
        if ($query_run) {
            $_SESSION['success'] = "Project Amenities Add Successfully";
            header('location:project-aminities-add.php');
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Amenities Add Not Successfull";
            header('location:project-aminities-add.php');
        }
    }
}

/* Check Box Entry */

if (isset($_POST["property_aminities_dts_update"])) {
    $aminities_id = mysqli_real_escape_string($connection, $_POST['aminities_id']);
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $aminities_name = mysqli_real_escape_string($connection, $_POST['aminities_name']);
    $old_aminities_logo = mysqli_real_escape_string($connection, $_POST['old_aminities_logo']);
    //$old_attachment_file= $_POST['old_attachment_file'];

    if (!empty($_FILES["aminities_logo"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["aminities_logo"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG');
        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['aminities_logo']['tmp_name'];
            $extension = explode('.', $_FILES['aminities_logo']['name']);
            $image_name = rand(10000, 99999) . '.' . $extension[1];
            $imgContent = addslashes(file_get_contents($image));
            $folder = "upload_aminites_file/";
            move_uploaded_file($image, $folder . $image_name);
            // Insert image content into database 
            $query = "UPDATE mm_aminities SET prop_title='$prop_title',aminities_name='$aminities_name',aminities_logo='$image_name' WHERE aminities_id='$aminities_id'";
            $query_run = mysqli_query($connection, $query);

            if ($query_run) {
                $_SESSION['success'] = "Project Aminities Update Successfully";
                header('location:aminities-list.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG, JPEG, PNG files are allowed to upload";
            header('location:aminities-list.php');
        }
    } else {
        if (empty($_FILES["aminities_logo"]["name"])) {
            $update_file_name1 = $old_aminities_logo;
        }

        //$query="UPDATE mm SET attachment_file='$update_file_name1' WHERE sl_no='$sl_hid_id'";
        //$query="UPDATE mm_banner SET banner_title1='$banner_title1',banner_title2='$banner_title2',banner_image='$update_file_name1' WHERE banner_id='$banner_id'";
        //$query="UPDATE mm_floor_plan SET prop_title='$prop_title',plan_title='$plan_title',floor_bed_room='$floor_bed_room',floor_bath_room='$floor_bath_room',floor_price='$floor_price',floor_price_post_fix='$floor_price_post_fix',floor_plan_size='$floor_plan_size',floor_content='$floor_content',plan_imgae='$update_file_name1' WHERE floor_plan_id='$floor_plan_id'";
        $query = "UPDATE mm_aminities SET prop_title='$prop_title',aminities_name='$aminities_name',aminities_logo='$update_file_name1' WHERE aminities_id='$aminities_id'";
        $query_run = mysqli_query($connection, $query);
        if ($query_run) {

            $_SESSION['success'] = "Project Aminities Update Successfully";
            header('location:aminities-list.php');
        } else {
            $_SESSION['success'] = "Not Successful";
            header('location:aminities-list.php');
        }

    }

}

// Delete section for aminities//

if (isset($_GET['aminities_delete_id'])) {
    //$sql_query="DELETE FROM users WHERE user_id=".$_GET['delete_id'];
    $query = "DELETE  FROM mm_aminities  WHERE aminities_id=" . $_GET['aminities_delete_id'];

    $query_run = mysqli_query($connection, $query);

    if ($query_run) {

        $_SESSION['success'] = "Aminities Details Deleted";
        header('Location: aminities-list.php');

    } else {

        $_SESSION['status'] = "Aminities Details Not Deleted";
        header('Location: aminities-list.php');

    }

}


/* Floor Section Entry*/

if (isset($_POST["floor_dts_add"])) {
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $plan_title = mysqli_real_escape_string($connection, $_POST['plan_title']);
    $floor_bed_room = mysqli_real_escape_string($connection, $_POST['floor_bed_room']);
    $floor_bath_room = mysqli_real_escape_string($connection, $_POST['floor_bath_room']);
    $floor_price = mysqli_real_escape_string($connection, $_POST['floor_price']);
    $floor_price_post_fix = mysqli_real_escape_string($connection, $_POST['floor_price_post_fix']);
    $floor_plan_size = mysqli_real_escape_string($connection, $_POST['floor_plan_size']);
    $floor_content = mysqli_real_escape_string($connection, $_POST['floor_content']);
    //$ord_dt=mysqli_real_escape_string($connection,$_POST['banner_img']);
    if (!empty($_FILES["plan_imgae"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["plan_imgae"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'WEBP', 'webp');
        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['plan_imgae']['tmp_name'];
            $extension = explode('.', $_FILES['plan_imgae']['name']);
            $image_name = rand(10000, 99999) . '.' . $extension[1];
            $imgContent = addslashes(file_get_contents($image));
            $folder = "upload_floor_file/";
            move_uploaded_file($image, $folder . $image_name);
            // Insert image content into database 
            $query = "INSERT INTO mm_floor_plan(prop_title,plan_title,floor_bed_room,floor_bath_room,floor_price,floor_price_post_fix,floor_plan_size,floor_content,plan_imgae,prop_active) values 
                ('$prop_title','$plan_title','$floor_bed_room','$floor_bath_room','$floor_price','$floor_price_post_fix','$floor_plan_size','$floor_content','$image_name','U')";
            $query_run = mysqli_query($connection, $query);
            if ($query_run) {
                $_SESSION['success'] = "Floor Plan Add Successfully";
                header('location:floor-plan-add.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG-jpg, JPEG-jpeg, PNG-png files are allowed to upload";
            header('location:floor-plan-add.php');
        }
    }

}


/* Floor Plan Update Section */

if (isset($_POST['floor_dts_modify'])) {
    $floor_plan_id = mysqli_real_escape_string($connection, $_POST['floor_plan_id']);
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $plan_title = mysqli_real_escape_string($connection, $_POST['plan_title']);
    $floor_bed_room = mysqli_real_escape_string($connection, $_POST['floor_bed_room']);
    $floor_bath_room = mysqli_real_escape_string($connection, $_POST['floor_bath_room']);
    $floor_price = mysqli_real_escape_string($connection, $_POST['floor_price']);
    $floor_price_post_fix = mysqli_real_escape_string($connection, $_POST['floor_price_post_fix']);
    $floor_plan_size = mysqli_real_escape_string($connection, $_POST['floor_plan_size']);
    $floor_content = mysqli_real_escape_string($connection, $_POST['floor_content']);
    $old_plan_imgae = mysqli_real_escape_string($connection, $_POST['old_plan_imgae']);
    //$old_attachment_file= $_POST['old_attachment_file'];

    if (!empty($_FILES["plan_imgae"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["plan_imgae"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'webp', 'WEBP');
        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['plan_imgae']['tmp_name'];
            $extension = explode('.', $_FILES['plan_imgae']['name']);
            $image_name = rand(10000, 99999) . '.' . $extension[1];
            $imgContent = addslashes(file_get_contents($image));
            $folder = "upload_floor_file/";
            move_uploaded_file($image, $folder . $image_name);
            // Insert image content into database 
            $query = "UPDATE mm_floor_plan SET prop_title='$prop_title',plan_title='$plan_title',floor_bed_room='$floor_bed_room',floor_bath_room='$floor_bath_room',floor_price='$floor_price',floor_price_post_fix='$floor_price_post_fix',floor_plan_size='$floor_plan_size',floor_content='$floor_content',plan_imgae='$image_name' WHERE floor_plan_id='$floor_plan_id'";
            $query_run = mysqli_query($connection, $query);

            if ($query_run) {
                $_SESSION['success'] = "Floor Plan Update Successfully";
                header('location:floor-plan-list.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG, JPEG, PNG files are allowed to upload";
            header('location:floor-plan-list.php');
        }
    } else {
        if (empty($_FILES["plan_imgae"]["name"])) {
            $update_file_name1 = $old_plan_imgae;
        }

        //$query="UPDATE mm SET attachment_file='$update_file_name1' WHERE sl_no='$sl_hid_id'";
        //$query="UPDATE mm_banner SET banner_title1='$banner_title1',banner_title2='$banner_title2',banner_image='$update_file_name1' WHERE banner_id='$banner_id'";
        $query = "UPDATE mm_floor_plan SET prop_title='$prop_title',plan_title='$plan_title',floor_bed_room='$floor_bed_room',floor_bath_room='$floor_bath_room',floor_price='$floor_price',floor_price_post_fix='$floor_price_post_fix',floor_plan_size='$floor_plan_size',floor_content='$floor_content',plan_imgae='$update_file_name1' WHERE floor_plan_id='$floor_plan_id'";

        $query_run = mysqli_query($connection, $query);
        if ($query_run) {

            $_SESSION['success'] = "Floor Plan Update Successfully";
            header('location:floor-plan-list.php');
        } else {
            $_SESSION['success'] = "Not Successful";
            header('location:floor-plan-list.php');
        }

    }

}

// Delete section for Floor Plan//

if (isset($_GET['floor_delete_id'])) {
    //$sql_query="DELETE FROM users WHERE user_id=".$_GET['delete_id'];
    $query = "DELETE  FROM mm_floor_plan  WHERE floor_plan_id=" . $_GET['floor_delete_id'];

    $query_run = mysqli_query($connection, $query);

    if ($query_run) {

        $_SESSION['success'] = "Floor Plan Details Deleted";
        header('Location: floor-plan-list.php');

    } else {

        $_SESSION['status'] = "Floor Details Not Deleted";
        header('Location: floor-plan-list.php');

    }

}

/*Master Plan Section */

if (isset($_POST["master_plan_dts_add"])) {
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    //$ord_dt=mysqli_real_escape_string($connection,$_POST['banner_img']);
    if (!empty($_FILES["master_plan_imgae"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["master_plan_imgae"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'WEBP', 'webp');
        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['master_plan_imgae']['tmp_name'];
            $extension = explode('.', $_FILES['master_plan_imgae']['name']);
            $image_name = rand(10000, 99999) . '.' . $extension[1];
            $imgContent = addslashes(file_get_contents($image));
            $folder = "upload_master_file/";
            move_uploaded_file($image, $folder . $image_name);
            // Insert image content into database 
            $query = "INSERT INTO mm_master_plan(prop_title,master_plan_imgae,prop_active) values 
                ('$prop_title','$image_name','U')";
            $query_run = mysqli_query($connection, $query);
            if ($query_run) {
                $_SESSION['success'] = "Master Plan Add Successfully";
                header('location:master-plan-add.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG-jpg, JPEG-jpeg, PNG-png files are allowed to upload";
            header('location:master-plan-add.php');
        }
    }

}


/* Floor Plan Update Section */

if (isset($_POST['master_dts_modify'])) {
    $master_plan_id = mysqli_real_escape_string($connection, $_POST['master_plan_id']);
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $old_master_plan_imgae = mysqli_real_escape_string($connection, $_POST['old_master_plan_imgae']);
    //$old_attachment_file= $_POST['old_attachment_file'];

    if (!empty($_FILES["master_plan_imgae"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["master_plan_imgae"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'webp', 'WEBP');
        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['master_plan_imgae']['tmp_name'];
            $extension = explode('.', $_FILES['master_plan_imgae']['name']);
            $image_name = rand(10000, 99999) . '.' . $extension[1];
            $imgContent = addslashes(file_get_contents($image));
            $folder = "upload_master_file/";
            move_uploaded_file($image, $folder . $image_name);
            // Insert image content into database 
            $query = "UPDATE mm_master_plan SET prop_title='$prop_title',master_plan_imgae='$image_name' WHERE master_plan_id='$master_plan_id'";
            $query_run = mysqli_query($connection, $query);

            if ($query_run) {
                $_SESSION['success'] = "Master Plan Update Successfully";
                header('location:master-plan-list.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG, JPEG, PNG files are allowed to upload";
            header('location:master-plan-list.php');
        }
    } else {
        if (empty($_FILES["master_plan_imgae"]["name"])) {
            $update_file_name1 = $old_master_plan_imgae;
        }

        //$query="UPDATE mm SET attachment_file='$update_file_name1' WHERE sl_no='$sl_hid_id'";
        //$query="UPDATE mm_banner SET banner_title1='$banner_title1',banner_title2='$banner_title2',banner_image='$update_file_name1' WHERE banner_id='$banner_id'";
        $query = "UPDATE mm_master_plan SET prop_title='$prop_title',master_plan_imgae='$update_file_name1' WHERE master_plan_id='$master_plan_id'";

        $query_run = mysqli_query($connection, $query);
        if ($query_run) {

            $_SESSION['success'] = "Master Plan Update Successfully";
            header('location:master-plan-list.php');
        } else {
            $_SESSION['success'] = "Not Successful";
            header('location:master-plan-list.php');
        }

    }

}

// Delete section for Floor Plan//

if (isset($_GET['master_delete_id'])) {
    //$sql_query="DELETE FROM users WHERE user_id=".$_GET['delete_id'];
    $query = "DELETE  FROM mm_master_plan  WHERE master_plan_id=" . $_GET['master_delete_id'];

    $query_run = mysqli_query($connection, $query);

    if ($query_run) {

        $_SESSION['success'] = "Master Plan Details Deleted";
        header('Location: master-plan-list.php');

    } else {

        $_SESSION['status'] = "Master Details Not Deleted";
        header('Location: master-plan-list.php');

    }

}

/*Sub Listing Section*/

if (isset($_POST["sublisting_dts_add"])) {
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $sub_title = mysqli_real_escape_string($connection, $_POST['sub_title']);
    $sub_title_bedroom = mysqli_real_escape_string($connection, $_POST['sub_title_bedroom']);
    $sub_title_bathroom = mysqli_real_escape_string($connection, $_POST['sub_title_bathroom']);
    $sub_title_prop_size = mysqli_real_escape_string($connection, $_POST['sub_title_prop_size']);
    $sub_title_size_postfix = mysqli_real_escape_string($connection, $_POST['sub_title_size_postfix']);
    $sub_title_price = mysqli_real_escape_string($connection, $_POST['sub_title_price']);
    $sub_title_price_postfix = mysqli_real_escape_string($connection, $_POST['sub_title_price_postfix']);
    $sub_title_prop_type = mysqli_real_escape_string($connection, $_POST['sub_title_prop_type']);
    $sub_title_ave_date = mysqli_real_escape_string($connection, $_POST['sub_title_ave_date']);
    $query = "INSERT INTO mm_sublisting(prop_title,sub_title,sub_title_bedroom,sub_title_bathroom,sub_title_prop_size,sub_title_size_postfix,sub_title_price,sub_title_price_postfix,sub_title_prop_type,sub_title_ave_date)
               values('$prop_title','$sub_title','$sub_title_bedroom','$sub_title_bathroom','$sub_title_prop_size','$sub_title_size_postfix','$sub_title_price','$sub_title_price_postfix','$sub_title_prop_type','$sub_title_ave_date')";
    $query_run = mysqli_query($connection, $query);
    if ($query_run) {
        $_SESSION['success'] = "Project Sublisting Details Add Successfully";
        header('location:sublisting-project-add.php');
    } else {
        //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
        $_SESSION['status'] = "Sublisting Not Add";
        header('location:sublisting-project-add.php');
    }


}

/*Modification Property Section*/
if (isset($_POST['sublisting_dts_modify'])) {
    $sublisting_id = mysqli_real_escape_string($connection, $_POST['sublisting_id']);
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $sub_title = mysqli_real_escape_string($connection, $_POST['sub_title']);
    $sub_title_bedroom = mysqli_real_escape_string($connection, $_POST['sub_title_bedroom']);
    $sub_title_bathroom = mysqli_real_escape_string($connection, $_POST['sub_title_bathroom']);
    $sub_title_prop_size = mysqli_real_escape_string($connection, $_POST['sub_title_prop_size']);
    $sub_title_size_postfix = mysqli_real_escape_string($connection, $_POST['sub_title_size_postfix']);
    $sub_title_price = mysqli_real_escape_string($connection, $_POST['sub_title_price']);
    $sub_title_price_postfix = mysqli_real_escape_string($connection, $_POST['sub_title_price_postfix']);
    $sub_title_prop_type = mysqli_real_escape_string($connection, $_POST['sub_title_prop_type']);
    $sub_title_ave_date = mysqli_real_escape_string($connection, $_POST['sub_title_ave_date']);
    $query = "UPDATE mm_sublisting SET prop_title='$prop_title',sub_title='$sub_title',sub_title_bedroom='$sub_title_bedroom',sub_title_bathroom='$sub_title_bathroom',sub_title_prop_size='$sub_title_prop_size',sub_title_size_postfix='$sub_title_size_postfix',sub_title_price='$sub_title_price',sub_title_price_postfix='$sub_title_price_postfix',sub_title_prop_type='$sub_title_prop_type',sub_title_ave_date='$sub_title_ave_date' WHERE sublisting_id='$sublisting_id'";
    $query_run = mysqli_query($connection, $query);
    if ($query_run) {
        $_SESSION['success'] = "Sublisting Property Details Update Successfully";
        header('location:sublisting-list.php');
    } else {
        //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
        $_SESSION['status'] = "SublistingProperty Details Update Not Successfully";
        header('location:sublisting-list.php');
    }

}

/*Banner Delete Section */


if (isset($_GET['sublisting_delete_id'])) {
    //$sql_query="DELETE FROM users WHERE user_id=".$_GET['delete_id'];
    $query = "DELETE  FROM mm_sublisting  WHERE sublisting_id=" . $_GET['sublisting_delete_id'];

    $query_run = mysqli_query($connection, $query);

    if ($query_run) {

        $_SESSION['success'] = "Sublisting Property Details Deleted";
        header('Location: sublisting-list.php');

    } else {

        $_SESSION['status'] = "Sublisting Details Not Deleted";
        header('Location: sublisting-list.php');

    }

}

/*Location Section Entry Update Delete */

if (isset($_POST["location_dts_add"])) {
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $location_address = mysqli_real_escape_string($connection, $_POST['location_address']);
    $location_country = mysqli_real_escape_string($connection, $_POST['location_country']);
    $location_state = mysqli_real_escape_string($connection, $_POST['location_state']);
    $location_city = mysqli_real_escape_string($connection, $_POST['location_city']);
    $location_area = mysqli_real_escape_string($connection, $_POST['location_area']);
    $location_pin_code = mysqli_real_escape_string($connection, $_POST['location_pin_code']);
    $location_map = mysqli_real_escape_string($connection, $_POST['location_map']);
    $location_advantage = mysqli_real_escape_string($connection, $_POST['location_advantage']);
    $query = "INSERT INTO mm_location(prop_title,location_address,location_country,location_state,location_city,location_area,location_pin_code,location_map,location_advantage,prop_active)
               values('$prop_title','$location_address','$location_country','$location_state','$location_city','$location_area','$location_pin_code','$location_map','$location_advantage','U')";
    $query_run = mysqli_query($connection, $query);
    if ($query_run) {
        $_SESSION['success'] = "Project Location Add Successfully";
        header('location:location-add.php');
    } else {
        //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
        $_SESSION['status'] = "Sublisting Not Add";
        header('location:location-add.php');
    }


}

/*Modification Property Section*/
if (isset($_POST['location_dts_modify'])) {
    $location_id = mysqli_real_escape_string($connection, $_POST['location_id']);
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $location_address = mysqli_real_escape_string($connection, $_POST['location_address']);
    $location_country = mysqli_real_escape_string($connection, $_POST['location_country']);
    $location_state = mysqli_real_escape_string($connection, $_POST['location_state']);
    $location_city = mysqli_real_escape_string($connection, $_POST['location_city']);
    $location_area = mysqli_real_escape_string($connection, $_POST['location_area']);
    $location_pin_code = mysqli_real_escape_string($connection, $_POST['location_pin_code']);
    $location_map = mysqli_real_escape_string($connection, $_POST['location_map']);
    $location_advantage = mysqli_real_escape_string($connection, $_POST['location_advantage']);
    $query = "UPDATE mm_location SET prop_title='$prop_title',location_address='$location_address',location_country='$location_country',location_state='$location_state',location_city='$location_city',location_area='$location_area',location_pin_code='$location_pin_code',location_map='$location_map',location_advantage='$location_advantage' WHERE location_id='$location_id'";
    $query_run = mysqli_query($connection, $query);
    if ($query_run) {
        $_SESSION['success'] = "Property Location Details Update Successfully";
        header('location:location-list.php');
    } else {
        //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
        $_SESSION['status'] = "Location Details Update Not Successfully";
        header('location:location-list.php');
    }

}

/*Banner Delete Section */


if (isset($_GET['location_delete_id'])) {
    //$sql_query="DELETE FROM users WHERE user_id=".$_GET['delete_id'];
    $query = "DELETE  FROM mm_location  WHERE location_id=" . $_GET['location_delete_id'];

    $query_run = mysqli_query($connection, $query);

    if ($query_run) {

        $_SESSION['success'] = "Property Location Details Deleted";
        header('Location: location-list.php');

    } else {

        $_SESSION['status'] = "Sublisting Details Not Deleted";
        header('Location: location-list.php');

    }

}

/*Image Section Upload Work*/

if (isset($_POST['uploadImageBtn'])) {
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $uploadFolder = 'uploads/';
    foreach ($_FILES['imageFile']['tmp_name'] as $key => $image) {
        $imageTmpName = $_FILES['imageFile']['tmp_name'][$key];
        $imageName = $_FILES['imageFile']['name'][$key];
        $extension = explode('.', $_FILES['imageFile']['name'][$key]);
        $image_name = rand(10000, 99999) . '.' . $extension[1];
        $result = move_uploaded_file($imageTmpName, $uploadFolder . $image_name);

        // save to database
        $query = "INSERT INTO mm_media SET img_name='$image_name',prop_title='$prop_title',prop_active='U'";
        $run = $connection->query($query) or die("Error in saving image" . $connection->error);
    }
    if ($result) {
        echo '<script>alert("Images uploaded successfully !")</script>';
        echo '<script>window.location.href="project-media-add.php";</script>';
    }
}

/* Floor Plan Update Section */

if (isset($_POST['media_dts_modify'])) {
    $media_id = mysqli_real_escape_string($connection, $_POST['media_id']);
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $old_media_imgae = mysqli_real_escape_string($connection, $_POST['old_media_imgae']);
    //$old_attachment_file= $_POST['old_attachment_file'];

    if (!empty($_FILES["media_imgae"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["media_imgae"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'WEBP', 'webp');
        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['media_imgae']['tmp_name'];
            $extension = explode('.', $_FILES['media_imgae']['name']);
            $image_name = rand(10000, 99999) . '.' . $extension[1];
            $imgContent = addslashes(file_get_contents($image));
            $folder = "uploads/";
            move_uploaded_file($image, $folder . $image_name);
            // Insert image content into database 
            $query = "UPDATE mm_media SET prop_title='$prop_title',img_name='$image_name' WHERE media_id='$media_id'";
            $query_run = mysqli_query($connection, $query);

            if ($query_run) {
                $_SESSION['success'] = "Media Update Successfully";
                header('location:media-list.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG, JPEG, PNG files are allowed to upload";
            header('location:media-list.php.php');
        }
    } else {
        if (empty($_FILES["media_imgae"]["name"])) {
            $update_file_name1 = $old_media_imgae;
        }

        //$query="UPDATE mm SET attachment_file='$update_file_name1' WHERE sl_no='$sl_hid_id'";
        //$query="UPDATE mm_banner SET banner_title1='$banner_title1',banner_title2='$banner_title2',banner_image='$update_file_name1' WHERE banner_id='$banner_id'";
        $query = "UPDATE mm_media SET prop_title='$prop_title',img_name='$update_file_name1' WHERE media_id='$media_id'";

        $query_run = mysqli_query($connection, $query);
        if ($query_run) {

            $_SESSION['success'] = "Media Update Successfully";
            header('location:media-list.php');
        } else {
            $_SESSION['success'] = "Not Successful";
            header('location:media-list.php');
        }

    }

}

// Delete section for Floor Plan//

if (isset($_GET['media_delete_id'])) {
    //$sql_query="DELETE FROM users WHERE user_id=".$_GET['delete_id'];
    $query = "DELETE  FROM mm_media  WHERE media_id=" . $_GET['media_delete_id'];

    $query_run = mysqli_query($connection, $query);

    if ($query_run) {

        $_SESSION['success'] = "This Media Details Deleted";
        header('Location: media-list.php');

    } else {

        $_SESSION['status'] = "Media Details Not Deleted";
        header('Location: media-list.php');

    }

}

/* Check Box Entry */

if (isset($_POST["icon_aminities_dts_add"])) {
    $aminities_name = mysqli_real_escape_string($connection, $_POST['aminities_name']);
    //$ord_dt=mysqli_real_escape_string($connection,$_POST['banner_img']);
    if (!empty($_FILES["aminities_logo"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["aminities_logo"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'WEBP', 'webp');
        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['aminities_logo']['tmp_name'];
            $extension = explode('.', $_FILES['aminities_logo']['name']);
            $image_name = rand(10000, 99999) . '.' . $extension[1];
            $imgContent = addslashes(file_get_contents($image));
            $folder = "upload_aminites_file/";
            move_uploaded_file($image, $folder . $image_name);
            // Insert image content into database 
            $query = "INSERT INTO mm_icon(aminities_name,aminities_logo) values 
             ('$aminities_name','$image_name')";
            $query_run = mysqli_query($connection, $query);
            if ($query_run) {
                $_SESSION['success'] = "Project Aminites Add Successfully";
                header('location:icon-upload.php');
            }
        } else {
            //$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            $_SESSION['status'] = "Sorry, only JPG-jpg, JPEG-jpeg, PNG-png files are allowed to upload";
            header('location:project-aminities-add.php');
        }
    }

}

/* Check Box Entry */


//========================= new agent entry section ===============================
if (isset($_POST["agent_new_add"])) {
    // Database connection
    include('db_connection.php'); // Adjust the connection file as needed

    // Retrieve form data and sanitize inputs
    $agent_name = mysqli_real_escape_string($connection, $_POST['agent_name']);
    $agent_code = mysqli_real_escape_string($connection, $_POST['agent_code']);
    $agent_mob = mysqli_real_escape_string($connection, $_POST['agent_mob']);
    $agent_wapp = mysqli_real_escape_string($connection, $_POST['agent_wapp']);
    $agent_mail = mysqli_real_escape_string($connection, $_POST['agent_mail']);
    $agent_photo = "";

    // Check if the agent_code already exists
    $checkQuery = "SELECT * FROM mm_agents WHERE agent_code = '$agent_code'";
    $result = mysqli_query($connection, $checkQuery);

    if (mysqli_num_rows($result) > 0) {
        // If agent code exists, return an error message
        $_SESSION['status'] = "Error! An agent with the same agent code exists.";
        header('location:agent-update.php'); // Adjust the redirect page
        exit();
    }

    // Handle file upload (profile photo)
    if (!empty($_FILES["agent_profile_photo"]["name"])) {
        $fileName = basename($_FILES["agent_profile_photo"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);

        // Allowed file formats
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'WEBP', 'webp');

        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['agent_profile_photo']['tmp_name'];
            $extension = explode('.', $_FILES['agent_profile_photo']['name']);
            $agent_photo = rand(10000, 99999) . '.' . $extension[1];

            $folder = "upload_agent_photos/";
            move_uploaded_file($image, $folder . $agent_photo);
        } else {
            $_SESSION['status'] = "Sorry, only JPG, JPEG, PNG, or WEBP files are allowed.";
            header('location:agent-list.php'); // Adjust the redirect page
            exit();
        }
    }

    // Prepare SQL query to insert/update data
    $query = "INSERT INTO mm_agents (agent_name, agent_code, agent_mob, agent_mail, agent_wapp, agent_photo) 
                  VALUES ('$agent_name', '$agent_code', '$agent_mob', '$agent_mail', '$agent_wapp', '$agent_photo')
                  ON DUPLICATE KEY UPDATE 
                  agent_name = VALUES(agent_name),
                  agent_code = VALUES(agent_code),
                  agent_photo = CASE 
                                  WHEN VALUES(agent_photo) != '' THEN VALUES(agent_photo) 
                                  ELSE agent_photo 
                                END";

    // Execute query
    if (mysqli_query($connection, $query)) {
        $_SESSION['success'] = "Agent details updated successfully.";
        header('location:agent-list.php'); // Adjust the redirect page
    } else {
        $_SESSION['status'] = "Error updating agent details: " . mysqli_error($connection);
        header('location:agent-list.php'); // Adjust the redirect page
    }
}

//agent details update logic
if (isset($_POST['agent_modification'])) {
    // Retrieve form data
    $agent_id = mysqli_real_escape_string($connection, $_POST['agent_id']);
    $agent_name = mysqli_real_escape_string($connection, $_POST['agent_name']);
    $agent_code = mysqli_real_escape_string($connection, $_POST['agent_code']);
    $agent_photo = $_POST['old_agent_image']; // Keep the old image by default

    // Check if the agent_code already exists
    $checkQuery = "SELECT * FROM mm_agents WHERE agent_code = '$agent_code'";
    $result = mysqli_query($connection, $checkQuery);

    if (mysqli_num_rows($result) > 0) {
        // If agent code exists, return an error message
        $_SESSION['status'] = "Error! An agent with the same agent code exists.";
        header('location:agent-list.php'); // Adjust the redirect page
        exit();
    }

    // Handle the file upload (new image for agent)
    if (!empty($_FILES['agent_image']['name'])) {
        $fileName = basename($_FILES["agent_image"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);

        // Allowed file formats
        $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG', 'WEBP', 'webp');

        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['agent_image']['tmp_name'];
            $extension = explode('.', $_FILES['agent_image']['name']);
            $agent_photo = rand(10000, 99999) . '.' . $extension[1]; // Unique file name

            $folder = "upload_agent_photos/";
            move_uploaded_file($image, $folder . $agent_photo); // Move uploaded file to target folder

            // Optionally delete the old image if the file is replaced
            $old_image = $_POST['old_agent_image'];
            if ($old_image && file_exists($folder . $old_image)) {
                unlink($folder . $old_image); // Delete old image
            }
        } else {
            $_SESSION['status'] = "Sorry, only JPG, JPEG, PNG, or WEBP files are allowed.";
            header('location:agent-update.php?agent_id=' . $agent_id); // Redirect with error message
            exit();
        }
    }

    // SQL query to update the agent's details
    $query = "UPDATE mm_agents SET 
                  agent_name='$agent_name', 
                  agent_code='$agent_code', 
                  agent_photo='$agent_photo' 
              WHERE agent_id='$agent_id'";

    // Execute query and handle success or failure
    if (mysqli_query($connection, $query)) {
        $_SESSION['success'] = "Agent details updated successfully.";
        header('location:agent-list.php'); // Redirect to agent list page after successful update
    } else {
        $_SESSION['status'] = "Error updating agent details: " . mysqli_error($connection);
        header('location:agent-update.php?agent_id=' . $agent_id); // Redirect back to update page with error
    }
}


// agent delete logic
if (isset($_GET['agent_delete_id'])) {
    //$sql_query="DELETE FROM users WHERE user_id=".$_GET['delete_id'];
    $query = "DELETE  FROM mm_agents  WHERE agent_id=" . $_GET['agent_delete_id'];

    $query_run = mysqli_query($connection, $query);

    if ($query_run) {

        $_SESSION['success'] = "Agent Details Deleted";
        header('Location: agent-list.php');

    } else {

        $_SESSION['status'] = "Agent Details Not Deleted";
        header('Location: agent-list.php');

    }

}

//agent assign
if (isset($_POST['agent_assign'])) {
    // Retrieve form data
    $prop_title = mysqli_real_escape_string($connection, $_POST['prop_title']);
    $agent_code = mysqli_real_escape_string($connection, $_POST['agent_code']);
    // SQL query to update the agent_code in the mm_property_dtls table
    $query = "UPDATE mm_property_dtls SET agent_code = '$agent_code' WHERE prop_title = '$prop_title'";

    // Execute query and handle success or failure
    if (mysqli_query($connection, $query)) {
        $_SESSION['success'] = "Agent successfully assigned to the project.";
        header('location:agent-list.php'); // Redirect to agent list page or the page you prefer
    } else {
        $_SESSION['status'] = "Error assigning agent: " . mysqli_error($connection);
        header('location:agent-assign.php'); // Redirect back to the form page with an error message
    }
}

// crwon form data delete logic
if (isset($_GET['form_delete_id']) || isset($_GET['frm'])) {
    //$sql_query="DELETE FROM users WHERE user_id=".$_GET['delete_id'];
    $query = "DELETE  FROM renitz_form_data  WHERE id=" . $_GET['form_delete_id'];

    $query_run = mysqli_query($connection, $query);

    if ($query_run) {

        $_SESSION['success'] = "Form Details Deleted";
        header('Location: form-leads.php?frm=' . $_GET['frm']);

    } else {

        $_SESSION['status'] = "Form Details Not Deleted";
        header('Location: form-leads.php?frm=' . $_GET['frm']);

    }

}
?>