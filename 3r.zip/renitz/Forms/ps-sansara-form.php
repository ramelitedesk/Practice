<?php

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './assets/vendor/autoload.php';

$nameErr = $emailErr = $phoneErr = "";
$name = $email = $phone = $project_title = "";
$formData = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        return htmlspecialchars($data); // Also escape HTML characters for safety
    }

    // Ensure $connection is initialized
    if (!isset($connection)) {
        die("Database connection not established.");
    }
    // Form field initializations
    $project_title = isset($_POST["project_title"]) ? test_input($_POST["project_title"]) : '';
    $pid = isset($_POST["pid"]) ? test_input($_POST["pid"]) : '';
    $page_url = isset($_POST["page_url"]) ? test_input($_POST["page_url"]) : '';

    $errors = [];
    $full_name = '';
    $email = '';
    $country_code = '';
    $phone_no = '';
    $projecttype = '';
    $budget = '';

    // Validate name
    if (empty($_POST["full_name"])) {
        $errors[] = "Name is required.";
    } else {
        $full_name = test_input($_POST["full_name"]);
        if (!preg_match("/^[a-zA-Z\s]*$/", $full_name)) {
            $errors[] = "Only letters and white space allowed in name.";
        }
    }

    // Validate email
    if (empty($_POST["email"])) {
        $errors[] = "Email is required.";
    } else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format.";
        }
    }

    // Validate country code
    if (empty($_POST["country_Code"])) {
        $errors[] = "Country selection is required.";
    } else {
        $country_code = test_input($_POST["country_Code"]);
    }

    // Validate phone
    if (empty($_POST["phone_no"])) {
        $errors[] = "Phone number is required.";
    } else {
        $phone_no = test_input($_POST["phone_no"]);
        if (!preg_match("/^\d{10,14}$/", $phone_no)) {
            $errors[] = "Phone number must be between 10 and 14 digits.";
        }
    }

    // Validate unit type
    if (empty($_POST["projecttype"])) {
        $errors[] = "Unit type selection is required.";
    } else {
        $projecttype = test_input($_POST["projecttype"]);
    }

    // Validate budget
    if (empty($_POST["budget"])) {
        $errors[] = "Budget selection is required.";
    } else {
        $budget = test_input($_POST["budget"]);
    }

    // If there are no errors, you can proceed to store or email the data
    if (empty($errors)) {
        // Proceed to save into database or send email
        // Example:
        // $query = "INSERT INTO enquiries (...) VALUES (...)";
        echo "Form submitted successfully.";
    } else {
        // Print errors
        foreach ($errors as $error) {
            echo "<p style='color:red;'>$error</p>";
        }
    }


    // Prepare the data for insertion
    $frm_name = strtolower(str_replace(' ', '-', $project_title));
    $form_data = [];
    $exclude_fields = ['project_title', 'submit'];
    foreach ($_POST as $key => $value) {
        if (!in_array($key, $exclude_fields)) {
            $form_data[$key] = htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
        }
    }
    $form_data_json = json_encode($form_data);
    // Insert data into the database
    $sql = "INSERT INTO renitz_form_data (form_name, form_data, created_at) VALUES (?, ?, NOW())";
    $stmt = $connection->prepare($sql);

    if ($stmt === false) {
        die("Error preparing statement: " . $connection->error);
    }

    $stmt->bind_param("ss", $project_title, $form_data_json);

    if ($stmt->execute()) {
        // Send Email
        try {
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->SMTPAuth = true;
            $mail->Host = 'smtp.gmail.com';
            $mail->Username = 'ramakrushna.kreative@gmail.com';
            $mail->Password = 'vzrv ffsc qtom cnrk';
            $mail->Port = 587;
            $mail->SMTPSecure = "tls";

            $mail->setFrom('ramakrushna.kreative@gmail.com', "Kingston");
            $mail->addAddress('ramakrushna.kreative@gmail.com');
            $mail->addReplyTo($email, "No Reply");

            $mail->isHTML(true);
            $mail->Subject = "New Contact Form Submission";
            $email_body = '';
            $exclude_fields = ['project_title', 'page_url', 'pid', 'honeypot_field', 'chkbox', 'submit'];

            // First, handle the phone number with country code
            if (!empty($_POST['country_Code']) && !empty($_POST['phone_no'])) {
                $country_code = htmlspecialchars($_POST['country_Code'], ENT_QUOTES, 'UTF-8');
                $phone_no = htmlspecialchars($_POST['phone_no'], ENT_QUOTES, 'UTF-8');
                $full_phone = $country_code . ' ' . $phone_no;
                $email_body .= "<p><strong>Phone:</strong> {$full_phone}</p>";
            }

            // Loop through remaining fields
            foreach ($_POST as $key => $value) {
                if (!in_array($key, $exclude_fields)) {
                    // Skip phone fields since already handled
                    if (in_array($key, ['country_Code', 'phone_no'])) {
                        continue;
                    }

                    $key_clean = htmlspecialchars($key, ENT_QUOTES, 'UTF-8');
                    $value_clean = nl2br(htmlspecialchars($value, ENT_QUOTES, 'UTF-8'));
                    $email_body .= "<p><strong>{$key_clean}:</strong> {$value_clean}</p>";
                }
            }
            $email_body .= "<p>Best regards,<br>renitz Team</p>";
            $mail->Body = $email_body;

            $mail->send();
            echo "Post published and email sent successfully!";
            echo "<script>
                    alert('Thank You for Contact us.');
                    window.location.href = 'https://renitzproperties.com/ps-sansara.php';
                  </script>";
            exit();

        } catch (Exception $e) {
            echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "Database Error: " . $stmt->error;
    }

    $stmt->close();

}
?>