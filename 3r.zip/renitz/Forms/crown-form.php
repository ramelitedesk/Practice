<?php

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './assets/vendor/autoload.php';

$nameErr = $emailErr = $phoneErr = "";
$name = $email = $phone = $form_title = "";
$formData = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        return $data;
    }

    // Ensure $conn is initialized
    if (!isset($connection)) {
        die("Database connection not established.");
    }

    $form_title = !empty($_POST["form_title"]) ? test_input($_POST["form_title"]) : "";

    if (empty($_POST["name"])) {
        $nameErr = "Name is required";
    } else {
        $name = test_input($_POST["name"]);
        if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
            $nameErr = "Only letters and white space allowed";
        }
    }

    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        }
    }

    if (empty($_POST["phone"])) {
        $phoneErr = "Phone is required";
    } else {
        $phone = test_input($_POST["phone"]);
    }


    // Prepare the data for insertion
    $frm_name = strtolower(str_replace(' ', '-', $form_title));
    $form_data = [];
    $exclude_fields = ['form_title', 'consent_checkbox', 'submit'];
    foreach ($_POST as $key => $value) {
        if (!in_array($key, $exclude_fields)) {
            $form_data[$key] = htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
        }
    }
    $form_data_json = json_encode($form_data);
    // Insert data into the database
    $sql = "INSERT INTO renitz_form_data (form_name, form_data, created_at) VALUES (?, ?, NOW())";
    $stmt = $connection->prepare($sql);

    if ($stmt === false) {
        die("Error preparing statement: " . $connection->error);
    }

    $stmt->bind_param("ss", $form_title, $form_data_json);

    if ($stmt->execute()) {
        // Send Email
        try {
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->SMTPAuth = true;
            $mail->Host = 'smtp.gmail.com';
            $mail->Username = 'ramakrushna.kreative@gmail.com';
            $mail->Password = 'vzrv ffsc qtom cnrk';
            $mail->Port = 587;
            $mail->SMTPSecure = "tls";

            $mail->setFrom('ramakrushna.kreative@gmail.com', "Kingston");
            $mail->addAddress('ramakrushna.kreative@gmail.com');
            $mail->addReplyTo($email, "No Reply");

            $mail->isHTML(true);
            $mail->Subject = "New Contact Form Submission";
            $email_body = '';
            $exclude_fields = ['form_title', 'consent_checkbox', 'submit'];

            foreach ($_POST as $key => $value) {
                if (!in_array($key, $exclude_fields)) {
                    $key_clean = htmlspecialchars($key, ENT_QUOTES, 'UTF-8');
                    $value_clean = nl2br(htmlspecialchars($value, ENT_QUOTES, 'UTF-8'));
                    $email_body .= "<p><strong>{$key_clean}:</strong> {$value_clean}</p>";
                }
            }
            $email_body .= "<p>Best regards,<br>renitz Team</p>";
            $mail->Body = $email_body;

            $mail->send();
            echo "Post published and email sent successfully!";
            echo "<script>
                    alert('Thank You for Contact us.');
                    window.location.href = 'http://localhost/renitz/crown.php';
                  </script>";
            exit();

        } catch (Exception $e) {
            echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "Database Error: " . $stmt->error;
    }

    $stmt->close();

}
?>