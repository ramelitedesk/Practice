<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "renitz_db";



// Create connection

$connection = mysqli_connect($servername, $username, $password, $db);

// SQL to create the 'renitz_form_data' table
// $sql = "CREATE TABLE renitz_form_data (
//     id INT(11) AUTO_INCREMENT PRIMARY KEY,
//     form_name VARCHAR(255) NOT NULL,
//     form_data LONGTEXT NOT NULL,
//     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
// )";

// if ($connection->query($sql) === TRUE) {
//    echo "Table created successfully.";
// } else {
//    echo "Error creating table: " . $connection->error;
// }

// Check connection

if (!$connection) {

   die("Connection failed: " . mysqli_connect_error());

}

//echo "Connected successfully";

?>