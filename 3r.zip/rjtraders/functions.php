<?php
/**
 * Functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

// This theme requires WordPress 5.3 or later.
if (version_compare($GLOBALS['wp_version'], '5.3', '<')) {
	require get_template_directory() . '/inc/back-compat.php';
}

if (!function_exists('twenty_twenty_one_setup')) {
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 *
	 * @since Twenty Twenty-One 1.0
	 *
	 * @return void
	 */
	function twenty_twenty_one_setup()
	{

		// Add default posts and comments RSS feed links to head.
		add_theme_support('automatic-feed-links');

		/*
		 * Let WordPress manage the document title.
		 * This theme does not use a hard-coded <title> tag in the document head,
		 * WordPress will provide it for us.
		 */
		add_theme_support('title-tag');

		/**
		 * Add post-formats support.
		 */
		add_theme_support(
			'post-formats',
			array(
				'link',
				'aside',
				'gallery',
				'image',
				'quote',
				'status',
				'video',
				'audio',
				'chat',
			)
		);

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support('post-thumbnails');
		set_post_thumbnail_size(1568, 9999);

		register_nav_menus(
			array(
				'primary' => esc_html__('Primary menu', 'twentytwentyone'),
				'footer' => esc_html__('Secondary menu', 'twentytwentyone'),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
				'navigation-widgets',
			)
		);

		/*
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		$logo_width = 300;
		$logo_height = 100;

		add_theme_support(
			'custom-logo',
			array(
				'height' => $logo_height,
				'width' => $logo_width,
				'flex-width' => true,
				'flex-height' => true,
				'unlink-homepage-logo' => true,
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support('customize-selective-refresh-widgets');

		// Add support for Block Styles.
		add_theme_support('wp-block-styles');

		// Add support for full and wide align images.
		add_theme_support('align-wide');

		// Add support for editor styles.
		add_theme_support('editor-styles');
		$background_color = get_theme_mod('background_color', 'D1E4DD');
		if (127 > Twenty_Twenty_One_Custom_Colors::get_relative_luminance_from_hex($background_color)) {
			add_theme_support('dark-editor-style');
		}

		$editor_stylesheet_path = './assets/css/style-editor.css';

		// Note, the is_IE global variable is defined by WordPress and is used
		// to detect if the current browser is internet explorer.
		global $is_IE;
		if ($is_IE) {
			$editor_stylesheet_path = './assets/css/ie-editor.css';
		}

		// Enqueue editor styles.
		add_editor_style($editor_stylesheet_path);

		// Add custom editor font sizes.
		add_theme_support(
			'editor-font-sizes',
			array(
				array(
					'name' => esc_html__('Extra small', 'twentytwentyone'),
					'shortName' => esc_html_x('XS', 'Font size', 'twentytwentyone'),
					'size' => 16,
					'slug' => 'extra-small',
				),
				array(
					'name' => esc_html__('Small', 'twentytwentyone'),
					'shortName' => esc_html_x('S', 'Font size', 'twentytwentyone'),
					'size' => 18,
					'slug' => 'small',
				),
				array(
					'name' => esc_html__('Normal', 'twentytwentyone'),
					'shortName' => esc_html_x('M', 'Font size', 'twentytwentyone'),
					'size' => 20,
					'slug' => 'normal',
				),
				array(
					'name' => esc_html__('Large', 'twentytwentyone'),
					'shortName' => esc_html_x('L', 'Font size', 'twentytwentyone'),
					'size' => 24,
					'slug' => 'large',
				),
				array(
					'name' => esc_html__('Extra large', 'twentytwentyone'),
					'shortName' => esc_html_x('XL', 'Font size', 'twentytwentyone'),
					'size' => 40,
					'slug' => 'extra-large',
				),
				array(
					'name' => esc_html__('Huge', 'twentytwentyone'),
					'shortName' => esc_html_x('XXL', 'Font size', 'twentytwentyone'),
					'size' => 96,
					'slug' => 'huge',
				),
				array(
					'name' => esc_html__('Gigantic', 'twentytwentyone'),
					'shortName' => esc_html_x('XXXL', 'Font size', 'twentytwentyone'),
					'size' => 144,
					'slug' => 'gigantic',
				),
			)
		);

		// Custom background color.
		add_theme_support(
			'custom-background',
			array(
				'default-color' => 'd1e4dd',
			)
		);

		// Editor color palette.
		$black = '#000000';
		$dark_gray = '#28303D';
		$gray = '#39414D';
		$green = '#D1E4DD';
		$blue = '#D1DFE4';
		$purple = '#D1D1E4';
		$red = '#E4D1D1';
		$orange = '#E4DAD1';
		$yellow = '#EEEADD';
		$white = '#FFFFFF';

		add_theme_support(
			'editor-color-palette',
			array(
				array(
					'name' => esc_html__('Black', 'twentytwentyone'),
					'slug' => 'black',
					'color' => $black,
				),
				array(
					'name' => esc_html__('Dark gray', 'twentytwentyone'),
					'slug' => 'dark-gray',
					'color' => $dark_gray,
				),
				array(
					'name' => esc_html__('Gray', 'twentytwentyone'),
					'slug' => 'gray',
					'color' => $gray,
				),
				array(
					'name' => esc_html__('Green', 'twentytwentyone'),
					'slug' => 'green',
					'color' => $green,
				),
				array(
					'name' => esc_html__('Blue', 'twentytwentyone'),
					'slug' => 'blue',
					'color' => $blue,
				),
				array(
					'name' => esc_html__('Purple', 'twentytwentyone'),
					'slug' => 'purple',
					'color' => $purple,
				),
				array(
					'name' => esc_html__('Red', 'twentytwentyone'),
					'slug' => 'red',
					'color' => $red,
				),
				array(
					'name' => esc_html__('Orange', 'twentytwentyone'),
					'slug' => 'orange',
					'color' => $orange,
				),
				array(
					'name' => esc_html__('Yellow', 'twentytwentyone'),
					'slug' => 'yellow',
					'color' => $yellow,
				),
				array(
					'name' => esc_html__('White', 'twentytwentyone'),
					'slug' => 'white',
					'color' => $white,
				),
			)
		);

		add_theme_support(
			'editor-gradient-presets',
			array(
				array(
					'name' => esc_html__('Purple to yellow', 'twentytwentyone'),
					'gradient' => 'linear-gradient(160deg, ' . $purple . ' 0%, ' . $yellow . ' 100%)',
					'slug' => 'purple-to-yellow',
				),
				array(
					'name' => esc_html__('Yellow to purple', 'twentytwentyone'),
					'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $purple . ' 100%)',
					'slug' => 'yellow-to-purple',
				),
				array(
					'name' => esc_html__('Green to yellow', 'twentytwentyone'),
					'gradient' => 'linear-gradient(160deg, ' . $green . ' 0%, ' . $yellow . ' 100%)',
					'slug' => 'green-to-yellow',
				),
				array(
					'name' => esc_html__('Yellow to green', 'twentytwentyone'),
					'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $green . ' 100%)',
					'slug' => 'yellow-to-green',
				),
				array(
					'name' => esc_html__('Red to yellow', 'twentytwentyone'),
					'gradient' => 'linear-gradient(160deg, ' . $red . ' 0%, ' . $yellow . ' 100%)',
					'slug' => 'red-to-yellow',
				),
				array(
					'name' => esc_html__('Yellow to red', 'twentytwentyone'),
					'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $red . ' 100%)',
					'slug' => 'yellow-to-red',
				),
				array(
					'name' => esc_html__('Purple to red', 'twentytwentyone'),
					'gradient' => 'linear-gradient(160deg, ' . $purple . ' 0%, ' . $red . ' 100%)',
					'slug' => 'purple-to-red',
				),
				array(
					'name' => esc_html__('Red to purple', 'twentytwentyone'),
					'gradient' => 'linear-gradient(160deg, ' . $red . ' 0%, ' . $purple . ' 100%)',
					'slug' => 'red-to-purple',
				),
			)
		);

		/*
		 * Adds starter content to highlight the theme on fresh sites.
		 * This is done conditionally to avoid loading the starter content on every
		 * page load, as it is a one-off operation only needed once in the customizer.
		 */
		if (is_customize_preview()) {
			require get_template_directory() . '/inc/starter-content.php';
			add_theme_support('starter-content', twenty_twenty_one_get_starter_content());
		}

		// Add support for responsive embedded content.
		add_theme_support('responsive-embeds');

		// Add support for custom line height controls.
		add_theme_support('custom-line-height');

		// Add support for link color control.
		add_theme_support('link-color');

		// Add support for experimental cover block spacing.
		add_theme_support('custom-spacing');

		// Add support for custom units.
		// This was removed in WordPress 5.6 but is still required to properly support WP 5.5.
		add_theme_support('custom-units');

		// Remove feed icon link from legacy RSS widget.
		add_filter('rss_widget_feed_link', '__return_empty_string');
	}
}
add_action('after_setup_theme', 'twenty_twenty_one_setup');

/**
 * Registers widget area.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 *
 * @return void
 */
function twenty_twenty_one_widgets_init()
{

	register_sidebar(
		array(
			'name' => esc_html__('Footer', 'twentytwentyone'),
			'id' => 'sidebar-1',
			'description' => esc_html__('Add widgets here to appear in your footer.', 'twentytwentyone'),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget' => '</section>',
			'before_title' => '<h2 class="widget-title">',
			'after_title' => '</h2>',
		)
	);
}
add_action('widgets_init', 'twenty_twenty_one_widgets_init');

/**
 * Sets the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @global int $content_width Content width.
 *
 * @return void
 */
function twenty_twenty_one_content_width()
{
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters('twenty_twenty_one_content_width', 750);
}
add_action('after_setup_theme', 'twenty_twenty_one_content_width', 0);

/**
 * Enqueues scripts and styles.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @global bool       $is_IE
 * @global WP_Scripts $wp_scripts
 *
 * @return void
 */
function twenty_twenty_one_scripts()
{
	// Note, the is_IE global variable is defined by WordPress and is used
	// to detect if the current browser is internet explorer.
	global $is_IE, $wp_scripts;
	if ($is_IE) {
		// If IE 11 or below, use a flattened stylesheet with static values replacing CSS Variables.
		wp_enqueue_style('twenty-twenty-one-style', get_template_directory_uri() . '/assets/css/ie.css', array(), wp_get_theme()->get('Version'));
	} else {
		// If not IE, use the standard stylesheet.
		wp_enqueue_style('twenty-twenty-one-style', get_template_directory_uri() . '/style.css', array(), wp_get_theme()->get('Version'));
	}

	// RTL styles.
	wp_style_add_data('twenty-twenty-one-style', 'rtl', 'replace');

	// Print styles.
	wp_enqueue_style('twenty-twenty-one-print-style', get_template_directory_uri() . '/assets/css/print.css', array(), wp_get_theme()->get('Version'), 'print');

	// Threaded comment reply styles.
	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}

	// Register the IE11 polyfill file.
	wp_register_script(
		'twenty-twenty-one-ie11-polyfills-asset',
		get_template_directory_uri() . '/assets/js/polyfills.js',
		array(),
		wp_get_theme()->get('Version'),
		array('in_footer' => true)
	);

	// Register the IE11 polyfill loader.
	wp_register_script(
		'twenty-twenty-one-ie11-polyfills',
		null,
		array(),
		wp_get_theme()->get('Version'),
		array('in_footer' => true)
	);
	wp_add_inline_script(
		'twenty-twenty-one-ie11-polyfills',
		wp_get_script_polyfill(
			$wp_scripts,
			array(
				'Element.prototype.matches && Element.prototype.closest && window.NodeList && NodeList.prototype.forEach' => 'twenty-twenty-one-ie11-polyfills-asset',
			)
		)
	);

	// Main navigation scripts.
	if (has_nav_menu('primary')) {
		wp_enqueue_script(
			'twenty-twenty-one-primary-navigation-script',
			get_template_directory_uri() . '/assets/js/primary-navigation.js',
			array('twenty-twenty-one-ie11-polyfills'),
			wp_get_theme()->get('Version'),
			array(
				'in_footer' => false, // Because involves header.
				'strategy' => 'defer',
			)
		);
	}

	// Responsive embeds script.
	wp_enqueue_script(
		'twenty-twenty-one-responsive-embeds-script',
		get_template_directory_uri() . '/assets/js/responsive-embeds.js',
		array('twenty-twenty-one-ie11-polyfills'),
		wp_get_theme()->get('Version'),
		array('in_footer' => true)
	);
}
add_action('wp_enqueue_scripts', 'twenty_twenty_one_scripts');

/**
 * Enqueues block editor script.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_block_editor_script()
{

	wp_enqueue_script('twentytwentyone-editor', get_theme_file_uri('/assets/js/editor.js'), array('wp-blocks', 'wp-dom'), wp_get_theme()->get('Version'), array('in_footer' => true));
}

add_action('enqueue_block_editor_assets', 'twentytwentyone_block_editor_script');

/**
 * Fixes skip link focus in IE11.
 *
 * This does not enqueue the script because it is tiny and because it is only for IE11,
 * thus it does not warrant having an entire dedicated blocking script being loaded.
 *
 * @since Twenty Twenty-One 1.0
 * @deprecated Twenty Twenty-One 1.9 Removed from wp_print_footer_scripts action.
 *
 * @link https://git.io/vWdr2
 */
function twenty_twenty_one_skip_link_focus_fix()
{

	// If SCRIPT_DEBUG is defined and true, print the unminified file.
	if (defined('SCRIPT_DEBUG') && SCRIPT_DEBUG) {
		echo '<script>';
		include get_template_directory() . '/assets/js/skip-link-focus-fix.js';
		echo '</script>';
	} else {
		// The following is minified via `npx terser --compress --mangle -- assets/js/skip-link-focus-fix.js`.
		?>
		<script>
			/(trident|msie)/i.test(navigator.userAgent) && document.getElementById && window.addEventListener && window.addEventListener("hashchange", (function () { var t, e = location.hash.substring(1); /^[A-z0-9_-]+$/.test(e) && (t = document.getElementById(e)) && (/^(?:a|select|input|button|textarea)$/i.test(t.tagName) || (t.tabIndex = -1), t.focus()) }), !1);
		</script>
		<?php
	}
}

/**
 * Enqueues non-latin language styles.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twenty_twenty_one_non_latin_languages()
{
	$custom_css = twenty_twenty_one_get_non_latin_css('front-end');

	if ($custom_css) {
		wp_add_inline_style('twenty-twenty-one-style', $custom_css);
	}
}
add_action('wp_enqueue_scripts', 'twenty_twenty_one_non_latin_languages');

// SVG Icons class.
require get_template_directory() . '/classes/class-twenty-twenty-one-svg-icons.php';

// Custom color classes.
require get_template_directory() . '/classes/class-twenty-twenty-one-custom-colors.php';
new Twenty_Twenty_One_Custom_Colors();

// Enhance the theme by hooking into WordPress.
require get_template_directory() . '/inc/template-functions.php';

// Menu functions and filters.
require get_template_directory() . '/inc/menu-functions.php';

// Custom template tags for the theme.
require get_template_directory() . '/inc/template-tags.php';

// Customizer additions.
require get_template_directory() . '/classes/class-twenty-twenty-one-customize.php';
new Twenty_Twenty_One_Customize();

// Block Patterns.
require get_template_directory() . '/inc/block-patterns.php';

// Block Styles.
require get_template_directory() . '/inc/block-styles.php';

// Dark Mode.
require_once get_template_directory() . '/classes/class-twenty-twenty-one-dark-mode.php';
new Twenty_Twenty_One_Dark_Mode();

/**
 * Enqueues scripts for the customizer preview.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_customize_preview_init()
{
	wp_enqueue_script(
		'twentytwentyone-customize-helpers',
		get_theme_file_uri('/assets/js/customize-helpers.js'),
		array(),
		wp_get_theme()->get('Version'),
		array('in_footer' => true)
	);

	wp_enqueue_script(
		'twentytwentyone-customize-preview',
		get_theme_file_uri('/assets/js/customize-preview.js'),
		array('customize-preview', 'customize-selective-refresh', 'jquery', 'twentytwentyone-customize-helpers'),
		wp_get_theme()->get('Version'),
		array('in_footer' => true)
	);
}
add_action('customize_preview_init', 'twentytwentyone_customize_preview_init');

/**
 * Enqueues scripts for the customizer.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_customize_controls_enqueue_scripts()
{

	wp_enqueue_script(
		'twentytwentyone-customize-helpers',
		get_theme_file_uri('/assets/js/customize-helpers.js'),
		array(),
		wp_get_theme()->get('Version'),
		array('in_footer' => true)
	);
}
add_action('customize_controls_enqueue_scripts', 'twentytwentyone_customize_controls_enqueue_scripts');

/**
 * Calculates classes for the main <html> element.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_the_html_classes()
{
	/**
	 * Filters the classes for the main <html> element.
	 *
	 * @since Twenty Twenty-One 1.0
	 *
	 * @param string The list of classes. Default empty string.
	 */
	$classes = apply_filters('twentytwentyone_html_classes', '');
	if (!$classes) {
		return;
	}
	echo 'class="' . esc_attr($classes) . '"';
}

/**
 * Adds "is-IE" class to body if the user is on Internet Explorer.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_add_ie_class()
{
	?>
	<script>
		if (-1 !== navigator.userAgent.indexOf('MSIE') || -1 !== navigator.appVersion.indexOf('Trident/')) {
			document.body.classList.add('is-IE');
		}
	</script>
	<?php
}
add_action('wp_footer', 'twentytwentyone_add_ie_class');

if (!function_exists('wp_get_list_item_separator')):
	/**
	 * Retrieves the list item separator based on the locale.
	 *
	 * Added for backward compatibility to support pre-6.0.0 WordPress versions.
	 *
	 * @since 6.0.0
	 */
	function wp_get_list_item_separator()
	{
		/* translators: Used between list items, there is a space after the comma. */
		return __(', ', 'twentytwentyone');
	}
endif;


// Enque JS to footer
function add_this_script_footer()
{ ?>


	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/jquery.js"></script>
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/popper.min.js"></script>
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/bootstrap.min.js"></script>
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/jquery.mCustomScrollbar.concat.min.js"></script>
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/appear.js"></script>
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/owl.js"></script>
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/wow.js"></script>
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/jquery-ui.js"></script>
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/validate.js"></script>
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/script.js"></script>

	<!-- swiper js link -->
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/swiper-bundle.min.js" defer="defer"></script>

	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/product-slide.js"></script>
	<!--Google Map APi Key-->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD39_Mb1wKUcuRD-0KPmQT6SQHhEMVX1O0"></script>
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/map-script.js"></script>
	<!--End Google Map APi-->
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/jquery.fancybox.min.js"></script>
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/color-settings.js"></script>


<?php }
add_action('wp_footer', 'add_this_script_footer');


// Enque JS to footer
function add_script_carousel_footer()
{
	?>


	<!-- DATA -->

	<script>
		$(document).ready(function () {
			const $carousel = $('.main-slider-carousel');

			$carousel.owlCarousel({
				items: 1,
				loop: true,
				autoplay: true,
				autoplayTimeout: 5000,
				animateOut: 'fadeOut',
				onChanged: function (event) {

					const shapes = $carousel.find('.banner-shape');
					shapes.each(function () {
						$(this).css({
							left: '-100%',
							opacity: 0
						});
					});


					const activeShapes = $carousel.find('.owl-item.active').find('.banner-shape');
					activeShapes.each(function (index) {
						const shape = $(this);
						setTimeout(() => {
							shape.css({
								left: '0',
								opacity: 1
							});
						}, index * 300);
					});
				}
			});
		});


		function openTab(evt, contentId) {
			const contents = document.querySelectorAll('.tab-content');
			contents.forEach(content => {
				content.classList.remove('visible');
			});

			const tabs = document.querySelectorAll('.tab-item');
			tabs.forEach(tab => {
				tab.classList.remove('active');
			});

			document.getElementById(contentId).classList.add('visible');
			evt.currentTarget.classList.add('active');
		}
	</script>
	<!-- DATA -->

	<script>
		document.addEventListener("DOMContentLoaded", function () {
			function generateCaptcha() {
				var num1 = Math.floor(Math.random() * 10) + 1;
				var num2 = Math.floor(Math.random() * 10) + 1;
				var answer = num1 + num2;

				document.getElementById('captcha_question').textContent = num1 + " + " + num2;
				document.getElementById('captcha_answer').value = answer; // Store answer in hidden field
			}

			generateCaptcha();

			document.getElementById('refresh_captcha').addEventListener("click", function () {
				generateCaptcha();
			});

			window.validateCaptcha = function () {
				var userInput = document.getElementById('captcha_input').value;
				var correctAnswer = document.getElementById('captcha_answer').value;

				if (userInput !== correctAnswer) {
					alert("Incorrect CAPTCHA answer. Please try again.");
					generateCaptcha();
					return false;
				}
				return true;
			};
		});

	</script>

	<script>
		document.addEventListener("DOMContentLoaded", function () {
			function generateCaptcha() {
				let num1 = Math.floor(Math.random() * 10) + 1;
				let num2 = Math.floor(Math.random() * 10) + 1;
				let answer = num1 + num2;

				document.getElementById("captcha_question").textContent = num1 + " + " + num2;
				document.getElementById("captcha_answer").value = answer;
			}

			document.getElementById("refresh_captcha").addEventListener("click", function () {
				generateCaptcha();
			});

			generateCaptcha(); // Generate CAPTCHA on page load

			// Prevent form submission if CAPTCHA is incorrect
			document.getElementById("career_form").addEventListener("submit", function (event) {
				let captchaInput = document.getElementById("captcha_input").value.trim();
				let correctAnswer = document.getElementById("captcha_answer").value;

				if (captchaInput === "") {
					alert("Please enter the CAPTCHA.");
					event.preventDefault(); // Stop form submission
					return;
				}

				if (parseInt(captchaInput) !== parseInt(correctAnswer)) {
					alert("Incorrect CAPTCHA. Please try again.");
					event.preventDefault(); // Stop form submission
					return;
				}

				// If CAPTCHA is correct, allow form submission
			});
		});

	</script>

	<?php
}

add_action('wp_footer', 'add_script_carousel_footer');





// For Removing Visual Editor On a Specific Page (By Page Title)
add_action('admin_init', 'hide_editor');

function hide_editor()
{
	// Get the Post ID.
	$post_id = $_GET['post'] ? $_GET['post'] : $_POST['post_ID'];
	if (!isset($post_id))
		return;


	$page1 = get_the_title($post_id);
	if ($page1 == 'Home') {
		remove_post_type_support('page', 'editor');
	}
	$page2 = get_the_title($post_id);
	if ($page2 == 'About Us') {
		remove_post_type_support('page', 'editor');
	}
	$page3 = get_the_title($post_id);
	if ($page3 == 'Contact Us') {
		remove_post_type_support('page', 'editor');
	}
	$page4 = get_the_title($post_id);
	if ($page4 == 'Mission And Vission') {
		remove_post_type_support('page', 'editor');
	}

	$page9 = get_the_title($post_id);
	if ($page9 == 'Why Choose Us') {
		remove_post_type_support('page', 'editor');
	}
	$page10 = get_the_title($post_id);
	if ($page10 == 'Blog') {
		remove_post_type_support('page', 'editor');
	}
	$page11 = get_the_title($post_id);
	if ($page11 == 'Our Customers') {
		remove_post_type_support('page', 'editor');
	}
	$page12 = get_the_title($post_id);
	if ($page12 == 'Image Gallery') {
		remove_post_type_support('page', 'editor');
	}
	$page13 = get_the_title($post_id);
	if ($page13 == 'Video Gallery') {
		remove_post_type_support('page', 'editor');
	}
	$page14 = get_the_title($post_id);
	if ($page14 == 'Career') {
		remove_post_type_support('page', 'editor');
	}
	$page15 = get_the_title($post_id);
	if ($page15 == 'Enquiry') {
		remove_post_type_support('page', 'editor');
	}
	$page16 = get_the_title($post_id);
	if ($page16 == 'Contact us') {
		remove_post_type_support('page', 'editor');
	}
	$page17 = get_the_title($post_id);
	if ($page17 == 'Our Team') {
		remove_post_type_support('page', 'editor');
	}






}


// For Removing Visual Editor On a Specific Page (By Page id)
function remove_pages_editor()
{
	if (get_the_ID() === 14) {
		remove_post_type_support('page', 'editor');
	} // end if
} // end remove_pages_editor
add_action('add_meta_boxes', 'remove_pages_editor');




// For Disable Add Item
$labels = array(
	'name' => _x('Contact Details', 'Post Type General Name', 'text_domain'),
	'singular_name' => _x('Contact Detail', 'Post Type Singular Name', 'text_domain'),
	'menu_name' => __('Contact Details', 'text_domain'),
	'name_admin_bar' => __('Contact Detail', 'text_domain'),
	'archives' => __('Contact Detail Archives', 'text_domain'),
	'attributes' => __('Contact Detail Attributes', 'text_domain'),
	'parent_item_colon' => __('Parent Contact Detail:', 'text_domain'),
	'all_items' => __('All Contact Details', 'text_domain'),
	'add_new_item' => __('Add New Contact Detail', 'text_domain'),
	'add_new' => __('Add New', 'text_domain'),
	'new_item' => __('New Contact Detail', 'text_domain'),
	'edit_item' => __('Edit Contact Detail', 'text_domain'),
	'update_item' => __('Update Contact Detail', 'text_domain'),
	'view_item' => __('View Contact Detail', 'text_domain'),
	'view_items' => __('View Contact Details', 'text_domain'),
	'search_items' => __('Search Contact Details', 'text_domain'),
	'not_found' => __('Not Found', 'text_domain'),
	'not_found_in_trash' => __('Not Found in Trash', 'text_domain'),
	'featured_image' => __('Featured Image', 'text_domain'),
	'set_featured_image' => __('Set Featured Image', 'text_domain'),
	'remove_featured_image' => __('Remove Featured Image', 'text_domain'),
	'use_featured_image' => __('Use as Featured Image', 'text_domain'),
	'insert_into_item' => __('Insert into Contact Detail', 'text_domain'),
	'uploaded_to_this_item' => __('Uploaded to this Contact Detail', 'text_domain'),
	'items_list' => __('Contact Details List', 'text_domain'),
	'items_list_navigation' => __('Contact Details List Navigation', 'text_domain'),
	'filter_items_list' => __('Filter Contact Details List', 'text_domain'),
);

$args = array(
	'label' => __('Contact Details', 'text_domain'),
	'description' => __('Contact Details', 'text_domain'),
	'labels' => $labels,
	'supports' => array('title'),
	'hierarchical' => false,
	'public' => true,
	'show_ui' => true,
	'show_in_menu' => true,
	'show_in_nav_menus' => true,
	'show_in_admin_bar' => true,
	'has_archive' => true,
	'exclude_from_search' => false,
	'publicly_queryable' => true,
	'map_meta_cap' => true,
	'capabilities' => array(
		'create_posts' => 'do_not_allow',
	),
);

register_post_type('contact-details', $args);



function custom_login_logo()
{ ?>
	<style type="text/css">
		.login h1 a {
			background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/images/favicon.png') !important;
			width: 100px !important;
			pointer-events: none;
			background-color: #fff;
			background-position: center !important;
			height: 100px !important;
			background-size: 80px !important;
			box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px;
			border-radius: 50%;
			border: 5px solid #6c46af;
		}

		body.login {
			background-image: linear-gradient(to right, #4d37af, #522e89, #4d37af);
			position: relative;
		}

		body.login:before {
			position: absolute;
			content: '';
			top: 0;
			right: 0;
			width: 50%;
			height: 100%;
			background-position: center right;
			background-repeat: no-repeat;
			background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/images/bannerr.gif');
			z-index: -1;
			background-size: contain;
		}

		body.login:after {
			position: absolute;
			content: '';
			top: 0;
			left: 0;
			width: 50%;
			height: 100%;
			background-position: center right;
			background-repeat: no-repeat;
			background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/images/bannerr.gif');
			z-index: -1;
			background-size: contain;
			transform: rotateY(180deg);
		}

		.login #backtoblog a,
		.login #nav a {
			text-decoration: none;
			color: #fff !important;
		}

		.login form {
			border: none !important;
			border-radius: 10px !important;
			box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px !important;
		}
	</style>
<?php }
add_action('login_enqueue_scripts', 'custom_login_logo');




function enqueue_custom_form_script()
{
	wp_enqueue_script('custom-form-handler', get_template_directory_uri() . '/js/form-handler.js', ['jquery'], null, true);
	wp_localize_script('custom-form-handler', 'ajax_form', [
		'ajax_url' => admin_url('admin-ajax.php'),
	]);
}
add_action('wp_enqueue_scripts', 'enqueue_custom_form_script');





// Redirect the 'contact-details' post type edit page
add_action('admin_init', function () {
	global $pagenow;
	if ($pagenow === 'edit.php' && isset($_GET['post_type']) && $_GET['post_type'] === 'contact-details') {
		wp_redirect(admin_url('post.php?post=43&action=edit'));
		exit;
	}
});

// Remove "Delete" or "Trash" option for the 'contact-details' post type in row actions
add_filter('post_row_actions', function ($actions, $post) {
	if ($post->post_type === 'contact-details') {
		unset($actions['trash']); // Remove Trash
		unset($actions['delete']); // Remove Delete
	}
	return $actions;
}, 10, 2);

// Disable the "Move to Trash" bulk action for the 'contact-details' post type
add_filter('bulk_actions-edit-contact-details', function ($actions) {
	unset($actions['trash']); // Remove "Move to Trash" option
	return $actions;
});

// Force posts of 'contact-details' post type to bypass the Trash and not allow deletion
add_action('wp_trash_post', function ($post_id) {
	$post = get_post($post_id);
	if ($post && $post->post_type === 'contact-details') {
		wp_die(__('You cannot move this post to the Trash.', 'textdomain'));
	}
});

// Block bulk trashing of 'contact-details' posts
add_filter('map_meta_cap', function ($caps, $cap, $user_id, $args) {
	if ($cap === 'delete_post' || $cap === 'delete_posts') {
		$post_id = isset($args[0]) ? $args[0] : null;
		if ($post_id && get_post_type($post_id) === 'contact-details') {
			return ['do_not_allow'];
		}
	}
	return $caps;
}, 10, 4);







// Register Custom Post Type for Blog Comments
function custom_blog_comments()
{
	register_post_type(
		'blog-comments',
		array(
			'labels' => array(
				'name' => __('Blog Comments'),
				'singular_name' => __('Blog Comment'),
			),
			'public' => false,
			'show_ui' => true,
			'supports' => array('title'),
			'menu_position' => 5,
			'menu_icon' => 'dashicons-admin-comments', // Dashicon for comments
			'capabilities' => array(
				'create_posts' => false, // Disable "Add New"
			),
			'map_meta_cap' => true,
		)
	);
}
add_action('init', 'custom_blog_comments');

// Modify Admin Table Columns for Blog Comments
function set_custom_edit_blog_comments_columns($columns)
{
	unset($columns['message']); // Remove Message
	unset($columns['blog_id']); // Remove Blog Post


	$columns['username'] = 'Name';
	$columns['location'] = 'Location';
	$columns['view_details'] = '';
	$columns['approved'] = 'Approval';

	return $columns;
}
add_filter('manage_blog-comments_posts_columns', 'set_custom_edit_blog_comments_columns');

// Populate Admin Table with View Details Button
function custom_blog_comments_column($column, $post_id)
{
	switch ($column) {
		case 'view_details':
			echo '<a href="' . get_edit_post_link($post_id) . '" class="button">View Details</a>';
			break;
		case 'username':
			echo get_post_meta($post_id, 'username', true);
			break;
		case 'location':
			echo get_post_meta($post_id, 'location', true);
			break;
		case 'approved':
			$approved = get_post_meta($post_id, 'approved', true);
			if ($approved == '1') {
				echo '<span style="color:green;">Approved</span>';
			} else {
				echo '<a href="' . admin_url('admin-post.php?action=approve_comment&id=' . $post_id) . '" class="button">Approve</a>';
			}
			break;
	}
}
add_action('manage_blog-comments_posts_custom_column', 'custom_blog_comments_column', 10, 2);

// Add Fields to Comment Edit Page
function add_blog_comment_meta_boxes()
{
	add_meta_box('blog_comment_details', 'Blog Comment Details', 'blog_comment_meta_box_callback', 'blog-comments', 'normal', 'high');
}
add_action('add_meta_boxes', 'add_blog_comment_meta_boxes');

function blog_comment_meta_box_callback($post)
{
	$message = get_post_meta($post->ID, 'message', true);
	$username = get_post_meta($post->ID, 'username', true);
	$location = get_post_meta($post->ID, 'location', true);
	$email = get_post_meta($post->ID, 'email', true);
	$blog_id = get_post_meta($post->ID, 'blog_id', true);
	$approved = get_post_meta($post->ID, 'approved', true);
	$blog_name = get_the_title($blog_id);

	?>
	<table class="form-table">
		<tr>
			<th><label for="username">Name:</label></th>
			<td><input type="text" id="username" name="username" value="<?php echo esc_attr($username); ?>"
					class="regular-text" readonly></td>
		</tr>
		<tr>
			<th><label for="email">Email:</label></th>
			<td><input type="text" id="email" name="email" value="<?php echo esc_attr($email); ?>" class="regular-text"
					readonly></td>
		</tr>
		<tr>
			<th><label for="location">Location:</label></th>
			<td><input type="text" id="location" name="location" value="<?php echo esc_attr($location); ?>"
					class="regular-text" readonly></td>
		</tr>
		<tr>
			<th><label for="blog_name">Blog Post:</label></th>
			<td><input type="text" id="blog_name" name="blog_name" value="<?php echo esc_attr($blog_name); ?>"
					class="regular-text" readonly></td>
		</tr>
		<tr>
			<th><label for="message">Message:</label></th>
			<td><textarea id="message" name="message" rows="5" class="large-text"
					readonly><?php echo esc_textarea($message); ?></textarea></td>
		</tr>
		<tr>
			<th>Approval Status:</th>
			<td>
				<?php if ($approved == '1') { ?>
					<span style="color:green;">Approved</span>
				<?php } else { ?>
					<a href="<?php echo admin_url('admin-post.php?action=approve_comment&id=' . $post->ID); ?>"
						class="button">Approve</a>
				<?php } ?>
			</td>
		</tr>
	</table>
	<?php
}

// Handle Comment Approval
function approve_blog_comment()
{
	if (!current_user_can('manage_options') || !isset($_GET['id'])) {
		wp_die(__('You are not allowed to do this.'));
	}

	$post_id = intval($_GET['id']);
	update_post_meta($post_id, 'approved', '1');

	wp_redirect(admin_url('edit.php?post_type=blog-comments'));
	exit;
}
add_action('admin_post_approve_comment', 'approve_blog_comment');



add_action('phpmailer_init', function ($phpmailer) {
	$phpmailer->isSMTP();
	$phpmailer->Host = 'srv90.bharatdns.com';
	$phpmailer->SMTPAuth = true;
	$phpmailer->Port = 465;
	$phpmailer->Username = 'noreply@rjtraders.in';
	$phpmailer->Password = '9=*aazeGAKTPAj';
	$phpmailer->SMTPSecure = 'ssl';
});

add_action('init', function () {
	if (isset($_POST['submit_contact_form'])) {
		// CAPTCHA Validation
		$user_input = isset($_POST['captcha_input']) ? sanitize_text_field($_POST['captcha_input']) : '';
		$correct_answer = isset($_POST['captcha_answer']) ? sanitize_text_field($_POST['captcha_answer']) : '';

		$form_name = isset($_POST['form_name']) ? sanitize_text_field($_POST['form_name']) : '';

		// Remove fields we don't want to include in form_data
		$exclude_fields = ['form_name', 'submit_contact_form', 'captcha_input', 'captcha_answer'];

		if ($user_input !== $correct_answer) {
			wp_die('Incorrect CAPTCHA answer. Please go back and try again.');
		}
		rj_form_insert_data($form_name, $exclude_fields);
		// Sanitize and retrieve form data
		$name = sanitize_text_field($_POST['name']);
		$subject1 = sanitize_text_field($_POST['subject1']);
		$phone = sanitize_text_field($_POST['phone']);
		$email = sanitize_email($_POST['email']);
		$message = sanitize_textarea_field($_POST['message']);

		// Email setup
		$to = 'rjtraders5@hotmail.com'; // Replace with your email address
		$subject = 'New Contact Form Submission (RJ Traders)';
		$headers = [
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $name . ' <' . $email . '>',
		];
		$body = "
            <div style='font-family: Arial, sans-serif; font-size: 14px; color: #333;'>
                <h2 style='background: #0073aa; padding: 10px 20px; margin-bottom: 0; width: 600px; text-align: center; color: #fff; font-size: 18px;'>New Contact Form Submission</h2>
                <table style='border-collapse: collapse; width: 100%; max-width: 600px; margin: 0px 0; border: 1px solid #ddd;'>
                    <tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>Full Name</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>{$name}</td>
                    </tr>
					<tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>Subject</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>{$subject1}</td>
                    </tr>
                    <tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>Phone No</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>{$phone}</td>
                    </tr>
                    <tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>Email Id</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>{$email}</td>
                    </tr>
                    <tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>Message</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>{$message}</td>
                    </tr>
                </table>
            </div>
        ";

		// Send the email
		if (wp_mail($to, $subject, $body, $headers)) {
			echo "<script>alert('Your message has been sent successfully!'); window.location='" . home_url($_SERVER['REQUEST_URI']) . "';</script>";
			exit;

		} else {
			echo 'Message failed. Please try again.';
		}
	}
});



add_action('init', function () {
	if (isset($_POST['submit_enquiry_form'])) {
		// CAPTCHA Validation
		$user_input = isset($_POST['captcha_input']) ? sanitize_text_field($_POST['captcha_input']) : '';
		$correct_answer = isset($_POST['captcha_answer']) ? sanitize_text_field($_POST['captcha_answer']) : '';
		$form_name = isset($_POST['form_name']) ? sanitize_text_field($_POST['form_name']) : '';


		// Remove fields we don't want to include in form_data
		$exclude_fields = ['form_name', 'submit_enquiry_form', 'captcha_input', 'captcha_answer'];
		if ($user_input !== $correct_answer) {
			wp_die('Incorrect CAPTCHA answer. Please go back and try again.');
		}
		rj_form_insert_data($form_name, $exclude_fields);
		// Sanitize and retrieve form data
		$name = sanitize_text_field($_POST['name']);
		$company_name = sanitize_text_field($_POST['company_name']);
		$phone = sanitize_text_field($_POST['phone']);
		$email = sanitize_email($_POST['email']);
		$region = sanitize_text_field($_POST['region']);
		$comments = sanitize_textarea_field($_POST['comments']);

		// Email setup
		$to = 'rjtraders5@hotmail.com'; // Replace with your email address
		$subject = 'New Enquiry Form Submission (RJ Traders)';
		$headers = [
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $name . ' <' . $email . '>',
		];
		$body = "
            <div style='font-family: Arial, sans-serif; font-size: 14px; color: #333;'>
                <h2 style='background: #0073aa; padding: 10px 20px; margin-bottom: 0; width: 600px; text-align: center; color: #fff; font-size: 18px;'>New Contact Form Submission</h2>
                <table style='border-collapse: collapse; width: 100%; max-width: 600px; margin: 0px 0; border: 1px solid #ddd;'>
                    <tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>Full Name</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>{$name}</td>
                    </tr>
					<tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>Company Name</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>{$company_name}</td>
                    </tr>
                    <tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>Phone No</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>{$phone}</td>
                    </tr>
                    <tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>Email Id</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>{$email}</td>
                    </tr>
					<tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>Region</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>{$region}</td>
                    </tr>
                    <tr>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center; background: #f1f1f1;'>Comments</td>
                        <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>{$comments}</td>
                    </tr>
                </table>
            </div>
        ";

		// Send the email
		if (wp_mail($to, $subject, $body, $headers)) {
			wp_redirect(add_query_arg('form_submitted', 'true', home_url($_SERVER['REQUEST_URI'])));
			exit;
		} else {
			echo 'Message failed. Please try again.';
		}
	}
});



function enqueue_custom_scripts()
{
	// Ensure jQuery is loaded
	wp_enqueue_script('jquery');
	wp_enqueue_script('modal-script', get_template_directory_uri() . '/js/modal.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'enqueue_custom_scripts');


//mail leads 
include get_template_directory() . '/admin/index.php';