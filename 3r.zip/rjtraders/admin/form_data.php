<?php
function rj_form_insert_data($form_name, $exclude_fields)
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'rj_form_data';

    $form_data = [];

    foreach ($_POST as $key => $value) {
        if (!in_array($key, $exclude_fields)) {
            $form_data[$key] = sanitize_text_field($value);
        }
    }

    // Get IP address from server
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $form_data['ip_address'] = sanitize_text_field($ip_address);

    // Convert to JSON
    $form_data_json = wp_json_encode($form_data);

    // Insert into database
    $wpdb->insert($table_name, [
        'form_name' => $form_name,
        'form_data' => $form_data_json,
    ]);
}

$ip_address = $_SERVER['REMOTE_ADDR'];
$form_data['ip_address'] = sanitize_text_field($ip_address);




