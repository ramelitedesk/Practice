<?php
include get_template_directory() . '/admin/option-page.php';
include get_template_directory() . '/admin/form_data.php';
include get_template_directory() . '/admin/admin-enqueue-scripts.php';
include get_template_directory() . '/admin/remove-formdata.php';

