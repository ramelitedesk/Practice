jQuery(document).ready(function () {
    $('.remove-email').on('click', function () {
        var removeId = $(this).data('order-id');

        $.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'remove_email',
                removeId: removeId
            },
            success: function (response) {
                console.log(response);

                if (response.success) {
                    console.log('data removed successfully');
                    location.reload();
                } else {
                    console.error('Server Error: ', response.data.message);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.error('AJAX Error:', textStatus, errorThrown);
            }
        });
    });
});