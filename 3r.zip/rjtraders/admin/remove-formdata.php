<?php
function handle_remove_email()
{
    $order_id = isset($_POST['removeId']) ? intval($_POST['removeId']) : 0;

    if (!$order_id || !is_numeric($order_id)) {
        $response = array(
            'success' => false,
            'data' => array(
                'message' => 'Invalid order ID',
            ),
        );
        wp_send_json($response);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'rj_form_data';

    $result = $wpdb->delete(
        $table_name,
        array('id' => $order_id),
        array('%d')
    );

    if ($result !== false) {
        $response = array(
            'success' => true,
            'data' => array(
                'message' => 'Data removed successfully',
            ),
        );
    } else {
        $response = array(
            'success' => false,
            'data' => array(
                'message' => 'Error removing data from the database',
            ),
        );
        error_log('Database deletion failed: ' . $wpdb->last_error);
    }

    wp_send_json($response);
}

add_action('wp_ajax_remove_email', 'handle_remove_email');
add_action('wp_ajax_nopriv_remove_email', 'handle_remove_email');