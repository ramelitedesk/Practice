<?php
function custom_admin_styles($hook)
{
    // Check if we are on the 'form-data' admin page
    if ($hook != 'toplevel_page_leads') {
        return;
    }
    wp_enqueue_style('rj-all-css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css', array(), '6.7.2');
    wp_enqueue_style('rj-dataTables-css', get_template_directory_uri() . '/css/dataTables.jqueryui.min.css', array(), '1.0.0');
    wp_enqueue_style('rj-jquery-ui-css', get_template_directory_uri() . '/css/jquery-ui.css', array(), '1.0.0');


    wp_enqueue_script('rj-jquery-min-js', get_template_directory_uri() . '/js/jquery.min.js', array(), '1.0.0', false);
    wp_enqueue_script('rj-dataTables-min-js', get_template_directory_uri() . '/js/jquery.dataTables.min.js', array(), '1.0.0', true);
    wp_enqueue_script('rj-jqueryui-min-js-js', get_template_directory_uri() . '/js/dataTables.jqueryui.min.js', array(), '1.0.0', true);
    wp_enqueue_script('rj-ajax-js', get_template_directory_uri() . '/admin/ajax.js', array(), '1.0.0', true);
    wp_localize_script('rj-ajax-js', 'ajax_object', array(
        'ajax_url' => admin_url('admin-ajax.php'),
    ));
}

add_action('admin_enqueue_scripts', 'custom_admin_styles');

?>