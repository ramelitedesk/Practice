<?php
function theme_options_page()
{
    add_menu_page(
        'Leads',
        'Leads',
        'manage_options',
        'leads',
        'show_lead__fn',
        'dashicons-media-default',
        5
    );
}
add_action('admin_menu', 'theme_options_page');


function show_lead__fn()
{
    ?>
    <style>
        .frm_container {
            position: absolute;
            top: 8%;
            left: 20%;
            transform: translate(-50%, -50%);
        }

        div#emailTable_wrapper {
            margin-top: 130px;
            padding: 1rem;

        }

        table.dataTable thead th div.DataTables_sort_wrapper span {
            display: none;
        }

        table.dataTable tbody td {
            font-weight: 400;
        }

        p {
            color: #fff;
            margin-bottom: 0.5rem;
            font-size: 1.4rem;
            text-align: center
        }

        select {
            width: 350px;
            outline: none;
            border: 1px solid #fff;
            padding: 1rem;
            font-size: 1.1rem;
            border-radius: 0.5rem;
            box-shadow: 0 1px 4px rgb(146 161 176 / 15%);
            cursor: pointer;
        }

        select:focus,
        select:hover {
            outline: none;
            border: 1px solid rgba(0, 0, 0, 0.329);
        }
    </style>
    <?php
    $frm = isset($_GET['frm']) ? $_GET['frm'] : '';
    ?>
    <div class="frm_container">
        <label for="menu-items">Form Lists</label>
        <select id="menu-items">
            <option value="">Select Form</option>
            <option value="1" <?php selected($frm, '1'); ?>>Contact Us Form</option>
            <option value="2" <?php selected($frm, '2'); ?>>Enquiry Form</option>
            <option value="3" <?php selected($frm, '3'); ?>>Home Page Form</option>

        </select>
    </div>
    <?php
    global $wpdb;
    $frm = isset($_GET['frm']) ? $_GET['frm'] : '';
    $frm_nm = '';

    if ($frm == '1') {
        $frm_nm = 'contact us form';
    } elseif ($frm == '2') {
        $frm_nm = 'enquiry form';
    } elseif ($frm == '3') {
        $frm_nm = 'home page form';
    }
    $table_name = $wpdb->prefix . 'rj_form_data';

    if (!empty($frm_nm)) {
        $query = $wpdb->prepare("SELECT * FROM $table_name WHERE form_name = %s ORDER BY id DESC", $frm_nm);
        $results = $wpdb->get_results($query, ARRAY_A);
    } else {
        // $query = "SELECT * FROM $table_name ORDER BY id DESC";
        // $results = $wpdb->get_results($query, ARRAY_A);
        echo '<p> Please Select form.</p>';
    }

    // Collect all possible keys from form_data
    $all_keys = [];
    foreach ($results as $row) {
        $form_data = json_decode($row['form_data'], true);
        if (is_array($form_data)) {
            $all_keys = array_merge($all_keys, array_keys($form_data));
        }
    }
    $all_keys = array_unique($all_keys);
    echo '<table id="emailTable" class="display" style="color: #4A4A4A;background-color: #D9EDF7;font-family:Poppins,sans-serif;font-size: 14px;font-weight: 100;">';
    echo "<thead>
    <tr style='background: #f9f9f9;'>
        <th style='border: 1px solid #ccc;'>ID</th>";

    foreach ($all_keys as $key) {
        echo "<th style='border: 1px solid #ccc;'>" . esc_html(ucfirst($key)) . "</th>";
    }

    echo "<th style='border: 1px solid #ccc;'>Date</th>
    <th style='border: 1px solid #ccc;'>Action</th>
    </tr>
    </thead>";
    echo '<tbody>';
    foreach ($results as $row) {
        $form_data = json_decode($row['form_data'], true);
        $form_nm = $row['form_name'];
        $iid = $row['id'];
        $created_at = $row['create_at'];
        $formatted_data = '';
        foreach ($form_data as $key => $value) {
            $formatted_data .= "<strong>" . esc_html($key) . "</strong>: " . esc_html($value) . "<br>";
        }

        echo "<tr>
            <td style='border: 1px solid #ccc;'>{$iid}</td>";

        foreach ($all_keys as $key) {
            $value = isset($form_data[$key]) ? esc_html($form_data[$key]) : '';
            echo "<td style='border: 1px solid #ccc;'>{$value}</td>";
        }

        echo "<td style='border: 1px solid #ccc;'>" . esc_html($created_at ?? '') . "</td>
       <td><button class='remove-email' data-Order-id='{$iid}' style='cursor:pointer;'><i class='fa-solid fa-trash'></i></button></td>
          </tr>";
    }

    echo '</tbody>';
    echo '</table>';
    ?>
    <script>
        jQuery(document).ready(function () {
            jQuery('#emailTable').DataTable({
            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const menu = document.getElementById('menu-items');
            if (menu) {
                menu.addEventListener('change', function () {
                    const formValue = this.value;
                    const redirectUrl = `https://www.rjtraders.in/wp-admin/admin.php?page=leads&frm=${formValue}`;
                    window.location.href = redirectUrl;
                });
            }
        });

    </script>
    <?php
}
?>