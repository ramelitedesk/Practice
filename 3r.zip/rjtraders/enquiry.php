<?php

/* Template Name: Enquiry Page*/


get_header();

/* Start the Loop */
while (have_posts()):
	the_post();
	?>

	<!--Page Title-->
	<section class="page-title" style="background-image:url(<?php the_post_thumbnail_url(); ?>)">
		<div class="auto-container">
			<h2><?php the_title(); ?></h2>
			<ul class="page-breadcrumb">
				<li><a href="<?php echo home_url('/'); ?>">Home</a></li>
				<li><?php the_title(); ?></li>
			</ul>
		</div>
	</section>
	<!--End Page Title-->

	<!-- Contact Page Section -->
	<section class="contact-page-section cus_bg sec_padding">
		<div class="auto-container">
			<div class="row clearfix justify-content-center">

				<!-- Form Column -->
				<div class="form-column col-lg-8 col-md-12 col-sm-12">
					<div class="inner-column">

						<!-- Contact Form -->
						<div class="contact-form res-mb-40">
							<form method="post" action="">
								<div class="row clearfix">
									<input type="hidden" name="form_name" value="enquiry form">
									<div class="col-lg-6 col-md-6 col-sm-12 form-group">
										<input type="text" name="name" placeholder="Name" required>
									</div>

									<div class="col-lg-6 col-md-6 col-sm-12 form-group">
										<input type="text" name="company_name" placeholder="Company Name" required>
									</div>

									<div class="col-lg-6 col-md-6 col-sm-12 form-group">
										<input type="email" name="email" placeholder="Email" required>
									</div>

									<div class="col-lg-6 col-md-6 col-sm-12 form-group">
										<input type="text" name="phone" placeholder="Phone" required>
									</div>

									<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<textarea name="comments" placeholder="Comments"></textarea>
									</div>

									<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<input type="text" name="region" placeholder="Region" required>
									</div>
									<input type="hidden" name="ip_address" id="visitor_ip" style="display: none;" value="">
									<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<label style="margin: 0 0 10px 0;">
											Solve: <span id="captcha_question"></span> = ?
											<span class="cap_txt">Captcha Verification</span>
											<button type="button" id="refresh_captcha"
												style="border: none; background: none; cursor: pointer;">🔄</button>
										</label>
										<input type="text" id="captcha_input" name="captcha_input"
											placeholder="Enter Captcha" required>
										<input type="hidden" id="captcha_answer" name="captcha_answer">
									</div>

									<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<button class="theme-btn btn-style-three" type="submit" name="submit_enquiry_form"
											onclick="return validateCaptcha();">Send Now</button>
									</div>

								</div>
								<div id="loading" style="display: none; margin-top: 10px">
									<div class="spinner-border" role="status">
										<span class="sr-only"></span>
									</div>
								</div>
							</form>

							<!-- Success/Failure Message -->
							<div id="response_message" style="display: none; margin-top: 10px;"></div>

							<script>
								function showLoading() {
									document.getElementById('loading').style.display = 'block';
									document.getElementById('response_message').style.display = 'none';
								}

								function closeMessage(id) {
									document.getElementById(id).style.display = 'none';
								}
							</script>
						</div>

					</div>
				</div>
			</div>

		</div>
	</section>
	<!-- End Faq Section -->

	<style>
		/* Modal Styling */
		.modal {
			position: fixed;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			background: rgba(0, 0, 0, 0.62);
			backdrop-filter: blur(5px) contrast(80%);
			padding: 20px;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
			display: none;
			z-index: 9999;
			display: flex;
			justify-content: center;
			align-items: center;
			width: 100%;
			height: 100%
		}

		.btn-close-modal {
			background-color: #4169E1;
			color: white;
			padding: 10px 20px;
			border: none;
			cursor: pointer;
		}

		.btn-close-modal:hover {
			background-color: #0073aa;
			color: white;
		}

		.modal::before {
			background: rgb(36, 38, 43);
		}

		.modal-content {
			position: relative;
			display: flex;
			flex-direction: column;
			width: 300px;
			pointer-events: auto;
			background-color: #fff;
			background-clip: padding-box;
			border: 1px solid rgba(0, 0, 0, .2);
			border-radius: .3rem;
			outline: 0;
			margin: auto;
			padding: 30px;
			text-align: center;
		}

		.cap_txt {
			color: #000;
			background: #ffd188;
			padding: 6px 10px 3px;
			margin-left: 15px;
			display: inherit;
			font-size: 13px;
			text-transform: uppercase;
			border-radius: 0;
			margin-bottom: 5px;
			line-height: 1;
			margin-right: 7px;
		}
	</style>
	<!-- Modal Structure -->
	<div id="thank-you-modal" class="modal" style="display: none;">
		<div class="modal-content">
			<img style="width:100px; margin: auto;"
				src="https://media0.giphy.com/media/iUZfNQLebVcZsJmNPZ/giphy.gif?cid=6c09b952yskahgj01pqmek9usfgcxqazy71htb8elu9fpy4t&ep=v1_stickers_search&rid=giphy.gif&ct=s">
			<h4>Thank You!</h4>
			<p style="line-height: 1.2;">Your form has been successfully submitted. We'll get back to you soon.</p>
			<a href="<?php the_permalink(285); ?>" style="border-radius: 30px; padding: 7px;"
				class="btn-close-modal">Close</a>
		</div>
	</div>

	<script>
		jQuery(document).ready(function ($) {
			// Check if the form was successfully submitted by checking the query string
			if (window.location.href.indexOf('form_submitted=true') > -1) {
				// Show the modal
				$('#thank-you-modal').fadeIn();
			}

			// Close modal on click
			$('.btn-close-modal').on('click', function () {
				$('#thank-you-modal').fadeOut();
			});
		});

	</script>


	<?php
	// get_template_part( 'template-parts/content/content-page' );

	// // If comments are open or there is at least one comment, load up the comment template.
	// if ( comments_open() || get_comments_number() ) {
	//  comments_template();
	// }
endwhile; // End of the loop.

get_footer();





