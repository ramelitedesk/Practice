<?php

/* Template Name: Contact Us Page*/


get_header();

/* Start the Loop */
while (have_posts()):
	the_post();
	?>

	<!--Page Title-->
	<section class="page-title" style="background-image:url(<?php the_post_thumbnail_url(); ?>)">
		<div class="auto-container">
			<h2><?php the_title(); ?></h2>
			<ul class="page-breadcrumb">
				<li><a href="<?php echo home_url('/'); ?>">Home</a></li>
				<li><?php the_title(); ?></li>
			</ul>
		</div>
	</section>
	<!--End Page Title-->

	<!-- Contact Page Section -->
	<section class="contact-page-section">
		<div class="auto-container">
			<div class="row clearfix">

				<!-- Form Column -->
				<div class="form-column col-lg-8 col-md-12 col-sm-12">
					<div class="inner-column">
						<!-- Sec Title -->
						<div class="sec-title">
							<div class="title-inner">
								<div class="title">Get in Touch</div>

								<h2>Contact Us</h2>
							</div>
						</div>

						<!-- Contact Form -->
						<div class="contact-form res-mb-40">
							<form method="post" action="">
								<div class="row clearfix">
									<input type="hidden" name="form_name" value="contact us form">
									<div class="col-lg-6 col-md-6 col-sm-12 form-group">
										<input type="text" name="name" placeholder="Name " required>
									</div>

									<div class="col-lg-6 col-md-6 col-sm-12 form-group">
										<input type="email" name="email" placeholder="Email " required>
									</div>

									<div class="col-lg-6 col-md-6 col-sm-12 form-group">
										<input type="text" name="subject1" placeholder="Subject " required>
									</div>

									<div class="col-lg-6 col-md-6 col-sm-12 form-group">
										<input type="text" name="phone" placeholder="Phone " required>
									</div>

									<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<textarea name="message" placeholder="Message "></textarea>
									</div>
									<input type="hidden" name="ip_address" id="visitor_ip" style="display: none;" value="">
									<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<label style="margin: 0 0 10px 0;">
											Solve: <span id="captcha_question"></span> = ?
											<span class="cap_txt">Captcha Verification</span>
											<button type="button" id="refresh_captcha"
												style="border: none; background: none; cursor: pointer;">🔄</button>
										</label>
										<input type="text" id="captcha_input" name="captcha_input"
											placeholder="Enter Captcha" required>
										<input type="hidden" id="captcha_answer" name="captcha_answer">
									</div>

									<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<button class="theme-btn btn-style-three" type="submit" name="submit_contact_form"
											onclick="return validateCaptcha();">Send Now</button>
									</div>

								</div>
								<div id="loading" style="display: none; margin-top: 10px">
									<div class="spinner-border" role="status">
										<span class="sr-only"></span>
									</div>
								</div>
							</form>

							<!-- Success/Failure Message -->
							<div id="response_message" style="display: none; margin-top: 10px;"></div>

							<script>
								function showLoading() {
									document.getElementById('loading').style.display = 'block';
									document.getElementById('response_message').style.display = 'none';
								}

								function closeMessage(id) {
									document.getElementById(id).style.display = 'none';
								}
							</script>
						</div>

					</div>
				</div>

				<!-- Info Column -->
				<div class="info-column col-lg-4 col-md-12 col-sm-12">
					<div class="inner-column">

						<!-- Sec Title -->
						<div class="sec-title">
							<div class="title-inner">
								<div class="title">Contact Us</div>
								<h2>Contact information</h2>
							</div>
						</div>

						<div class="content-boxed">
							<ul>
								<?php
								$loop = new WP_Query(
									array(
										'post_type' => 'contact-details',
										'post_status' => 'publish',
										'posts_per_page' => 1
									)
								);
								while ($loop->have_posts()):
									$loop->the_post();

									?>
									<li><span class="icon fa fa-map-marker"></span>
										<p><?php echo get_field('address'); ?></p>
									</li>
									<li><span class="icon fa fa-phone"></span><a
											href="tel:<?php echo get_field('phone_no')['phone_no_1']; ?>"
											class="alt-link-color"><?php echo get_field('phone_no')['phone_no_1']; ?></a> , <a
											href="tel:<?php echo get_field('phone_no')['phone_no_2']; ?>"
											class="alt-link-color"><?php echo get_field('phone_no')['phone_no_2']; ?></a> </li>
									<li><span class="icon fa fa-envelope"></span> <a
											href="mailto:<?php echo get_field('email_id'); ?>"
											class="alt-link-color"><?php echo get_field('email_id'); ?></a></li>

									<li><span class="icon fa fa-clock-o"></span>Operation Hours:
										<?php echo get_field('opening_hours'); ?></li>
								<?php endwhile;
								wp_reset_postdata(); ?>
							</ul>
						</div>

					</div>
				</div>

			</div>

		</div>
	</section>
	<!-- End Faq Section -->

	<style>
		/* Modal Styling */
		.modal {
			position: fixed;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			background: rgba(0, 0, 0, 0.62);
			backdrop-filter: blur(5px) contrast(80%);
			padding: 20px;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
			display: none;
			z-index: 9999;
			display: flex;
			justify-content: center;
			align-items: center;
			width: 100%;
			height: 100%
		}

		.btn-close-modal {
			background-color: #4169E1;
			color: white;
			padding: 10px 20px;
			border: none;
			cursor: pointer;
		}

		.btn-close-modal:hover {
			background-color: #0073aa;
			color: white;
		}

		.modal::before {
			background: rgb(36, 38, 43);
		}

		.modal-content {
			position: relative;
			display: flex;
			flex-direction: column;
			width: 300px;
			pointer-events: auto;
			background-color: #fff;
			background-clip: padding-box;
			border: 1px solid rgba(0, 0, 0, .2);
			border-radius: .3rem;
			outline: 0;
			margin: auto;
			padding: 30px;
			text-align: center;
		}

		.cap_txt {
			color: #000;
			background: #ffd188;
			padding: 6px 10px 3px;
			margin-left: 15px;
			display: inherit;
			font-size: 13px;
			text-transform: uppercase;
			border-radius: 0;
			margin-bottom: 5px;
			line-height: 1;
			margin-right: 7px;
		}
	</style>
	<!-- Modal Structure -->
	<div id="thank-you-modal" class="modal" style="display: none;">
		<div class="modal-content">
			<img style="width:100px; margin: auto;"
				src="https://media0.giphy.com/media/iUZfNQLebVcZsJmNPZ/giphy.gif?cid=6c09b952yskahgj01pqmek9usfgcxqazy71htb8elu9fpy4t&ep=v1_stickers_search&rid=giphy.gif&ct=s">
			<h4>Thank You!</h4>
			<p style="line-height: 1.2;">Your form has been successfully submitted. We'll get back to you soon.</p>
			<a href="<?php the_permalink(39); ?>" style="border-radius: 30px; padding: 7px;"
				class="btn-close-modal">Close</a>
		</div>
	</div>

	<script>
		jQuery(document).ready(function ($) {
			// Check if the form was successfully submitted by checking the query string
			if (window.location.href.indexOf('form_submitted=true') > -1) {
				// Show the modal
				$('#thank-you-modal').fadeIn();
			}

			// Close modal on click
			$('.btn-close-modal').on('click', function () {
				$('#thank-you-modal').fadeOut();
			});
		});

	</script>

	<!-- Contact Map Section -->
	<section class="contact-map-section">
		<div class="auto-container">
			<div class="map-outer">
				<?php
				$loop = new WP_Query(
					array(
						'post_type' => 'contact-details',
						'post_status' => 'publish',
						'posts_per_page' => 1
					)
				);
				while ($loop->have_posts()):
					$loop->the_post();

					?>
					<?php echo get_field('map'); ?>
				<?php endwhile;
				wp_reset_postdata(); ?>
			</div>
		</div>
	</section>
	<!-- End Map Section -->


	<?php
	// get_template_part( 'template-parts/content/content-page' );

	// // If comments are open or there is at least one comment, load up the comment template.
	// if ( comments_open() || get_comments_number() ) {
	//  comments_template();
	// }
endwhile; // End of the loop.

get_footer();





