<?php
get_header();
?>
<?php
$b = get_field('banner_options', 14);
if ($b):
    $i = isset($b['banner_image']) ? $b['banner_image'] : '';
    ?>
    <section class="energy__inner__banner energy__overlay custom__pad">
        <?php if (!empty($i)): ?>
            <?php
            $id = attachment_url_to_postid($i);
            if ($id):
                $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
                $t = get_the_title($id);
            endif;
            ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($i); ?>" alt="<?php echo esc_attr($alt); ?>"
                    title="<?php echo esc_attr($t); ?>" />
            </div>
        <?php endif; ?>
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-12">
                        <div class="energy__content__wrapper">

                            <div class="energy__header__title">
                                <h1><?php echo get_the_title(); ?></h1>
                            </div>
                            <nav class="energy__breadcrumb" aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                                    </li>
                                    <li  class="breadcrumb-item"><a
                                            href="<?php echo esc_url(home_url('/products')); ?>"><?php echo esc_html(get_the_title(14)); ?></a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo get_the_title(); ?>
                                    </li>
                                </ol>
                            </nav>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
endif;
while (have_posts()):
    the_post();
    $id = get_post_thumbnail_id();
    $e = get_field('title_text', get_the_ID());
    $ua = wp_get_attachment_image_src($id, 'thumbnail-size', true);
    $ur = !empty($ua) ? $ua[0] : ''; // Ensure the image URL is valid
    $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
    $t = get_the_title(); // Fetch the current post title
    $c = get_the_terms(get_the_ID(), 'product_category');
    $ta = get_the_tags();
    ?>
    <section class="energy__about-two  custom__pad">
        <div class="container">
            <div class="row g-4 g-lg-5">
                <div class="col-lg-6">
                    <?php if (!empty($ur)): ?>
                        <div class="about__content-right">
                            <div class="about__img__wrapper">
                                <img src="<?php echo esc_url($ur); ?>" title="<?php echo esc_attr($t); ?>"
                                    alt="<?php echo esc_attr($alt); ?>">
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-lg-6">
                    <div class="energy__content__wrapper">
                        <?php if (!empty($e)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($e); ?>
                            </h3>
                        <?php endif; ?>
                        <div class="energy__header__title">
                            <h2>
                                <?php the_title(); ?>
                            </h2>
                        </div>
                        <div class="cat__wrapper-one">
                            <h4>Categories:</h4>
                            <ul>
                                <?php if (!empty($c)): ?>
                                    <?php foreach ($c as $cc): ?>
                                        <?php if (is_object($cc)): ?>
                                            <li>
                                                <a href="<?php echo esc_url(get_category_link($cc->term_id)); ?>">
                                                    <?php echo esc_html($cc->name); ?>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <?php the_content(); ?>
                        <div class="details__btn__wrapper">
                            <a href="<?php echo esc_url(home_url('/contact-us')); ?>" class="energy__btn">Enquire
                                Now
                                <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                            </a>
                            <a href="<?php echo esc_url(home_url('/wp-content/uploads/2025/02/Battlink-Huaxing-Product-Brochure-2024.pdf')); ?>"
                                class="energy__btn energy__btn__one" download>Catalogue
                                <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endwhile; ?>

<?php
$co = get_field('contact_options', 14);
$f = get_field('footer_options', 'option');
$so = isset($f['social_links']) ? $f['social_links'] : array();
if ($co):
    $h = isset($co['heading_text']) ? $co['heading_text'] : '';
    $e = isset($co['texts']) ? $co['texts'] : '';
    $i = isset($co['image']) ? $co['image'] : '';
    ?>
    <section class="energy__contact-two  energy__white__text custom__pad">
        <?php if (!empty($i)): ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($i); ?>" alt="" />
            </div>
        <?php endif; ?>
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row g-xl-5 g-lg-4">
                    <div class="col-lg-6">
                        <div class="energy__content__wrapper">
                            <?php if (!empty($h)): ?>
                                <div class="energy__header__title">
                                    <h2><?php echo esc_html($h); ?></h2>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($e)): ?>
                                <p>
                                    <?php echo esc_html($e); ?>
                                </p>
                            <?php endif; ?>

                            <?php if (is_array($so) || $so): ?>
                                <div class="energy__media  white__icon">
                                    <ul>
                                        <?php foreach ($so as $l): ?>
                                            <?php
                                            if (is_array($l)):
                                                $li = isset($l['links']) ? $l['links'] : array();
                                                if (is_array($li) || !empty($li)):
                                                    $t = isset($li['title']) ? $li['title'] : '';
                                                    $ur = isset($li['url']) ? $li['url'] : '';
                                                endif;
                                                ?>
                                                <li>
                                                    <?php if (!empty($t)): ?>
                                                        <a href="<?php echo esc_url($ur); ?>" class="media__icon"><i
                                                                class="<?php echo esc_attr($t); ?>"></i></a>
                                                    <?php endif; ?>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="contact__wrapper-left">
                            <?php echo do_shortcode('[contact-form-7 id="962dc71" title="Product Contact Form" html_class="energy__contact-form"]'); ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </section>
<?php endif; ?>
<?php
$y = get_the_ID();
$pc = wp_get_post_terms($y, 'product_category');

$ci = wp_list_pluck($c, 'term_id');

$y = get_the_ID();
$pc = wp_get_post_categories($y);
$pcs = implode(',', $pc);
$as = array(
    'post_type' => 'product',
    'posts_per_page' => 4,
    'post__not_in' => array($y),
    'tax_query' => array(
        array(
            'taxonomy' => 'product_category',
            'field' => 'term_id',
            'terms' => $ci,
        ),
    ),
);
$r = new WP_Query($as);

if ($r->have_posts()):
    ?>
    <section class="energy__related custom__pad ">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="energy__content-wrapper">
                        <div class="energy__header__title">
                            <h2>Related Content</h2>
                        </div>
                        <div class="energy__slider-wrapper">
                            <div class="swiper-container energy__slider">
                                <div class="swiper-wrapper">
                                    <?php

                                    while ($r->have_posts()):
                                        $r->the_post();
                                        $id = get_post_thumbnail_id();
                                        $ri = wp_get_attachment_image_src($id, 'large');
                                        $ur = $ri[0];
                                        $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
                                        $t = get_the_title($id);
                                        ?>
                                        <div class="swiper-slide">
                                            <a href="<?php echo esc_url(get_the_permalink()); ?>"
                                                class="feature__card energy__overlay">
                                                <div class="feature__img__wrapper">
                                                    <img src="<?php echo esc_url($ur); ?>" title="<?php echo $t; ?>"
                                                        alt="<?php echo esc_attr($alt); ?>">
                                                </div>
                                                <div class="feature__content__wrapper">
                                                    <h3><?php the_title(); ?></h3>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endwhile; ?>
                                    <?php wp_reset_postdata(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
get_footer();
?>