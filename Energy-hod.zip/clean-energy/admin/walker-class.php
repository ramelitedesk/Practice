<?php

class Custom_Walker_Nav_Menu extends Walker_Nav_Menu
{
    function start_lvl(&$output, $depth = 0, $args = null)
    {
        $indent = str_repeat("\t", $depth);
        if ($depth === 0) {
            $classes = 'dropdown-menu';
            $output .= "\n$indent<ul aria-labelledby='dropdownMenuLink' class='" . esc_attr($classes) . "'>\n";
        } elseif ($depth === 1) {
            $classes = 'dropdown-menu sub-dropdown-menu';
            $output .= "\n$indent<ul role='menu' class='" . esc_attr($classes) . "'>\n";
        } else {
            $classes = '';
        }


    }

    function end_lvl(&$output, $depth = 0, $args = null)
    {
        $indent = str_repeat("\t", $depth);
        $output .= "$indent</ul>\n";
    }

    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        $indent = ($depth) ? str_repeat("\t", $depth) : '';
        $classes = empty($item->classes) ? array() : (array) $item->classes;

        if (is_object($args) && isset($args->walker) && $args->walker->has_children) {
            $classes[] = ($depth === 0) ? 'energy__menu__item nav-item dropdown' : 'nav-item dropdown';
        } else {
            $classes[] = 'energy__menu__item nav-item';
        }

        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args, $depth));
        $class_names = ' class="' . esc_attr($class_names) . '"';

        $output .= $indent . '<li' . $class_names . '>';

        $attributes = '';
        if (!empty($item->url)) {
            $attributes .= ' href="' . esc_attr($item->url) . '"';
        }
        if ($depth === 0 && is_object($args) && isset($args->walker) && $args->walker->has_children) {
            $attributes .= ' class="energy__menu__link nav-link dropdown-toggle" id="dropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false"';
        } elseif ($depth > 0) {
            $attributes .= ' class="dropdown-item menu-card"';
        } else {
            $attributes .= ' class="energy__menu__link nav-link"';
        }

        $icon_url = get_field('menu_icons', $item->ID); // Replace with your logic to fetch dynamic icons
        $title = $item->title;
        $description = get_field('menu_texts', $item->ID); // Fallback description

        $item_output = isset($args->before) ? $args->before : '';

        if ($depth > 0) {
            // Child item with menu-card structure
            $item_output .= '<a' . $attributes . '>';
            $item_output .= '<div class="menu-icon">';
            $item_output .= '<img src="' . esc_url($icon_url) . '" alt="Menu Icon" />';
            $item_output .= '</div>';
            $item_output .= '<div class="menu-content">';
            $item_output .= '<h6>' . esc_html($title) . '</h6>';
            $item_output .= '<p>' . esc_html($description) . '</p>';
            $item_output .= '</div>';
            $item_output .= '</a>';
        } else {
            // Parent item
            $item_output .= '<a' . $attributes . '>';
            $item_output .= isset($args->link_before) ? $args->link_before : '';
            $item_output .= $title;
            $item_output .= isset($args->link_after) ? $args->link_after : '';
            $item_output .= '</a>';
        }

        $item_output .= isset($args->after) ? $args->after : '';

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }


    function end_el(&$output, $item, $depth = 0, $args = null)
    {
        $output .= "</li>\n";
    }
}

?>