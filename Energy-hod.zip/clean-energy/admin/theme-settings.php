<?php


if (function_exists('acf_add_options_page')) {

	acf_add_options_page(array(
		'page_title' => 'Theme Settings',
		'menu_title' => 'Theme Settings',
		'menu_slug' => 'theme-general-settings',
		'capability' => 'edit_posts',
		'redirect' => true,
	));

	acf_add_options_sub_page(array(
		'page_title' => 'Theme Header Settings',
		'menu_title' => 'Header Settings',
		'parent_slug' => 'theme-general-settings',
	));

	acf_add_options_sub_page(array(
		'page_title' => 'Theme Footer Settings',
		'menu_title' => 'Footer Settings',
		'parent_slug' => 'theme-general-settings',
	));
	acf_add_options_sub_page(array(
		'page_title' => 'Footer Sticky Menu',
		'menu_title' => 'Footer Sticky Menu',
		'parent_slug' => 'theme-general-settings',
	));
	// acf_add_options_sub_page(array(
	// 	'page_title' => 'Post Settings',
	// 	'menu_title' => 'Post Settings',
	// 	'parent_slug' => 'edit.php',
	// ));

}

