<?php
function register_custom_post_type($post_type, $singular_name, $plural_name, $menu_icon)
{
    $labels = array(
        'name' => _x($plural_name, 'post type general name', 'your-text-domain'),
        'singular_name' => _x($singular_name, 'post type singular name', 'your-text-domain'),
        'menu_name' => _x($plural_name, 'admin menu', 'your-text-domain'),
        'name_admin_bar' => _x($singular_name, 'add new on admin bar', 'your-text-domain'),
        'add_new' => _x('Add New', $singular_name, 'your-text-domain'),
        'add_new_item' => __('Add New ' . $singular_name, 'your-text-domain'),
        'new_item' => __('New ' . $singular_name, 'your-text-domain'),
        'edit_item' => __('Edit ' . $singular_name, 'your-text-domain'),
        'view_item' => __('View ' . $singular_name, 'your-text-domain'),
        'all_items' => __('All ' . $plural_name, 'your-text-domain'),
        'search_items' => __('Search ' . $plural_name, 'your-text-domain'),
        'not_found' => __('No ' . $plural_name . ' found', 'your-text-domain'),
        'not_found_in_trash' => __('No ' . $plural_name . ' found in Trash', 'your-text-domain'),
        'parent_item_colon' => '',
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_rest ' => true,
        'query_var' => true,
        'rewrite' => array('slug' => sanitize_title($singular_name)),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        'menu_icon' => $menu_icon,
    );

    register_post_type(sanitize_title($singular_name), $args);



}

add_action('init', function () {
    register_custom_post_type('product', 'product', 'Products', 'dashicons-edit-page');
});


///custom taxonomy



function register_custom_taxonomy($post_type, $singular_name)
{
    $labels = array(
        'name' => _x('Categories', 'taxonomy general name', 'your-text-domain'),
        'singular_name' => _x('Category', 'taxonomy singular name', 'your-text-domain'),
        'search_items' => __('Search Categories', 'your-text-domain'),
        'popular_items' => __('Popular Categories', 'your-text-domain'),
        'all_items' => __('All Categories', 'your-text-domain'),
        'edit_item' => __('Edit Category', 'your-text-domain'),
        'update_item' => __('Update Category', 'your-text-domain'),
        'add_new_item' => __('Add New Category', 'your-text-domain'),
        'new_item_name' => __('New Category Name', 'your-text-domain'),
        'separate_items_with_commas' => __('Separate categories with commas', 'your-text-domain'),
        'add_or_remove_items' => __('Add or remove categories', 'your-text-domain'),
        'choose_from_most_used' => __('Choose from the most used categories', 'your-text-domain'),
        'not_found' => __('No categories found', 'your-text-domain'),
        'menu_name' => __('Categories', 'your-text-domain'),
    );

    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'public' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array('slug' => sanitize_title($singular_name) . '-category'),
    );

    register_taxonomy(sanitize_title($singular_name) . '_category', array(sanitize_title($singular_name)), $args);
}

// Hook into the 'init' action to register custom taxonomies for custom post types
add_action('init', function () {
    register_custom_taxonomy('product', 'product');

});

?>