<?php


function my_theme_styles_and_scripts()
{

    //enqueu css
    wp_enqueue_style('1energy-all-min-css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css?ver=6.6.0', array());
    wp_enqueue_style('1energy-bootstrap-min-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css', array());
    wp_enqueue_style('1energy-aos-css', 'https://unpkg.com/aos@next/dist/aos.css', array());
    wp_enqueue_style('1energy-swiper-bundle-css', 'https://cdnjs.cloudflare.com/ajax/libs/Swiper/11.0.5/swiper-bundle.css', array());
    wp_enqueue_style('1energy-fancybox-css', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css?ver=3.5.7', array());
    wp_enqueue_style('1energy-stylesheet-css', get_template_directory_uri() . '/assets/fonts/stylesheet.css', array(), _S_VERSION);
    wp_enqueue_style('1energy-style-css', get_template_directory_uri() . '/assets/css/style.css', array(), _S_VERSION);
    wp_enqueue_style('1energy-responsive-css', get_template_directory_uri() . '/assets/css/responsive.css', array(), _S_VERSION);



    wp_enqueue_script('1energy-jquery-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js', array(), time(), false);
    wp_enqueue_script('1energy-popper-min-js', 'https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js', array(), time(), true);
    wp_enqueue_script('1energy-bootstrap-min-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js', array(), time(), true);
    wp_enqueue_script('1energy-aos-js', 'https://unpkg.com/aos@next/dist/aos.js', array(), '2.3.4', true);
    wp_enqueue_script('1energy-swiper-bundle-js', 'https://cdnjs.cloudflare.com/ajax/libs/Swiper/11.0.5/swiper-bundle.min.js', array(), time(), true);
    wp_enqueue_script('1energy-fancybox-min-js', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js', array(), time(), true);
    wp_enqueue_script('1energy-custom-js', get_template_directory_uri() . '/assets/js/custom.js', array(), time(), true);

}

add_action('wp_enqueue_scripts', 'my_theme_styles_and_scripts');

?>