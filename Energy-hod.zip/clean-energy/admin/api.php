<?php
function register_api_endpoint()
{
    register_rest_route(
        'custom/v1',
        '/home-page',
        array(
            'methods' => 'GET',
            'callback' => 'get_home_page_data',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'custom/v1',
        '/why-us-page',
        array(
            'methods' => 'GET',
            'callback' => 'get_why_us_page_data',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'custom/v1',
        '/product-page',
        array(
            'methods' => 'GET',
            'callback' => 'get_product_page_data',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'custom/v1',
        '/product-category/(?P<post_title>[a-zA-Z0-9_-]+)',
        array(
            'methods' => 'GET',
            'callback' => 'get_products_category',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'custom/v1',
        '/product-detail/(?P<post_title>[a-zA-Z0-9_-]+)',
        array(
            'methods' => 'GET',
            'callback' => 'get_products_detail',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'custom/v1',
        '/sustainability-page',
        array(
            'methods' => 'GET',
            'callback' => 'get_sustainability_page_detail',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'custom/v1',
        '/faq-page',
        array(
            'methods' => 'GET',
            'callback' => 'get_faq_page_detail',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'custom/v1',
        '/oem-page',
        array(
            'methods' => 'GET',
            'callback' => 'get_oem_page_detail',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'custom/v1',
        '/contact-page',
        array(
            'methods' => 'GET',
            'callback' => 'get_contact_page_detail',
            'permission_callback' => '__return_true',
        )
    );
}
add_action('rest_api_init', 'register_api_endpoint');

function get_home_page_data()
{

    $data = [];
    $banner_options = get_field('banner_options', 10);
    $about_options = get_field('about_options', 10);
    $why_choose_option = get_field('why_choose_option', 10);
    $why_choose_card = get_field('why_choose_card', 10);
    $energy_product_options = get_field('energy_product_options', 10);
    $energy_partner_options = get_field('energy_partner_options', 10);
    $sustainability_options = get_field('sustainability_options', 10);
    $cta_option = get_field('cta_option', 10);
    $large_range_products = get_field('large_range_products', 10);
    $cta2_option = get_field('cta2_option', 10);
    $faq_options = get_field('faq_options', 10);
    $accordions = get_field('accordions', 10);
    $faq_feature_card_options = get_field('faq_feature_card_options', 10);
    $green_energy__options = get_field('green_energy__options', 10);
    $contact_options = get_field('contact_options', 10);
    $energy_transitions = get_field('energy_transitions', 10);
    $data = [
        'home_page' => [
            'banner' => $banner_options,
            'about' => $about_options,
            'why_choose_us' => $why_choose_option,
            'why_choose_card' => $why_choose_card,
            'energy_suite' => $energy_product_options,
            'our_promise' => $energy_partner_options,
            'sustainability' => $sustainability_options,
            'cta' => $cta_option,
            'our_product' => $large_range_products,
            'counter' => $cta2_option,
            'faqs' => $faq_options,
            'accordion' => $accordions,
            'feature_card' => $faq_feature_card_options,
            'green_energy' => $green_energy__options,
            'contact' => $contact_options,
            'energy_transition' => $energy_transitions,
        ]
    ];
    return new WP_REST_Response($data, 200);
}

function get_why_us_page_data()
{
    $data = [];
    $banner_options = get_field('banner_options', 20);
    $button = get_field('benefit_section_button', 20);
    $benifit_options = get_field('benifit_options', 20);
    $what_we_do_option = get_field('what_we_do_option', 20);
    $why_choose_cards = get_field('why_choose_cards', 20);
    $clean_energy_options = get_field('clean_energy_options', 20);
    $work_with_us_option = get_field('work_with_us_option', 20);
    $cta_options = get_field('cta_options', 20);
    $energy_cards = get_field('energy_cards', 20);
    $wheading_text = $what_we_do_option['heading_text'];
    $wtitle_text = $what_we_do_option['title_text'];
    $wtexts = $what_we_do_option['texts'];


    $benefit_heading_text = $benifit_options['benefit_heading_text'];
    $benefit_title_text = $benifit_options['benefit_title_text'];
    $benefit_texts = $benifit_options['benefit_texts'];
    $our_mission_options = $benifit_options['our_mission_options'];
    $our_vision_options = $benifit_options['our_vision_options'];
    $heading_text = $our_mission_options['heading_text'];
    $title_text = $our_mission_options['title_text'];
    $texts = $our_mission_options['texts'];
    $textsection = [];
    $mission = [];
    $why_choose = [];
    $textsection = [
        'button' => $button,
        'benefit_heading_text' => $benefit_heading_text,
        'benefit_title_text' => $benefit_title_text,
        'benefit_texts' => wp_strip_all_tags($benefit_texts),
    ];
    $mission = [
        'heading_text' => $heading_text,
        'title_text' => $title_text,
        'texts' => wp_strip_all_tags($texts)
    ];
    $why_choose = [
        'heading_text' => $wheading_text,
        'title_text' => $wtitle_text,
        'texts' => wp_strip_all_tags($wtexts)
    ];

    $data = [
        'why_us_page' => [
            'banner' => $banner_options,
            'our_edge' => $textsection,
            'our_mission' => $mission,
            'our_vission' => $our_vision_options,
            'what_do_we_do' => $why_choose,
            'why_choose_cards' => $why_choose_cards,
            'clean_energy' => $clean_energy_options,
            'work_with_us' => $work_with_us_option,
            'cta' => $cta_options,
            'energy_products' => $energy_cards,
        ]
    ];
    return new WP_REST_Response($data, 200);
}
function get_product_page_data($request)
{
    $data = [];
    $banner_options = get_field('banner_options', 14);
    $category_options = get_field('category_options', 14);
    $cta_options = get_field('cta_options', 14);
    $contact_options = get_field('contact_options', 14);
    $pr = array(
        'taxonomy' => 'product_category',
        'orderby' => 'date',
        'order' => 'DESC',
        'hide_empty' => false,
        'parent' => 0,
    );
    $pro = get_terms($pr);
    $pri = ['Container ESS', 'C&I ESS', 'Residential ESS', 'Photovoltaic System'];

    // Sort categories based on the priority
    usort($pro, function ($a, $b) use ($pri) {
        $pos_a = array_search($a->name, $pri);
        $pos_b = array_search($b->name, $pri);

        if ($pos_a === false && $pos_b === false) {
            return strcmp($a->name, $b->name); // Alphabetical for others
        }

        return ($pos_a === false ? PHP_INT_MAX : $pos_a) - ($pos_b === false ? PHP_INT_MAX : $pos_b);
    });

    $product_cat = [];
    $img = [];
    foreach ($pro as $c) {
        if (is_object($c)) {
            $n = $c->name;
            $i = $c->term_id;
            $s = $c->slug;
            $ss = str_replace('-', '_', $s);
            $u = get_field('thumbnail_image', 'product_category_' . $i);
            $id = attachment_url_to_postid($u);
            $alt = $t = '';

            if ($id) {
                $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
                $t = get_the_title($id);
            }
            $link = get_term_link($i);
            if (is_wp_error($link)) {
                $link = '';
            }
            $img = [
                'url' => $u,
                'alt' => $alt,
                'title' => $t
            ];
            $ch = get_terms(array(
                'taxonomy' => 'product_category',
                'orderby' => 'date',
                'order' => 'ASC',
                'hide_empty' => false,
                'parent' => $c->term_id,
            ));


            $ch_data = [];
            foreach ($ch as $ccc) {
                $ch_data[] = [
                    'name' => $ccc->name,
                    'slug' => $ccc->slug,
                    'id' => $ccc->term_id
                ];
            }

            $product_cat[$ss] = [
                'img' => $img,
                'id' => $i,
                'name' => $n,
                'slug' => $s,
                'link' => $link,
                'child_categories' => $ch_data
            ];
        }
    }


    $paged = $request->get_param('page') ? intval($request->get_param('page')) : 1;

    $args = array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => 9,
        'paged' => $paged,
        'order' => 'DESC',
    );

    $query = new WP_Query($args);
    $products = [];
    $all_products = [];

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();

            $post_id = get_the_ID();
            $thumb_id = get_post_thumbnail_id($post_id);
            $thumb = wp_get_attachment_image_src($thumb_id, 'thumbnail');
            $img_url = $thumb ? $thumb[0] : '';
            $img_alt = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);
            $img_title = get_the_title($thumb_id);

            $products[] = [
                'id' => $post_id,
                'name' => get_the_title(),
                'slug' => get_post_field('post_name', $post_id),
                'content' => wp_trim_words(get_the_content(), 15, '...'),
                'link' => get_the_permalink(),
                'img' => [
                    'url' => $img_url,
                    'alt' => $img_alt,
                    'title' => $img_title,
                ]
            ];
        }
        wp_reset_postdata();
    }

    $all_products = [
        'products' => $products,
        'limit' => 9,
        'page' => $paged,
        'totalPages' => $query->max_num_pages,
    ];
    $data = [
        'product_page' => [
            'banner' => $banner_options,
            'category_text' => $category_options,
            'cta' => $cta_options,
            'contact' => $contact_options,
            'categories' => $product_cat,
            'all_products' => $all_products,

        ]
    ];
    return new WP_REST_Response($data, 200);
}

function get_products_category($request)
{
    $slug = $request['post_title'];
    $paged = $request->get_param('page') ? intval($request->get_param('page')) : 1;

    $ar = array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => 9,
        'order' => 'DESC',
        'paged' => $paged,
        'tax_query' => array(
            array(
                'taxonomy' => 'product_category',
                'field' => 'slug',
                'terms' => $slug,
                'include_children' => true,
            ),
        ),
    );
    $q = new WP_Query($ar);

    $products = [];
    if ($q->have_posts()) {
        while ($q->have_posts()) {
            $q->the_post();
            $post_id = get_the_ID();
            $thumb_id = get_post_thumbnail_id($post_id);
            $thumb = wp_get_attachment_image_src($thumb_id, 'thumbnail');
            $img_url = $thumb ? $thumb[0] : '';
            $img_alt = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);
            $img_title = get_the_title($thumb_id);

            $products[] = [
                'id' => $post_id,
                'name' => get_the_title(),
                'slug' => get_post_field('post_name', $post_id),
                'content' => wp_trim_words(get_the_content(), 15, '...'),
                'link' => get_the_permalink(),
                'img' => [
                    'url' => $img_url,
                    'alt' => $img_alt,
                    'title' => $img_title,
                ]
            ];
        }
        wp_reset_postdata();
    }

    return new WP_REST_Response([
        'products' => $products,
        'limit' => 9,
        'page' => $paged,
        'totalPages' => $q->max_num_pages,
    ], 200);
}

function get_products_detail($request)
{
    $slug = $request['post_title'];
    $sslug = strtolower(str_replace('_', '-', $slug));
    $args = array(
        'name' => $sslug,
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => 9,
        'orderby' => 'date',
        'order' => 'ASC',
    );
    $query = new WP_Query($args);
    $blogs = $query->posts[0];
    $image = wp_get_attachment_image_src(get_post_thumbnail_id($blogs->ID), 'large');
    $additional_meta_data = get_field('additional_meta_data', $blogs->ID);
    // Prepare the blog post details
    $blog_details = array(
        'id' => $blogs->ID,
        'title' => $blogs->post_title,
        'content' => $blogs->post_content,
        'excerpt' => $blogs->post_excerpt,
        'thumbnail' => $image ? $image[0] : '',
        'date' => get_the_date('Y-m-d', $blogs->ID),
        'author' => get_the_author_meta('display_name', $blogs->post_author),
        'categories' => wp_get_post_terms($blogs->ID, 'product_category', array('fields' => 'names')),
        'metadata' => $additional_meta_data
    );

    $c = get_the_terms($blogs->ID, 'product_category');
    $ci = wp_list_pluck($c, 'term_id');
    $y = $blogs->ID;
    $as = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'post__not_in' => array($y),
        'tax_query' => array(
            array(
                'taxonomy' => 'product_category',
                'field' => 'term_id',
                'terms' => $ci,
            ),
        ),
    );
    $r = new WP_Query($as);
    $recent_posts = [];
    if ($r->have_posts()):
        while ($r->have_posts()):
            $r->the_post();
            $id = get_post_thumbnail_id();
            $ri = wp_get_attachment_image_src($id, 'large');
            $ur = $ri[0];
            $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
            $t = get_the_title($id);
            $recent_posts[] = array(
                'id' => get_the_ID(),
                'name' => get_the_title(),
                'slug' => get_post_field('post_name', get_the_ID()),
                'content' => wp_trim_words(get_the_content(), 15, '...'),
                'link' => get_the_permalink(),
                'img' => [
                    'url' => $ur,
                    'alt' => $alt,
                    'title' => $t,
                ]
            );
        endwhile;
    endif;

    // Return both blog details and recent posts
    return new WP_REST_Response(array(
        'product_details' => $blog_details,
        'recent_posts' => $recent_posts
    ), 200);
}


function get_sustainability_page_detail()
{
    $data = [];
    $banner_options = get_field('banner_options', 15);
    $energy_business_options = get_field('energy_business_options', 15);
    $our_values_options = get_field('our_values_options', 15);
    $cta_options = get_field('cta_options', 15);
    $cta_options2 = get_field('cta_options2', 15);
    $save_the_world = get_field('save_the_world', 15);
    $energy_transition = get_field('energy_transition', 15);
    $cta = [];
    $cta = [
        'heading_texts' => $cta_options2['heading_texts'],
        'title_texts' => $cta_options2['title_texts'],
        'texts' => wp_strip_all_tags($cta_options2['texts']),
        'image' => $cta_options2['image'],
        'button_title' => $cta_options2['button_link']['title'],
        'button_link' => $cta_options2['button_link']['url'],
    ];
    $data = [
        'sustainability_page' => [
            'banner' => $banner_options,
            'new_reality' => $energy_business_options,
            'our_values' => $our_values_options,
            'cta' => $cta_options,
            'cta2' => $cta,
            'save_the_world' => $save_the_world,
            'energy_transition' => $energy_transition,
        ]
    ];
    return new WP_REST_Response($data, 200);
}
function get_faq_page_detail()
{
    $data = [];
    $banner_options = get_field('banner_options', 1066);
    $accordions = get_field('accordions', 1066);
    $faq_options = get_field('faq_options', 1066);

    $data = [
        'faq_page' => [
            'banner' => $banner_options,
            'accordions' => $accordions,
            'faq_options' => $faq_options
        ]
    ];
    return new WP_REST_Response($data, 200);
}
function get_oem_page_detail()
{
    $data = [];
    $banner_options = get_field('banner_options', 2094);
    $bioenergy_options = get_field('bioenergy_options', 2094);
    $energy_solution_options = get_field('energy_solution_options', 2094);
    $bioenergy_and_green_energy = get_field('bioenergy_and_green_energy', 2094);
    $contact_options = get_field('contact_options', 2094);
    $energy_transition = get_field('energy_transition', 2094);
    $cont = [];

    $heading_text = $contact_options['heading_text'];
    $title_text = $contact_options['title_text'];
    $texts = $contact_options['texts'];
    $contact_info = $contact_options['contact_info'];
    $bg_image_1 = $contact_options['bg_image_1'];
    $bg_image_2 = $contact_options['bg_image_2'];
    $cont = [
        'heading_text' => $heading_text,
        'title_text' => $title_text,
        'texts' => wp_strip_all_tags($texts),
        'contact_info' => $contact_info,
        'bg_image_1' => $bg_image_1,
        'bg_image_2' => $bg_image_2,
    ];
    $data = [
        'oem_page' => [
            'banner' => $banner_options,
            'bioenergy_options' => $bioenergy_options,
            'clean_energy' => $energy_solution_options,
            'bioenergy_and_green_energy' => $bioenergy_and_green_energy,
            'contact_options' => $cont,
            'energy_transition' => $energy_transition,
        ]
    ];
    return new WP_REST_Response($data, 200);
}
function get_contact_page_detail()
{
    $data = [];
    $banner_options = get_field('banner_options', 18);
    $contact_options = get_field('contact_options', 18);
    $contact_info = get_field('contact_info', 18);
  
    $data = [
        'contact_page' => [
            'banner' => $banner_options,
            'contact_options' => $contact_options,
            'contact_info' => $contact_info,
            'map' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3305.119266755374!2d-118.38491482428299!3d34.06645677315165!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c2b9503479c53d%3A0x43caa8b4ef0a427!2s8730%20Wilshire%20Blvd%2C%20Beverly%20Hills%2C%20CA%2090211%2C%20USA!5e0!3m2!1sen!2sin!4v1731043850714!5m2!1sen!2sin',
        ]
    ];
    return new WP_REST_Response($data, 200);
}