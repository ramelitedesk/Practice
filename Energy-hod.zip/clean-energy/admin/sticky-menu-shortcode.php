<?php
function sticky_menu_shortcode()
{
    ob_start();
    ?>
    <section class="footer__menu footer__menu-sticky dark-mode__mob d-md-none d-block">
        <div class="container-fluid">
            <div class="row">
                <?php
                $fa = get_field('factory', 'option');
                if ($fa):
                    $i = isset($fa['icon']) ? $fa['icon'] : '';
                    $t = isset($fa['title']) ? $fa['title'] : '';
                    $o = isset($fa['office_locations']) ? $fa['office_locations'] : array();
                    ?>
                    <div class="col-sm-3 col-3">
                        <div class="footer__menu-wrap">
                            <div aria-label="Offcanvas navbar large" class="footer__menu-box ">
                                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas"
                                    data-bs-target="#offcanvasFooterNav1" aria-controls="offcanvasFooterNav1">
                                    <?php if (!empty($i)): ?>
                                        <img src="<?php echo esc_url($i); ?>">
                                    <?php endif; ?>
                                    <?php if (!empty($t)): ?>
                                        <span class="text"><?php echo esc_html($t); ?></span>
                                    <?php endif; ?>
                                </button>
                                <div class="offcanvas offcanvas-bottom" tabindex="-1" id="offcanvasFooterNav1"
                                    aria-labelledby="offcanvasFooterNav1Label">
                                    <div class="offcanvas-header">
                                        <button class="footer__off-close" type="button" data-bs-dismiss="offcanvas"
                                            aria-label="Close">
                                            <svg width="30" height="30" viewBox="0 0 32 32" version="1.1"
                                                xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                                xmlns:sketch="http://www.bohemiancoding.com/sketch/ns">
                                                <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"
                                                    sketch:type="MSPage">
                                                    <g id="Icon-Set-Filled" sketch:type="MSLayerGroup"
                                                        transform="translate(-570.000000, -1089.000000)" fill="#000000">
                                                        <path
                                                            d="M591.657,1109.24 C592.048,1109.63 592.048,1110.27 591.657,1110.66 C591.267,1111.05 590.633,1111.05 590.242,1110.66 L586.006,1106.42 L581.74,1110.69 C581.346,1111.08 580.708,1111.08 580.314,1110.69 C579.921,1110.29 579.921,1109.65 580.314,1109.26 L584.58,1104.99 L580.344,1100.76 C579.953,1100.37 579.953,1099.73 580.344,1099.34 C580.733,1098.95 581.367,1098.95 581.758,1099.34 L585.994,1103.58 L590.292,1099.28 C590.686,1098.89 591.323,1098.89 591.717,1099.28 C592.11,1099.68 592.11,1100.31 591.717,1100.71 L587.42,1105.01 L591.657,1109.24 L591.657,1109.24 Z M586,1089 C577.163,1089 570,1096.16 570,1105 C570,1113.84 577.163,1121 586,1121 C594.837,1121 602,1113.84 602,1105 C602,1096.16 594.837,1089 586,1089 L586,1089 Z"
                                                            id="cross-circle" sketch:type="MSShapeGroup">
                                                        </path>
                                                    </g>
                                                </g>
                                            </svg>
                                        </button>
                                    </div>
                                    <div class="offcanvas-body">
                                        <div class="footer__menu-offices">
                                            <div class="footer__office-wrap">

                                                <?php if (is_array($o)): ?>
                                                    <?php foreach ($o as $k => $ol): ?>
                                                        <?php
                                                        if (is_array($ol)):
                                                            $oi = isset($ol['image']) ? $ol['image'] : '';
                                                            $ot = isset($ol['title']) ? $ol['title'] : '';
                                                            $oa = isset($ol['address']) ? $ol['address'] : '';
                                                            $oc = isset($ol['contact']) ? $ol['contact'] : array();
                                                            $oe = isset($ol['email']) ? $ol['email'] : array();
                                                            ?>
                                                            <div class="footer__office-box">
                                                                <div class="title">
                                                                    <?php if (!empty($oi)): ?>
                                                                        <span class="icon">
                                                                            <img src="<?php echo esc_url($oi); ?>" alt="">
                                                                        </span>
                                                                    <?php endif; ?>
                                                                    <?php if (!empty($ot)): ?>
                                                                        <h5><?php echo esc_html($ot); ?></h5>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <?php if (!empty($oa) || !empty($oc) || !empty($oe)): ?>
                                                                    <ul class="footer__contact-list" style="display:flex">
                                                                        <?php if (!empty($oa)): ?>
                                                                            <li>
                                                                                <span><i class="fas fa-map-marker-alt"></i></span>
                                                                                <?php echo esc_html($oa); ?>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if (is_array($oc)): ?>
                                                                            <?php if (!empty($oc['title'])): ?>
                                                                                <li>
                                                                                    <a href=" <?php echo esc_url($oc['url']); ?> ">
                                                                                        <span><i class="fas fa-phone"></i></span>
                                                                                        <?php echo esc_html($oc['title']); ?> </a>
                                                                                </li>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                        <?php if (is_array($oe)): ?>
                                                                            <?php if (!empty($oe['title'])): ?>
                                                                                <li>
                                                                                    <a href="<?php echo esc_url($oe['url']); ?>">
                                                                                        <span><i class="fas fa-envelope"></i></span>
                                                                                        <?php echo esc_html($oe['title']); ?> </a>
                                                                                </li>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    </ul>
                                                                <?php endif; ?>
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <?php
                $fo = get_field('factory_option', 'option');
                if ($fo):
                    $i = $fo['icon'] ?? '';
                    $t = $fo['title'] ?? '';
                    $o = $fo['office_locations'] ?? [];
                    ?>
                    <div class="col-sm-3 col-3">
                        <div class="footer__menu-wrap">
                            <div aria-label="Offcanvas navbar large" class="footer__menu-box">
                                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas"
                                    data-bs-target="#offcanvasFooterNav2" aria-controls="offcanvasFooterNav2">
                                    <?php if (!empty($i)): ?>
                                        <img src="<?php echo esc_url($i); ?>" alt="">
                                    <?php endif; ?>
                                    <?php if (!empty($t)): ?>
                                        <span class="text"><?php echo esc_html($t); ?></span>
                                    <?php endif; ?>
                                </button>
                                <div class="offcanvas offcanvas-bottom" tabindex="-1" id="offcanvasFooterNav2"
                                    aria-labelledby="offcanvasFooterNav2Label">
                                    <div class="offcanvas-header">
                                        <button class="footer__off-close" type="button" data-bs-dismiss="offcanvas"
                                            aria-label="Close">
                                            <svg width="30" height="30" viewBox="0 0 32 32" version="1.1"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <g fill="#000000">
                                                    <path
                                                        d="M591.657,1109.24 C592.048,1109.63 592.048,1110.27 591.657,1110.66 ..." />
                                                </g>
                                            </svg>
                                        </button>
                                    </div>
                                    <div class="offcanvas-body">
                                        <div class="footer__factory-wrap">
                                            <div class="accordion accordion-flush" id="accordionFlushExample">
                                                <?php if (!empty($o) && is_array($o)): ?>
                                                    <?php foreach ($o as $ke => $ol): ?>
                                                        <?php
                                                        if (is_array($ol)):
                                                            $oi = $ol['image'] ?? '';
                                                            $ot = $ol['title'] ?? '';
                                                            $oc = $ol['counter'] ?? [];
                                                            ?>
                                                            <div class="accordion-item">
                                                                <h2 class="accordion-header" id="flush-heading_<?php echo $ke; ?>">
                                                                    <button class="accordion-button collapsed" type="button"
                                                                        data-bs-toggle="collapse"
                                                                        data-bs-target="#flush-collapse_<?php echo $ke; ?>"
                                                                        aria-expanded="false"
                                                                        aria-controls="flush-collapse_<?php echo $ke; ?>">
                                                                        <div class="footer__factory-title">
                                                                            <?php if (!empty($oi)): ?>
                                                                                <img src="<?php echo esc_url($oi); ?>" alt="">
                                                                            <?php endif; ?>
                                                                            <?php if (!empty($ot)): ?>
                                                                                <?php echo esc_html($ot); ?>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </button>
                                                                </h2>
                                                                <div id="flush-collapse_<?php echo $ke; ?>"
                                                                    class="accordion-collapse collapse"
                                                                    aria-labelledby="flush-heading_<?php echo $ke; ?>"
                                                                    data-bs-parent="#accordionFlushExample">
                                                                    <div class="accordion-body">
                                                                        <div class="footer__factory-content">
                                                                            <ul>
                                                                                <?php foreach ($oc as $co): ?>
                                                                                    <?php if (is_array($co)): ?>
                                                                                        <?php
                                                                                        $cot = $co['title'] ?? '';
                                                                                        $p = isset($co['percentage_number']) ? (int) $co['percentage_number'] : 0;
                                                                                        if (!empty($cot)):
                                                                                            ?>
                                                                                            <li>
                                                                                                <h5><?php echo esc_html($cot); ?>
                                                                                                    <span><?php echo $p; ?>%</span>
                                                                                                </h5>
                                                                                                <div class="progress" role="progressbar"
                                                                                                    aria-label="Basic example"
                                                                                                    aria-valuenow="<?php echo $p; ?>" aria-valuemin="0"
                                                                                                    aria-valuemax="100">
                                                                                                    <div class="progress-bar"
                                                                                                        style="width: <?php echo $p; ?>%"></div>
                                                                                                </div>
                                                                                            </li>
                                                                                        <?php endif; ?>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; ?>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <?php
                $opt = get_field('contact_option', 'option');
                if ($opt):
                    $i = isset($opt['icon']) ? $opt['icon'] : '';
                    $t = isset($opt['title']) ? $opt['title'] : '';
                    $coi = isset($opt['contact_image']) ? $opt['contact_image'] : '';
                    $o = isset($opt['office_locations']) ? $opt['office_locations'] : array();
                    ?>
                    <div class="col-sm-3 col-3">
                        <div class="footer__menu-wrap">
                            <div aria-label="Offcanvas navbar large" class="footer__menu-box ">
                                <button class="navbar-toggler " type="button" data-bs-toggle="offcanvas"
                                    data-bs-target="#offcanvasFooterNav3" aria-controls="offcanvasFooterNav3">
                                    <?php if (!empty($i)): ?>
                                        <img src="<?php echo esc_url($i); ?>">
                                    <?php endif; ?>
                                    <?php if (!empty($t)): ?>
                                        <span class="text"><?php echo esc_html($t); ?></span>
                                    <?php endif; ?>
                                </button>
                                <div class="offcanvas offcanvas-bottom" tabindex="-1" id="offcanvasFooterNav3"
                                    aria-labelledby="offcanvasFooterNav3Label">
                                    <div class="offcanvas-header">
                                        <button class="footer__off-close" type="button" data-bs-dismiss="offcanvas"
                                            aria-label="Close">
                                            <svg width="30" height="30" viewBox="0 0 32 32" version="1.1"
                                                xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                                xmlns:sketch="http://www.bohemiancoding.com/sketch/ns">
                                                <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"
                                                    sketch:type="MSPage">
                                                    <g id="Icon-Set-Filled" sketch:type="MSLayerGroup"
                                                        transform="translate(-570.000000, -1089.000000)" fill="#000000">
                                                        <path
                                                            d="M591.657,1109.24 C592.048,1109.63 592.048,1110.27 591.657,1110.66 C591.267,1111.05 590.633,1111.05 590.242,1110.66 L586.006,1106.42 L581.74,1110.69 C581.346,1111.08 580.708,1111.08 580.314,1110.69 C579.921,1110.29 579.921,1109.65 580.314,1109.26 L584.58,1104.99 L580.344,1100.76 C579.953,1100.37 579.953,1099.73 580.344,1099.34 C580.733,1098.95 581.367,1098.95 581.758,1099.34 L585.994,1103.58 L590.292,1099.28 C590.686,1098.89 591.323,1098.89 591.717,1099.28 C592.11,1099.68 592.11,1100.31 591.717,1100.71 L587.42,1105.01 L591.657,1109.24 L591.657,1109.24 Z M586,1089 C577.163,1089 570,1096.16 570,1105 C570,1113.84 577.163,1121 586,1121 C594.837,1121 602,1113.84 602,1105 C602,1096.16 594.837,1089 586,1089 L586,1089 Z"
                                                            id="cross-circle" sketch:type="MSShapeGroup">
                                                        </path>
                                                    </g>
                                                </g>
                                            </svg>
                                        </button>
                                    </div>
                                    <div class="offcanvas-body">
                                        <div class="footer__menu-qc">
                                            <ul>
                                                <?php foreach ($o as $cl): ?>
                                                    <?php
                                                    $im = isset($cl['image']) ? $cl['image'] : '';
                                                    $l = isset($cl['contact_link']) ? $cl['contact_link'] : array();
                                                    ?>
                                                    <li>
                                                        <a href="<?php echo esc_url($l['url']); ?>">
                                                            <div class="qc-right">
                                                                <span class="icon">
                                                                    <img src="<?php echo esc_url($im); ?>" alt="...">
                                                                </span>
                                                                <h5><?php echo esc_html($l['title']); ?></h5>
                                                            </div>
                                                        </a>
                                                    </li>
                                                <?php endforeach; ?>
                                                <li>
                                                    <a href="#url" data-bs-toggle="modal"
                                                        data-bs-target="#footerMenuContactModal">
                                                        <div class="qc-right">
                                                            <span class="icon">
                                                                <img src="<?php echo esc_url($coi); ?>" alt="...">
                                                            </span>
                                                            <h5>Contact Form</h5>
                                                        </div>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="col-sm-3 col-3">
                    <div class="footer__menu-wrap">
                        <div class="footer__menu-box">
                            <button id="myLauncher" class="navbar-toggler " onclick="openWidget()" type="button">
                                <?php
                                $ch = get_field('chat_options', 'option');
                                ?>
                                <img src="<?php echo esc_url($ch['image']); ?>">
                                <span class="text">Chat</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php
    return ob_get_clean();
}
add_shortcode('sticky_menu_shortcode', 'sticky_menu_shortcode');
?>