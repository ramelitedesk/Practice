<?php

include get_template_directory() . '/admin/nav-menu.php';
include get_template_directory() . '/admin/walker-class.php';
include get_template_directory() . '/admin/theme-settings.php';
include get_template_directory() . '/admin/enqueue-css-js.php';
include get_template_directory() . '/admin/cpt.php';
include get_template_directory() . '/admin/sticky-menu-shortcode.php';
// include get_template_directory() . '/admin/jwt-token.php';
include get_template_directory() . '/admin/acf-option-endpoint.php';
include get_template_directory() . '/admin/api.php';

function wpdocs_remove_menus()
{

	remove_menu_page('edit.php');
}
add_action('admin_menu', 'wpdocs_remove_menus');
//custom function
function pr($val)
{
	echo '<pre>';
	print_r($val);
	echo '<pre>';
}



add_filter('wpcf7_form_elements', 'remove_cf7_paragraph_tags_for_location');
function remove_cf7_paragraph_tags_for_location($content)
{
	$content = preg_replace('/<\/?p>\s*(<\/?br\s*\/?>)?/', '', $content);
	$content = preg_replace('/<\/?span[^>]*>/', '', $content);
	$content = preg_replace('/<span(?! class="wpcf7-spinner")[^>]*>/', '', $content);
	return $content;
}
