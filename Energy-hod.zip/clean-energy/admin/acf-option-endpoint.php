<?php
function register_cf7_data_endpoint()
{
    register_rest_route(
        'wp/v2',
        '/header',
        array(
            'methods' => 'GET',
            'callback' => 'get_header_details',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'wp/v2',
        '/footer',
        array(
            'methods' => 'GET',
            'callback' => 'get_footer_details',
            'permission_callback' => '__return_true',
        )
    );

    register_rest_route(
        'wp/v2',
        '/text-section',
        array(
            'methods' => 'GET',
            'callback' => 'get_why_us_textsection',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'wp/v2',
        '/pro-cat',
        array(
            'methods' => 'GET',
            'callback' => 'product_categories',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'wp/v2',
        '/all-products',
        array(
            'methods' => 'GET',
            'callback' => 'get_all_products',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'wp/v2',
        '/products/(?P<post_title>[a-zA-Z0-9_-]+)',
        array(
            'methods' => 'GET',
            'callback' => 'get_products_by_category',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'wp/v2',
        '/single-products/(?P<post_title>[a-zA-Z0-9_-]+)',
        array(
            'methods' => 'GET',
            'callback' => 'get_single_products',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'wp/v2',
        '/sticky-footer/offices',
        array(
            'methods' => 'GET',
            'callback' => 'get_office_details',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'wp/v2',
        '/sticky-footer/factories',
        array(
            'methods' => 'GET',
            'callback' => 'get_factory_details',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'wp/v2',
        '/sticky-footer/contact-options',
        array(
            'methods' => 'GET',
            'callback' => 'get_contact_details',
            'permission_callback' => '__return_true',
        )
    );
}
add_action('rest_api_init', 'register_cf7_data_endpoint');



function get_header_details($data)
{
    $header = get_field('header_options', 'option');
    $data = [];
    $data = [
        'header' => $header
    ];

    return new WP_REST_Response($data, 200);
}
function get_footer_details($data)
{
    $footer = get_field('footer_options', 'option');
    $data = [];
    $data = [
        'footer' => $footer
    ];

    return new WP_REST_Response($data, 200);
}
function get_why_us_textsection($data)
{
    $button = get_field('benefit_section_button', 20);
    $benifit_options = get_field('benifit_options', 20);
    $benefit_heading_text = $benifit_options['benefit_heading_text'];
    $benefit_title_text = $benifit_options['benefit_title_text'];
    $benefit_texts = $benifit_options['benefit_texts'];
    $textsection = [];
    $textsection = [
        'button' => $button,
        'benefit_heading_text' => $benefit_heading_text,
        'benefit_title_text' => $benefit_title_text,
        'benefit_texts' => $benefit_texts,
    ];
    $data = [
        'footer' => $textsection
    ];

    return new WP_REST_Response($data, 200);
}
function product_categories($data)
{
    $pr = array(
        'taxonomy' => 'product_category',
        'orderby' => 'date',
        'order' => 'DESC',
        'hide_empty' => false,
        'parent' => 0,
    );
    $pro = get_terms($pr);
    $pri = ['Container ESS', 'C&I ESS', 'Residential ESS', 'Photovoltaic System'];

    // Sort categories based on the priority
    usort($pro, function ($a, $b) use ($pri) {
        $pos_a = array_search($a->name, $pri);
        $pos_b = array_search($b->name, $pri);

        if ($pos_a === false && $pos_b === false) {
            return strcmp($a->name, $b->name); // Alphabetical for others
        }

        return ($pos_a === false ? PHP_INT_MAX : $pos_a) - ($pos_b === false ? PHP_INT_MAX : $pos_b);
    });

    $data = [];
    $img = [];
    foreach ($pro as $c) {
        if (is_object($c)) {
            $n = $c->name;
            $i = $c->term_id;
            $s = $c->slug;
            $u = get_field('thumbnail_image', 'product_category_' . $i);
            $id = attachment_url_to_postid($u);
            $alt = $t = '';

            if ($id) {
                $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
                $t = get_the_title($id);
            }
            $link = get_term_link($i);
            if (is_wp_error($link)) {
                $link = '';
            }
            $img = [
                'url' => $u,
                'alt' => $alt,
                'title' => $t
            ];
            $ch = get_terms(array(
                'taxonomy' => 'product_category',
                'orderby' => 'date',
                'order' => 'ASC',
                'hide_empty' => false,
                'parent' => $c->term_id,
            ));


            $ch_data = [];
            foreach ($ch as $ccc) {
                $ch_data[] = [
                    'name' => $ccc->name,
                    'slug' => $ccc->slug,
                    'id' => $ccc->term_id
                ];
            }

            $data[$s] = [
                'img' => $img,
                'id' => $i,
                'name' => $n,
                'slug' => $s,
                'link' => $link,
                'child_categories' => $ch_data
            ];
        }
    }

    return new WP_REST_Response($data, 200);
}
function get_all_products($request)
{
    $paged = $request->get_param('page') ? intval($request->get_param('page')) : 1;

    $args = array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => 9,
        'paged' => $paged,
        'order' => 'DESC',
    );

    $query = new WP_Query($args);
    $products = [];

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();

            $post_id = get_the_ID();
            $thumb_id = get_post_thumbnail_id($post_id);
            $thumb = wp_get_attachment_image_src($thumb_id, 'thumbnail');
            $img_url = $thumb ? $thumb[0] : '';
            $img_alt = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);
            $img_title = get_the_title($thumb_id);

            $products[] = [
                'id' => $post_id,
                'name' => get_the_title(),
                'slug' => get_post_field('post_name', $post_id),
                'content' => wp_trim_words(get_the_content(), 15, '...'),
                'link' => get_the_permalink(),
                'img' => [
                    'url' => $img_url,
                    'alt' => $img_alt,
                    'title' => $img_title,
                ]
            ];
        }
        wp_reset_postdata();
    }

    return new WP_REST_Response([
        'products' => $products,
        'limit' => 9,
        'page' => $paged,
        'totalPages' => $query->max_num_pages,
    ], 200);
}
function get_products_by_category($request)
{
    $slug = $request['post_title'];
    $paged = $request->get_param('page') ? intval($request->get_param('page')) : 1;

    $ar = array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => 9,
        'order' => 'DESC',
        'paged' => $paged,
        'tax_query' => array(
            array(
                'taxonomy' => 'product_category',
                'field' => 'slug',
                'terms' => $slug,
                'include_children' => true,
            ),
        ),
    );
    $q = new WP_Query($ar);

    $products = [];
    if ($q->have_posts()) {
        while ($q->have_posts()) {
            $q->the_post();
            $post_id = get_the_ID();
            $thumb_id = get_post_thumbnail_id($post_id);
            $thumb = wp_get_attachment_image_src($thumb_id, 'thumbnail');
            $img_url = $thumb ? $thumb[0] : '';
            $img_alt = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);
            $img_title = get_the_title($thumb_id);

            $products[] = [
                'id' => $post_id,
                'name' => get_the_title(),
                'slug' => get_post_field('post_name', $post_id),
                'content' => wp_trim_words(get_the_content(), 15, '...'),
                'link' => get_the_permalink(),
                'img' => [
                    'url' => $img_url,
                    'alt' => $img_alt,
                    'title' => $img_title,
                ]
            ];
        }
        wp_reset_postdata();
    }

    return new WP_REST_Response([
        'products' => $products,
        'limit' => 9,
        'page' => $paged,
        'totalPages' => $q->max_num_pages,
    ], 200);
}
function get_single_products($request)
{
    $slug = $request['post_title'];
    $sslug = strtolower(str_replace('_', '-', $slug));
    $args = array(
        'name' => $sslug,
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => 9,
        'orderby' => 'date',
        'order' => 'ASC',
    );
    $query = new WP_Query($args);
    $blogs = $query->posts[0];
    $image = wp_get_attachment_image_src(get_post_thumbnail_id($blogs->ID), 'large');
    $additional_meta_data = get_field('additional_meta_data', $blogs->ID);
    // Prepare the blog post details
    $blog_details = array(
        'id' => $blogs->ID,
        'title' => $blogs->post_title,
        'content' => $blogs->post_content,
        'excerpt' => $blogs->post_excerpt,
        'thumbnail' => $image ? $image[0] : '',
        'date' => get_the_date('Y-m-d', $blogs->ID),
        'author' => get_the_author_meta('display_name', $blogs->post_author),
        'categories' => wp_get_post_terms($blogs->ID, 'product_category', array('fields' => 'names')),
        'metadata' => $additional_meta_data
    );

    $c = get_the_terms($blogs->ID, 'product_category');
    $ci = wp_list_pluck($c, 'term_id');
    $y = $blogs->ID;
    $as = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'post__not_in' => array($y),
        'tax_query' => array(
            array(
                'taxonomy' => 'product_category',
                'field' => 'term_id',
                'terms' => $ci,
            ),
        ),
    );
    $r = new WP_Query($as);
    $recent_posts = [];
    if ($r->have_posts()):
        while ($r->have_posts()):
            $r->the_post();
            $id = get_post_thumbnail_id();
            $ri = wp_get_attachment_image_src($id, 'large');
            $ur = $ri[0];
            $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
            $t = get_the_title($id);
            $recent_posts[] = array(
                'id' => get_the_ID(),
                'name' => get_the_title(),
                'slug' => get_post_field('post_name', get_the_ID()),
                'content' => wp_trim_words(get_the_content(), 15, '...'),
                'link' => get_the_permalink(),
                'img' => [
                    'url' => $ur,
                    'alt' => $alt,
                    'title' => $t,
                ]
            );
        endwhile;
    endif;

    // Return both blog details and recent posts
    return new WP_REST_Response(array(
        'blog_details' => $blog_details,
        'recent_posts' => $recent_posts
    ), 200);
}

function get_office_details()
{

    $data = [];
    $offices = get_field('factory', 'option');
    $data = [
        'offices' => $offices
    ];
    return new WP_REST_Response($data, 200);
}
function get_factory_details()
{

    $data = [];
    $factory_option = get_field('factory_option', 'option');
    $data = [
        'factory' => $factory_option
    ];
    return new WP_REST_Response($data, 200);
}
function get_contact_details()
{

    $data = [];
    $contact_option = get_field('contact_option', 'option');
    $data = [
        'factory' => $contact_option
    ];
    return new WP_REST_Response($data, 200);
}