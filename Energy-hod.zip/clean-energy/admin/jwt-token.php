<?php
// $token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL3d3dy4xZW5lcmd5LmNvbS9jbGVhbiIsImlhdCI6MTc0NTgyMTczMSwibmJmIjoxNzQ1ODIxNzMxLCJleHAiOjE3NDY0MjY1MzEsImRhdGEiOnsidXNlciI6eyJpZCI6IjEifX19.y3NanYYe7uqgBO75l_BPJghLMYjlBLj-o_6ZizZH9T0';
// add_filter('jwt_auth_expire', function($expire, $issued_at) {
//     return $issued_at + (24 * 60 * 60);
// }, 10, 2);



//add authenticaation to the acf field endpoint urls

add_filter('rest_pre_dispatch', function ($response, $server, $request) {
    $route = $request->get_route();
    $pageIds = [10, 20, 14, 15, 2094, 1066, 18];
    foreach ($pageIds as $pid) {
        if (strpos($route, "/wp/v2/pages/{$pid}") !== false) {
            // Check if user is authenticated
            if (!is_user_logged_in()) {
                $auth_header = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';

                if (empty($auth_header)) {
                    return new WP_Error('rest_forbidden', __('Authorization header not found.'), array('status' => 401));
                }

                // Let JWT plugin validate token
                $user = apply_filters('jwt_auth_token_before_dispatch', null, $request);

                if (is_wp_error($user)) {
                    return $user;
                }
            }
        }
    }

    return $response;
}, 10, 3);


//add authenticaation to the endpoint urls
add_filter('rest_pre_dispatch', function ($response, $server, $request) {
    $route = $request->get_route();
    $keys = parse_url(trim($route, '/')); // parse the url
    $path = explode("/", $keys['path']); // splitting the path
    $the_slug = end($path);
    // echo $the_slug;

    $urls = ['/wp/v2/header', '/wp/v2/footer', '/wp/v2/text-section', '/wp/v2/pro-cat', '/wp/v2/all-products', 'wp/v2/products/' . $the_slug, 'wp/v2/single-products/' . $the_slug];
    // Check for your custom endpoint
    foreach ($urls as $url) {
        if (strpos($route, $url) !== false) {
            // Check if user is authenticated
            if (!is_user_logged_in()) {
                $auth_header = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';

                if (empty($auth_header)) {
                    return new WP_Error('rest_forbidden', __('Authorization header not found.'), array('status' => 401));
                }

                // Let JWT plugin validate token
                $user = apply_filters('jwt_auth_token_before_dispatch', null, $request);

                if (is_wp_error($user)) {
                    return $user;
                }
            }
        }
    }
    return $response;
}, 10, 3);



?>