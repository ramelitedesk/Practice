<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package one-energy
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>1energy</title>
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<!-- font family -->
	<link rel="preconnect" href="https://fonts.googleapis.com" />
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
	<link
		href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap"
		rel="stylesheet" />
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>

	<div class="modal fade enquiry-modal" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
		aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content  contact__wrapper-left">
				<div class="modal-header">
					<h5 id="exampleModalLabel" class="visually-hidden">Contact Form</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
						style="color:red;"></button>
				</div>
				<div class="modal-body">
					<?php echo do_shortcode('[contact-form-7 id="962dc71" title="Product Contact Form" html_class="energy__contact-form"]'); ?>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade footer__menu-modal" id="footerMenuContactModal" tabindex="-1"
		aria-labelledby="footerMenuContactModalLabel" style="display: none;" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content contact__wrapper-left">
				<div class="modal-header">
					<h3>Get In Touch</h3>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">

					<?php echo do_shortcode('[contact-form-7 id="962dc71" title="Product Contact Form" html_class="energy__contact-form"]'); ?>
				</div>
			</div>
		</div>
	</div>
	<?php
	$header_options = get_field('header_options', 'option');
	if (isset($header_options)):
		$logo = isset($header_options['logo']) ? $header_options['logo'] : '';
		$offcanvas_logo = isset($header_options['offcanvas_logo']) ? $header_options['offcanvas_logo'] : '';
		$button_link = isset($header_options['button_link']) ? $header_options['button_link'] : array();
	endif;
	?>
	<header class="energy__header">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<nav class="energy__navbar navbar navbar-expand-lg navbar-light">
						<?php if (!empty($logo)): ?>
							<?php
							$logo_id = attachment_url_to_postid($logo);
							if ($logo_id):
								$logo_alt_text = get_post_meta($logo_id, '_wp_attachment_image_alt', true);
								$logo_title_attr = get_the_title($logo_id);
							endif;
							?>
							<a class="energy__logo navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
								<img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($logo_alt_text); ?>"
									title="<?php echo esc_attr($logo_title_attr); ?>" />
							</a>
						<?php endif; ?>

						<button class="energy__humber btn toggle-btn d-lg-none" type="button" data-bs-toggle="offcanvas"
							data-bs-target="#offcanvasExample" aria-controls="offcanvasExample"
							aria-label="Toggle navigation">
							<span class="energy__humber__bar"></span>
							<span class="energy__humber__bar"></span>
							<span class="energy__humber__bar"></span>
						</button>

						<div class="energy__offcanvas offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample"
							aria-labelledby="offcanvasExampleLabel">
							<div class="energy__offcanvas__header offcanvas-header d-lg-none">
								<?php if (!empty($logo)): ?>
									<?php
									$logo_id = attachment_url_to_postid($logo);
									if ($logo_id):
										$logo_alt_text = get_post_meta($logo_id, '_wp_attachment_image_alt', true);
										$logo_title_attr = get_the_title($logo_id);
									endif;
									?>
									<a class="energy__logo navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
										<img src="<?php echo esc_url($logo); ?>"
											alt="<?php echo esc_attr($logo_alt_text); ?>"
											title="<?php echo esc_attr($logo_title_attr); ?>" />
									</a>
								<?php endif; ?>
								<button type="button" class="energy__offcanvas__close btn-close"
									data-bs-dismiss="offcanvas" aria-label="Close"><i
										class="fa-solid fa-xmark"></i></button>
							</div>
							<div class="energy__offcanvas__body offcanvas-body">

								<?php
								wp_nav_menu(array(
									'theme_location' => 'primary-menu',
									'menu_class' => 'energy__menu navbar-nav',
									'container' => false,
									'walker' => new Custom_Walker_Nav_Menu(),
								));
								?>
							</div>
						</div>
						<?php if (is_array($button_link)): ?>
							<?php
							$button_text = isset($button_link['title']) ? $button_link['title'] : '';
							$button_url = isset($button_link['url']) ? $button_link['url'] : '';
							if (!empty($button_text) || !empty($button_url)):
								?>
								<a href="<?php echo esc_url($button_url); ?>" class="energy__btn">
									<?php echo esc_html($button_text); ?>
									<span>
										<i class="fa-solid fa-bolt-lightning"></i>
									</span>
								</a>
							<?php endif; ?>
						<?php endif; ?>
					</nav>
				</div>
			</div>
		</div>
	</header>