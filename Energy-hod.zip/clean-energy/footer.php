<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package one-energy
 */

?>
<?php
echo do_shortcode('[sticky_menu_shortcode]');
$footer_options = get_field('footer_options', 'option');
if (isset($footer_options)):
	$logo = isset($footer_options['footer_logo']) ? $footer_options['footer_logo'] : '';
	$page_link_texts = isset($footer_options['page_link_texts']) ? $footer_options['page_link_texts'] : '';
	$footer_page_links = isset($footer_options['footer_page_links']) ? $footer_options['footer_page_links'] : array();
	$social_links = isset($footer_options['social_links']) ? $footer_options['social_links'] : array();
	$copyright_texts = isset($footer_options['copyright_texts']) ? $footer_options['copyright_texts'] : array();
	$footer_bottom_page_links = isset($footer_options['footer_bottom_page_links']) ? $footer_options['footer_bottom_page_links'] : array();
endif;
?>
<footer class="energy__footer bg__one energy__white__text">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="energy__footer__left">
					<?php if (!empty($logo)): ?>
						<?php
						$logo_id = attachment_url_to_postid($logo);
						if ($logo_id):
							$logo_alt_text = get_post_meta($logo_id, '_wp_attachment_image_alt', true);
							$logo_title_attr = get_the_title($logo_id);
						endif;
						?>
						<a class="footer__logo" href="<?php echo esc_url(home_url('/')); ?>">
							<img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($logo_alt_text); ?>"
								title="<?php echo esc_attr($logo_title_attr); ?>" />
						</a>
					<?php endif; ?>
					<?php if (!empty($page_link_texts)): ?>
						<div class="energy__header__title">
							<h2><?php echo esc_html($page_link_texts); ?></h2>
						</div>
					<?php endif; ?>
					<?php if (is_array($footer_page_links) || $footer_page_links): ?>
						<div class="footer__nav">
							<ul>
								<?php foreach ($footer_page_links as $page_link): ?>
									<?php
									if (is_array($page_link)):
										$links = isset($page_link['links']) ? $page_link['links'] : array();
										if (is_array($links) || !empty($links)):
											$links_title = isset($links['title']) ? $links['title'] : '';
											$links_url = isset($links['url']) ? $links['url'] : '';
										endif;
										?>
										<li>
											<?php if (!empty($links_title)): ?>
												<a href="<?php echo esc_url($links_url); ?>"
													class="nav__link"><?php echo esc_html($links_title); ?> </a>
											<?php endif; ?>
										</li>
									<?php endif; ?>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif; ?>
				</div>
			</div>
			<div class="col-md-6">
				<div class="energy__footer-right">
					<a href="#url" class="modal__btn" data-bs-toggle="modal" data-bs-target="#exampleModal">Get In
						Touch</a>
					<?php if (is_array($social_links) || $social_links): ?>
						<div class="energy__media">
							<ul>
								<?php foreach ($social_links as $soc_link): ?>
									<?php
									if (is_array($soc_link)):
										$links = isset($soc_link['links']) ? $soc_link['links'] : array();
										if (is_array($links) || !empty($links)):
											$links_title = isset($links['title']) ? $links['title'] : '';
											$links_url = isset($links['url']) ? $links['url'] : '';
										endif;
										?>
										<li>
											<?php if (!empty($links_title)): ?>
												<a href="<?php echo esc_url($links_url); ?>" class="media__icon"><i
														class="<?php echo esc_attr($links_title); ?>"></i></a>
											<?php endif; ?>
										</li>
									<?php endif; ?>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif; ?>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="energy__footer__bottom">
					<?php if ($copyright_texts): ?>
						<div class="footer__bottom-left">
							<?php if (!empty($copyright_texts['text_1']) || !empty($copyright_texts['text_2']) || !empty($copyright_texts['text_3'])): ?>
								<p>
									<?php echo esc_html($copyright_texts['text_1']); ?> 		<?php echo date('Y'); ?> | <a
										class="copy__link"
										href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_html($copyright_texts['text_2']); ?></a><?php echo esc_html($copyright_texts['text_3']); ?>
								</p>
							<?php endif; ?>
						</div>
					<?php endif; ?>
					<?php if (is_array($footer_bottom_page_links) || $footer_bottom_page_links): ?>
						<div class="footer__bottom-right">
							<p>

								<?php
								$separator = '';
								foreach ($footer_bottom_page_links as $bott_link):
									?>
									<?php
									if (is_array($bott_link)):
										$links = isset($bott_link['links']) ? $bott_link['links'] : array();
										if (is_array($links) || !empty($links)):
											$links_title = isset($links['title']) ? $links['title'] : '';
											$links_url = isset($links['url']) ? $links['url'] : '';
										endif;
										if (!empty($links_title)):
											echo $separator;
											?>
											<a href="<?php echo esc_url($links_url); ?>"><?php echo esc_html($links_title); ?></a>
											<?php
											$separator = '|';
										endif;
										?>
									<?php endif; ?>
								<?php endforeach; ?>
							</p>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=30851f64-6333-4478-8719-b16022cfba32">
</script>
<script type="text/javascript">
	window.zESettings = {
		messenger: {
			color: {
				theme: '#fc3a2c'
			}
		}
	};
	zE('messenger', 'hide');

	function openWidget() {
		zE('messenger', 'show');
		zE('messenger', 'open');
		document.querySelector('#myLauncher').style.opacity = 1;
	};
	zE('messenger:on', 'close', function () {
		zE('messenger', 'hide');
		document.querySelector('#myLauncher').style.opacity = 1;
	})
</script>
<script>
	document.addEventListener('wpcf7mailsent', function (event) {
		location = '<?php echo site_url('thank-you'); ?>';
	}, false);
</script>
<script>
	$(document).ready(function () {
		$(".toggle__icon").on("click", function () {
			$(this).toggleClass("active"),
				$(this).hasClass("active") ? $(this).find("i").removeClass("fa-plus").addClass("fa-minus") : $(this).find("i").removeClass("fa-minus").addClass("fa-plus"),
				$(this).siblings(".children").slideToggle();
		});
	});
</script>

</body>

</html>