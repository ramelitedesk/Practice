<?php
get_header();
?>

<?php

//banner section

$banner_options = get_field('banner_options');
if ($banner_options):
    $banner_image = isset($banner_options['banner_image']) ? $banner_options['banner_image'] : '';
    $banner_logo = isset($banner_options['banner_logo']) ? $banner_options['banner_logo'] : '';
    $banner_title = isset($banner_options['banner_title']) ? $banner_options['banner_title'] : '';
    $banner_button_link = isset($banner_options['banner_button_link']) ? $banner_options['banner_button_link'] : array();
    $banner_service_card = isset($banner_options['banner_service_card']) ? $banner_options['banner_service_card'] : array();
    ?>
    <section class="energy__banner energy__overlay custom__pad">
        <?php
        if (!empty($banner_image)):
            $banner_image_id = attachment_url_to_postid($banner_image);
            if ($banner_image_id):
                $banner_image_alt_text = get_post_meta($banner_image_id, '_wp_attachment_image_alt', true);
                $banner_image_title_attr = get_the_title($banner_image_id);
            endif;
            ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($banner_image); ?>"
                    alt="<?php echo esc_attr($banner_image_alt_text); ?>" />
            </div>
        <?php endif; ?>
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row gy-4 align-items-center">
                    <div class="col-lg-12">
                        <div class="energy__content__wrapper">
                            <?php
                            if (!empty($banner_logo)):
                                $banner_logo_id = attachment_url_to_postid($banner_logo);
                                if ($banner_logo_id):
                                    $banner_logo_alt_text = get_post_meta($banner_logo_id, '_wp_attachment_image_alt', true);
                                    $banner_logo_title_attr = get_the_title($banner_logo_id);
                                endif;
                                ?>
                                <div class="energy__img__wrapper">
                                    <img src="<?php echo esc_url($banner_logo); ?>"
                                        alt="<?php echo esc_url($banner_logo_alt_text); ?>"
                                        title="<?php echo esc_url($banner_logo_title_attr); ?>" />
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($banner_title)): ?>
                                <div class="energy__header__title">
                                    <h1><?php echo esc_html($banner_title); ?></h1>
                                </div>
                                <?php
                            endif;
                            if (is_array($banner_button_link) || $banner_button_link):
                                $button_txt = isset($banner_button_link['title']) ? $banner_button_link['title'] : '';
                                $button_url = isset($banner_button_link['url']) ? $banner_button_link['url'] : '';
                                if (!empty($button_txt)):
                                    ?>
                                    <a href="<?php echo esc_url($button_url); ?>"
                                        class="energy__btn energy__btn__one"><?php echo esc_html($button_txt); ?>
                                        <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                                    </a>
                                    <?php
                                endif;
                            endif;
                            ?>
                            <div class="service__card">
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <?php
                                        if ($banner_service_card):
                                            $banner_card_img = isset($banner_service_card['image']) ? $banner_service_card['image'] : '';
                                            $banner_card_title = isset($banner_service_card['title']) ? $banner_service_card['title'] : '';
                                            $banner_card_text = isset($banner_service_card['text']) ? $banner_service_card['text'] : '';
                                            $card_button_link = isset($banner_service_card['button_link']) ? $banner_service_card['button_link'] : '';
                                        endif;
                                        if (!empty($banner_card_img)):
                                            $banner_card_img_id = attachment_url_to_postid($banner_card_img);
                                            if ($banner_logo_id):
                                                $banner_card_img_alt_text = get_post_meta($banner_logo_id, '_wp_attachment_image_alt', true);
                                                $banner_card_img_title_attr = get_the_title($banner_logo_id);
                                            endif;
                                            ?>
                                            <div class="energy__service__img">
                                                <img src="<?php echo esc_url($banner_card_img); ?>"
                                                    alt="<?php echo esc_url($banner_card_img_alt_text); ?>"
                                                    title="<?php echo esc_url($banner_card_img_title_attr); ?>" />
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="energy__service__content">
                                            <?php if (!empty($banner_card_title)): ?>
                                                <h3><?php echo esc_html($banner_card_title); ?></h3>
                                            <?php endif; ?>
                                            <a href="<?php echo esc_url($card_button_link); ?>" class="arrow__icon"><img
                                                    src="<?php echo get_template_directory_uri() . '/assets/images/arrow__icon.png'; ?>"
                                                    alt="this is an image" />
                                            </a>
                                            <?php if (!empty($banner_card_text)): ?>
                                                <p>
                                                    <?php echo esc_html($banner_card_text); ?>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php

//about section

$about_options = get_field('about_options');
if ($about_options):
    $title_text = isset($about_options['title_text']) ? $about_options['title_text'] : '';
    $about_img = isset($about_options['image']) ? $about_options['image'] : '';
    $feature_cards = isset($about_options['feature_cards']) ? $about_options['feature_cards'] : array();
    $about_texts = isset($about_options['texts']) ? $about_options['texts'] : '';
    $energy_bg_image = isset($about_options['energy_bg_image']) ? $about_options['energy_bg_image'] : '';
    ?>
    <section class="energy__about custom__pad">
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row g-4 g-lg-5">
                    <div class="col-lg-6">
                        <?php
                        if (!empty($about_img)):
                            $about_img_id = attachment_url_to_postid($about_img);
                            if ($about_img_id):
                                $about_img_alt_text = get_post_meta($about_img_id, '_wp_attachment_image_alt', true);
                                $about_img_title_attr = get_the_title($about_img_id);
                            endif;
                            ?>
                            <div class="about__img__wrapper">
                                <img src="<?php echo esc_url($about_img); ?>"
                                    alt="<?php echo esc_attr($about_img_alt_text); ?>" />
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-6">
                        <div class="energy__content__wrapper">
                            <?php if (!empty($title_text)): ?>
                                <h3 class="energy__sub__title">
                                    <span>
                                        <i class="fa-solid fa-bolt"></i>
                                    </span>
                                    <?php echo esc_html($title_text); ?>
                                </h3>
                            <?php endif; ?>
                            <?php if (!empty($about_texts)): ?>
                                <div class="energy__header__title">
                                    <h2>
                                        <?php echo esc_html($about_texts); ?>
                                    </h2>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <?php
                        if (is_array($feature_cards)):

                            ?>
                            <div class="feature__card__wrapper">
                                <div class="row g-2">
                                    <?php
                                    foreach ($feature_cards as $fea):
                                        if (is_array($fea)):
                                            $fea_link = isset($fea['link']) ? $fea['link'] : '';
                                            $fea_image = isset($fea['image']) ? $fea['image'] : '';
                                            $fea_title = isset($fea['title']) ? $fea['title'] : '';
                                            ?>

                                            <div class="col-lg-3 col-md-6">
                                                <a href="<?php echo esc_url($fea_link); ?>" class="feature__card energy__overlay">
                                                    <?php if (!empty($fea_image)): ?>
                                                        <div class="feature__img__wrapper">
                                                            <img src="<?php echo esc_url($fea_image); ?>" alt="" />
                                                        </div>
                                                    <?php endif; ?>
                                                    <div class="feature__content__wrapper">
                                                        <h3>
                                                            <?php echo esc_html($fea_title); ?>
                                                            <span>
                                                                <img src="<?php echo get_template_directory_uri() . '/assets/images/arrow__icon.png'; ?>"
                                                                    alt="this is an image" />
                                                            </span>
                                                        </h3>
                                                    </div>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php if (!empty($energy_bg_image)): ?>
            <div class="energy__bg__shape">
                <img src="<?php echo esc_url($energy_bg_image); ?>" alt="" />
            </div>
        <?php endif; ?>
    </section>
    <?php
endif;


/// why choose section
?>
<section class="energy__about energy__whychoose custom__pad bg__one energy__white__text">
    <div class="energy__section__wrapper">
        <div class="container">
            <div class="row g-4">
                <?php
                $why_choose_option = get_field('why_choose_option');
                if ($why_choose_option):
                    $why_heading_text = isset($why_choose_option['heading_text']) ? $why_choose_option['heading_text'] : '';
                    $why_title = isset($why_choose_option['title']) ? $why_choose_option['title'] : '';
                    $why_text = isset($why_choose_option['text']) ? $why_choose_option['text'] : '';
                    $why_button_link = isset($why_choose_option['button_link']) ? $why_choose_option['button_link'] : array();
                    ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="energy__content__wrapper">
                            <?php if (!empty($why_heading_text)): ?>
                                <h3 class="energy__sub__title">
                                    <span>
                                        <i class="fa-solid fa-bolt"></i>
                                    </span>
                                    <?php echo esc_html($why_heading_text); ?>
                                </h3>
                            <?php endif; ?>
                            <?php if (!empty($why_title)): ?>
                                <div class="energy__header__title">
                                    <h2><?php echo esc_html($why_title); ?></h2>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($why_text)): ?>
                                <p>
                                    <?php echo esc_html($why_text); ?>
                                </p>
                            <?php endif; ?>
                            <?php if (is_array($why_button_link)):
                                $why_btn_title = isset($why_button_link['title']) ? $why_button_link['title'] : '';
                                $why_btn_url = isset($why_button_link['url']) ? $why_button_link['url'] : '';
                            endif;
                            if (!empty($why_btn_title)):
                                ?>
                                <a href="<?php echo esc_url($why_btn_url); ?>"
                                    class="energy__btn"><?php echo esc_html($why_btn_title); ?>
                                    <span> <i class="fa-solid fa-bolt-lightning"></i> </span></a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
                <?php
                $why_choose_card = get_field('why_choose_card');
                if ($why_choose_card):
                    ?>
                    <?php
                    foreach ($why_choose_card as $why_card):
                        if (is_array($why_card)):
                            $why_icon = isset($why_card['icon']) ? $why_card['icon'] : '';
                            $why_title = isset($why_card['title']) ? $why_card['title'] : '';
                            $why_texts = isset($why_card['texts']) ? $why_card['texts'] : '';
                            $why_link = isset($why_card['link']) ? $why_card['link'] : array();
                            ?>
                            <div class="col-lg-4 col-md-6">
                                <div class="whychoose__card">
                                    <?php if (!empty($why_icon)): ?>
                                        <div class="whychoose__icon">
                                            <img src="<?php echo esc_url($why_icon); ?>" alt="" />
                                        </div>
                                    <?php endif; ?>
                                    <div class="whychoose__content__wrapper">
                                        <?php if (!empty($why_title)): ?>
                                            <h3><?php echo esc_html($why_title); ?></h3>
                                        <?php endif; ?>
                                        <?php if (!empty($why_texts)): ?>
                                            <p>
                                                <?php echo esc_html($why_texts); ?>
                                            </p>
                                        <?php endif; ?>
                                        <?php if (is_array($why_link)):
                                            $why_link_title = isset($why_link['title']) ? $why_link['title'] : '';
                                            $why_link_url = isset($why_link['url']) ? $why_link['url'] : '';
                                        endif;
                                        if (!empty($why_link_title)):
                                            ?>
                                            <a href="<?php echo esc_url($why_link_url); ?>"
                                                class="energy__btn energy__btn__one"><?php echo esc_html($why_link_title); ?>
                                                <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php

// energy partner section
$energy_partner_options = get_field('energy_partner_options');
if ($energy_partner_options):
    $partner_title_text = isset($energy_partner_options['title_text']) ? $energy_partner_options['title_text'] : '';
    $partner_heading_text = isset($energy_partner_options['heading_text']) ? $energy_partner_options['heading_text'] : '';
    $partner_texts = isset($energy_partner_options['texts']) ? $energy_partner_options['texts'] : '';
    $partner_card_section = isset($energy_partner_options['card_section']) ? $energy_partner_options['card_section'] : array();
    $partner_bg_image = isset($energy_partner_options['bg_image']) ? $energy_partner_options['bg_image'] : array();
    ?>
    <section class="energy__partner custom__pad pb-0">
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="energy__content__wrapper">
                            <?php if (!empty($partner_title_text)): ?>
                                <h3 class="energy__sub__title">
                                    <span>
                                        <i class="fa-solid fa-bolt"></i>
                                    </span>
                                    <?php echo esc_html($partner_title_text); ?>
                                </h3>
                            <?php endif; ?>
                            <?php if (!empty($partner_heading_text)): ?>
                                <div class="energy__header__title">
                                    <h2> <?php echo esc_html($partner_heading_text); ?></h2>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($partner_texts)): ?>
                                <p>
                                    <?php echo esc_html($partner_texts); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <?php
                        if (is_array($partner_card_section)):
                            ?>
                            <div class="partner__card__wrapper">
                                <div class="row g-3">
                                    <?php
                                    foreach ($partner_card_section as $r => $cs):
                                        if (is_array($cs)):
                                            $cs_img = isset($cs['image']) ? $cs['image'] : '';
                                            $cs_icon = isset($cs['icon']) ? $cs['icon'] : '';
                                            $cs_title = isset($cs['title']) ? $cs['title'] : '';
                                            $cs_texts = isset($cs['texts']) ? $cs['texts'] : '';
                                            ?>
                                            <div class="col-lg-3 col-md-6">
                                                <div class="partner__card">
                                                    <?php if (!empty($cs_img)): ?>
                                                        <div class="partner__img_wrapper">
                                                            <img src="<?php echo esc_url($cs_img); ?>" alt="" />
                                                        </div>
                                                    <?php endif; ?>
                                                    <div class="partner__icon">
                                                        <!-- <img src="<?php echo esc_url($cs_icon); ?>" alt="" /> -->
                                                        <span><?php echo $r + 1; ?></span>
                                                    </div>
                                                    <div class="partner__content__wrapper">
                                                        <?php if (!empty($cs_title)): ?>
                                                            <h3><?php echo esc_html($cs_title); ?></h3>
                                                        <?php endif; ?>
                                                        <?php if (!empty($cs_texts)): ?>
                                                            <p>
                                                                <?php echo esc_html($cs_texts); ?>
                                                            </p>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php if ($partner_bg_image): ?>
            <?php if (!empty($partner_bg_image['image_1'])): ?>
                <div class="energy__bg__shape">
                    <img src="<?php echo esc_url($partner_bg_image['image_1']); ?>" alt="" />
                </div>
            <?php endif; ?>
            <?php if (!empty($partner_bg_image['image_2'])): ?>
                <div class="energy__bg__shape one">
                    <img src="<?php echo esc_url($partner_bg_image['image_2']); ?>" alt="" />
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </section>
<?php endif; ?>
<?php

//product section 

$energy_product_options = get_field('energy_product_options');
if ($energy_product_options):
    $pr_heading_text = isset($energy_product_options['heading_text']) ? $energy_product_options['heading_text'] : '';
    $pr_title_text = isset($energy_product_options['title_text']) ? $energy_product_options['title_text'] : '';
    $pr_texts = isset($energy_product_options['texts']) ? $energy_product_options['texts'] : '';
    $product_cards = isset($energy_product_options['product_cards']) ? $energy_product_options['product_cards'] : '';
    ?>
    <section class="energy__product custom__pad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="energy__content__wrapper">
                        <?php if (!empty($pr_heading_text)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($pr_heading_text); ?>
                            </h3>
                        <?php endif; ?>
                        <?php if (!empty($pr_title_text)): ?>
                            <div class="energy__header__title">
                                <h2> <?php echo esc_html($pr_title_text); ?></h2>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($pr_texts)): ?>
                            <p>
                                <?php echo esc_html($pr_texts); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="product__card__wrapper">
                        <?php
                        foreach ($product_cards as $k => $pr):
                            if (is_array($pr)):
                                $pr_link = isset($pr['link']) ? $pr['link'] : '';
                                $pr_img = isset($pr['image']) ? $pr['image'] : '';
                                $pr_icon = isset($pr['icon']) ? $pr['icon'] : '';
                                $pr_title = isset($pr['title']) ? $pr['title'] : '';
                                $pr_texts = isset($pr['texts']) ? $pr['texts'] : '';
                                ?>
                                <a href="<?php echo esc_url($pr_link); ?>"
                                    class="feature__card product__box0<?php echo $k + 1; ?> energy__overlay">
                                    <?php if (!empty($pr_img)): ?>
                                        <div class="feature__img__wrapper">
                                            <img src="<?php echo esc_url($pr_img); ?>" alt="" />
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($pr_icon)): ?>
                                        <div class="feature__icon">
                                            <img src="<?php echo esc_url($pr_icon); ?>" alt="" />
                                        </div>
                                    <?php endif; ?>
                                    <div class="feature__content__wrapper">
                                        <?php if (!empty($pr_title)): ?>
                                            <h3><?php echo esc_html($pr_title); ?></h3>
                                        <?php endif; ?>
                                        <?php if (!empty($pr_texts)): ?>
                                            <p>
                                                <?php echo esc_html($pr_texts); ?>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php

//sustainability section

$sustainability_options = get_field('sustainability_options');
if ($sustainability_options):
    $s_image = isset($sustainability_options['image']) ? $sustainability_options['image'] : '';
    $s_title_text = isset($sustainability_options['title_text']) ? $sustainability_options['title_text'] : '';
    $s_heading_text = isset($sustainability_options['heading_text']) ? $sustainability_options['heading_text'] : '';
    $s_texts = isset($sustainability_options['texts']) ? $sustainability_options['texts'] : '';
    $s_button_links = isset($sustainability_options['button_links']) ? $sustainability_options['button_links'] : array();
    $s_bg_shape_image = isset($sustainability_options['bg_shape_image']) ? $sustainability_options['bg_shape_image'] : '';
    $s_images = isset($sustainability_options['images']) ? $sustainability_options['images'] : array();
    ?>
    <section class="energy__sustainability bg__one energy__white__text">
        <div class="container-fluid">
            <div class="row g-3 g-lg-4">
                <div class="col-lg-5">
                    <?php
                    if (!empty($s_image)):
                        ?>
                        <div class="sustainability__left__Part">
                            <div class="sustainability__img_wrapper">
                                <img src="<?php echo esc_url($s_image); ?>" alt="" />
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-lg-4">
                    <div class="sustainability__center__part custom__pad">
                        <div class="energy__content__wrapper">
                            <?php if (!empty($s_title_text)): ?>
                                <h3 class="energy__sub__title">
                                    <span>
                                        <i class="fa-solid fa-bolt"></i>
                                    </span>
                                    <?php echo esc_html($s_title_text); ?>
                                </h3>
                            <?php endif; ?>
                            <?php if (!empty($s_heading_text)): ?>
                                <div class="energy__header__title">
                                    <h2> <?php echo esc_html($s_heading_text); ?></h2>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($s_texts)): ?>
                                <p>
                                    <?php echo esc_html($s_texts); ?>
                                </p>
                            <?php endif; ?>
                            <?php if (is_array($s_button_links)): ?>
                                <?php
                                $s_button_title = isset($s_button_links['title']) ? $s_button_links['title'] : '';
                                $s_button_url = isset($s_button_links['url']) ? $s_button_links['url'] : '';
                                if (!empty($s_button_title)):
                                    ?>
                                    <a href="<?php echo esc_url($s_button_url); ?>"
                                        class="energy__btn"><?php echo esc_html($s_button_title); ?>
                                        <span> <i class="fa-solid fa-bolt-lightning"></i> </span></a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="energy__bg__shape">
                            <img src="<?php echo esc_url($s_bg_shape_image); ?>" alt="" />
                        </div>
                        <div class="energy__bg__shape one">
                            <img src="<?php echo esc_url($s_bg_shape_image); ?>" alt="" />
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <?php if (is_array($s_images)): ?>
                        <div class="sustainability__right__Part">
                            <?php foreach ($s_images as $im):
                                if (is_array($im)):
                                    $im_img = isset($im['image']) ? $im['image'] : '';
                                    ?>
                                    <div class="sustainability__img_wrapper">
                                        <?php if (!empty($im_img)): ?>
                                            <img src="<?php echo esc_url($im_img); ?>" alt="" />
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php

//large range Products section

$large_range_products = get_field('large_range_products');
if ($large_range_products):
    $la_heading_text = isset($large_range_products['heading_text']) ? $large_range_products['heading_text'] : '';
    $la_title_text = isset($large_range_products['title_text']) ? $large_range_products['title_text'] : '';
    $la_texts = isset($large_range_products['texts']) ? $large_range_products['texts'] : '';
    $la_product_cards = isset($large_range_products['product_cards']) ? $large_range_products['product_cards'] : array();
    $la_button_link = isset($large_range_products['button_link']) ? $large_range_products['button_link'] : array();
    ?>
    <section class="energy__discover custom__pad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="energy__content__wrapper">
                        <?php if (!empty($la_heading_text)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($la_heading_text); ?>
                            </h3>
                        <?php endif; ?>
                        <?php if (!empty($la_title_text)): ?>
                            <div class="energy__header__title">
                                <h2> <?php echo esc_html($la_title_text); ?></h2>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($la_texts)): ?>
                            <p>
                                <?php echo esc_html($la_texts); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-12">
                    <?php if (is_array($la_product_cards)): ?>
                        <div class="discover__card_wrapper">
                            <div class="row g-2 g-lg-3">
                                <?php
                                foreach ($la_product_cards as $la):
                                    if (is_array($la)):
                                        $la_link = isset($la['link']) ? $la['link'] : '';
                                        $la_image = isset($la['image']) ? $la['image'] : '';
                                        $la_title = isset($la['title']) ? $la['title'] : '';

                                        ?>
                                        <div class="col-lg-3 col-md-4">
                                            <a href="<?php echo esc_url($la_link); ?>" class="feature__card energy__overlay">
                                                <?php if (!empty($la_image)): ?>
                                                    <div class="feature__img__wrapper">
                                                        <img src="<?php echo esc_url($la_image); ?>" alt="" />
                                                    </div>
                                                <?php endif; ?>
                                                <div class="feature__content__wrapper">
                                                    <?php if (!empty($la_title)): ?>
                                                        <h3>
                                                            <?php echo esc_html($la_title); ?>
                                                            <span>
                                                                <img src="<?php echo get_template_directory_uri() . '/assets/images/arrow__icon.png'; ?>"
                                                                    alt="this is an image" />
                                                            </span>
                                                        </h3>
                                                    <?php endif; ?>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            <?php if (is_array($la_button_link)): ?>
                                <?php
                                $la_btn_title = isset($la_button_link['title']) ? $la_button_link['title'] : '';
                                $la_btn_url = isset($la_button_link['url']) ? $la_button_link['url'] : '';
                                ?>
                                <div class="center__btn__wrapper text-center">
                                    <?php if (!empty($la_btn_title)): ?>
                                        <a href="<?php echo esc_url($la_btn_url); ?>"
                                            class="energy__btn energy__btn__one"><?php echo esc_html($la_btn_title); ?>
                                            <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php

//faq sectiion 

$faq_options = get_field('faq_options');
if ($faq_options):
    $faq_image = isset($faq_options['image']) ? $faq_options['image'] : '';
    $faq_heading_text = isset($faq_options['heading_text']) ? $faq_options['heading_text'] : '';
    $faq_title_text = isset($faq_options['title_text']) ? $faq_options['title_text'] : '';
    $faq_texts = isset($faq_options['texts']) ? $faq_options['texts'] : '';
endif;
$accordions = get_field('accordions');
$faq_button_link = get_field('faq_button_link');
?>
<section class="energy__faq custom__pad pt-0">
    <div class="container">
        <div class="row g-xl-5 g-lg-4">
            <div class="col-lg-6">
                <?php if (!empty($faq_image)): ?>
                    <div class="faq__left__part">
                        <div class="faq__img-wrapper">
                            <img src="<?php echo esc_url($faq_image); ?>" alt="" />
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-lg-6">
                <div class="energy__content__wrapper">
                    <?php if (!empty($faq_heading_text)): ?>
                        <h3 class="energy__sub__title">
                            <span>
                                <i class="fa-solid fa-bolt"></i>
                            </span>
                            <?php echo esc_html($faq_heading_text); ?>
                        </h3>
                    <?php endif; ?>
                    <?php if (!empty($faq_title_text)): ?>
                        <div class="energy__header__title">
                            <h2> <?php echo esc_html($faq_title_text); ?></h2>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($faq_texts)): ?>
                        <p>
                            <?php echo esc_html($faq_texts); ?>
                        </p>
                    <?php endif; ?>
                    <?php if (is_array($accordions)): ?>
                        <div class="faq__item_wrapper">
                            <div class="accordion" id="accordionExample">
                                <?php
                                foreach ($accordions as $aa => $acc):
                                    if (is_array($acc)):
                                        $question_text = isset($acc['question_text']) ? $acc['question_text'] : '';
                                        $solution_texts = isset($acc['solution_texts']) ? $acc['solution_texts'] : '';
                                        // $show = ($aa == 0) ? 'show' : '';
                                        $expanded = ($aa == 0) ? 'true' : '';
                                        ?>
                                        <div class="accordion-item">
                                            <?php if (!empty($question_text)): ?>
                                                <h2 class="accordion-header" id="heading0<?php echo $aa + 1; ?>">
                                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                                        data-bs-target="#collapse0<?php echo $aa + 1; ?>"
                                                        aria-expanded="<?php echo $expanded; ?>"
                                                        aria-controls="collapse0<?php echo $aa + 1; ?>">
                                                        <?php echo esc_html($question_text); ?>
                                                    </button>
                                                </h2>
                                            <?php endif; ?>
                                            <?php if (!empty($solution_texts)): ?>
                                                <div id="collapse0<?php echo $aa + 1; ?>" class="accordion-collapse collapse"
                                                    aria-labelledby="heading0<?php echo $aa + 1; ?>" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <p>
                                                            <?php echo esc_html($solution_texts); ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php
                    if (is_array($faq_button_link)):
                        $faq_btn_title = isset($faq_button_link['title']) ? $faq_button_link['title'] : '';
                        $faq_btn_url = isset($faq_button_link['url']) ? $faq_button_link['url'] : '';
                        if (!empty($faq_btn_title)):
                            ?>
                            <a href="<?php echo esc_url($faq_btn_url); ?>"
                                class="energy__btn energy__btn__one"><?php echo esc_html($faq_btn_title); ?>
                                <span> <i class="fa-solid fa-bolt-lightning"></i> </span></a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
        $faq_feature_card_options = get_field('faq_feature_card_options');
        ?>
        <div class="row">
            <div class="col-lg-12">
                <?php if ($faq_feature_card_options): ?>
                    <div class="feature__card__one-wrapper">
                        <div class="row g-3 g-lg-5">
                            <?php
                            foreach ($faq_feature_card_options as $opt):
                                if (is_array($opt)):
                                    $opt_title = isset($opt['title']) ? $opt['title'] : '';
                                    $opt_link = isset($opt['link']) ? $opt['link'] : '';
                                    $opt_texts = isset($opt['texts']) ? $opt['texts'] : '';
                                    ?>
                                    <div class="col-lg-4">
                                        <div class="feature__card__one">
                                            <?php if (!empty($opt_title)): ?>
                                                <div class="energy__header__title">
                                                    <h2><?php echo esc_html($opt_title); ?></h2>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($opt_link)): ?>
                                                <a href="<?php echo esc_url($opt_link); ?>" class="arrow__icon-one"> <img
                                                        src="<?php echo get_template_directory_uri() . '/assets/images/arrow__black.png'; ?>"
                                                        alt="" /></a>
                                            <?php endif; ?>
                                            <hr class="feature__hr" />
                                            <?php if (!empty($opt_texts)): ?>
                                                <p>
                                                    <?php echo esc_html($opt_texts); ?>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php

//green energy section 

$green_energy__options = get_field('green_energy__options');
if ($green_energy__options):
    $g_image = isset($green_energy__options['image']) ? $green_energy__options['image'] : '';
    $g_heading_text = isset($green_energy__options['heading_text']) ? $green_energy__options['heading_text'] : '';
    $g_title_texts = isset($green_energy__options['title_texts']) ? $green_energy__options['title_texts'] : array();
    $g_texts = isset($green_energy__options['texts']) ? $green_energy__options['texts'] : '';
    $video_url = isset($green_energy__options['video_url']) ? $green_energy__options['video_url'] : '';
    $video_texts = isset($green_energy__options['video_texts']) ? $green_energy__options['video_texts'] : '';
    $vid_image = isset($green_energy__options['vid_image']) ? $green_energy__options['vid_image'] : '';
    $animated_images = isset($green_energy__options['animated_images']) ? $green_energy__options['animated_images'] : array();
    ?>
    <section class="energy__green energy__overlay energy__white__text custom__pad">
        <?php if (!empty($g_image)): ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($g_image); ?>" alt="" />
            </div>
        <?php endif; ?>
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="energy__content__wrapper">
                            <?php if (!empty($g_heading_text)): ?>
                                <h3 class="energy__sub__title"><?php echo esc_html($g_heading_text); ?></h3>
                            <?php endif; ?>
                            <?php if (!empty($g_title_texts)): ?>
                                <div class="energy__header__title">
                                    <?php
                                    $g_title_text1 = isset($g_title_texts['text_1']) ? $g_title_texts['text_1'] : '';
                                    $g_title_text2 = isset($g_title_texts['text_2']) ? $g_title_texts['text_2'] : '';
                                    if (!empty($g_title_text1) || !empty($g_title_text2)):
                                        ?>
                                        <h2><span><?php echo esc_html($g_title_text1); ?></span>
                                            <?php echo esc_html($g_title_text2); ?></h2>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($g_texts)): ?>
                                <p><?php echo esc_html($g_texts); ?></p>
                            <?php endif; ?>
                            <div class="service__card">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="service__card-left">
                                            <?php if (!empty($video_url)): ?>
                                                <a href="<?php echo esc_url($video_url); ?>" data-fancybox="gallery"
                                                    class="play__icon">
                                                    <i class="fa-solid fa-play"></i>
                                                </a>
                                            <?php endif; ?>
                                            <?php if (!empty($vid_image)): ?>
                                                <div class="energy__service__img">
                                                    <img src="<?php echo esc_url($vid_image); ?>" alt="" />
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <?php if (!empty($video_texts)): ?>
                                            <div class="energy__service__content">
                                                <h3><?php echo esc_html($video_texts); ?></h3>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                            if (is_array($animated_images)):
                                $an_img1 = isset($animated_images['image_1']) ? $animated_images['image_1'] : '';
                                $an_img2 = isset($animated_images['image_2']) ? $animated_images['image_2'] : '';
                                ?>
                                <div class="rotate__animation">
                                    <?php if (!empty($an_img1)): ?>
                                        <div class="rotate__img">
                                            <img src="<?php echo esc_url($an_img1); ?>" alt="" />
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($an_img2)): ?>
                                        <div class="rotate__img-one">
                                            <img src="<?php echo esc_url($an_img2); ?>" alt="" />
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<!--contaact section -->
<section class="energy__contact custom__pad">
    <div class="container">
        <div class="row g-xl-5 g-lg-4">
            <div class="col-lg-6">
                <div class="contact__wrapper-left">
                    <div class="energy__header__title">
                        <h2>Contact Form</h2>
                    </div>
                    <?php echo do_shortcode('[contact-form-7 id="0bc2a8c" title="Home Contact form" html_class="energy__contact-form"]'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <?php
                $contact_options = get_field('contact_options');
                $footer_options = get_field('footer_options', 'option');
                if ($footer_options):
                    $social_links = isset($footer_options['social_links']) ? $footer_options['social_links'] : array();
                endif;
                if ($contact_options):
                    $c_heading_text = isset($contact_options['heading_text']) ? $contact_options['heading_text'] : '';
                    $c_title_text = isset($contact_options['title_text']) ? $contact_options['title_text'] : '';
                    $c_texts = isset($contact_options['texts']) ? $contact_options['texts'] : '';
                    $c_contact_info = isset($contact_options['contact_info']) ? $contact_options['contact_info'] : array();
                    $bg_image_1 = isset($contact_options['bg_image_1']) ? $contact_options['bg_image_1'] : '';
                    $bg_image_2 = isset($contact_options['bg_image_2']) ? $contact_options['bg_image_2'] : '';

                    ?>
                    <div class="energy__content__wrapper">
                        <?php if (!empty($c_heading_text)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($c_heading_text); ?>
                            </h3>
                        <?php endif; ?>
                        <?php if (!empty($c_title_text)): ?>
                            <div class="energy__header__title">
                                <h2> <?php echo esc_html($c_title_text); ?></h2>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($c_texts)): ?>
                            <p>
                                <?php echo esc_html($c_texts); ?>
                            </p>
                        <?php endif; ?>
                        <div class="energy__address">
                            <?php if (is_array($c_contact_info)): ?>
                                <ul>
                                    <?php
                                    foreach ($c_contact_info as $info):
                                        if (is_array($info)):
                                            $contact_links = isset($info['contact_links']) ? $info['contact_links'] : array();
                                            $ic = isset($info['icons']) ? $info['icons'] : '';
                                            if (is_array($contact_links)):
                                                $contact_title = isset($contact_links['title']) ? $contact_links['title'] : '';
                                                $contact_url = isset($contact_links['url']) ? $contact_links['url'] : '';
                                            endif;
                                            ?>
                                            <li>
                                                <?php if (!empty($contact_title)): ?>
                                                    <a href="<?php echo esc_url($contact_url); ?>"><span><i
                                                                class="<?php echo esc_attr($ic); ?>"></i></span>
                                                        <?php echo esc_html($contact_title); ?></a>
                                                <?php endif; ?>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                        <?php if (is_array($social_links) || $social_links): ?>
                            <div class="energy__media">
                                <ul>
                                    <?php foreach ($social_links as $soc_link): ?>
                                        <?php
                                        if (is_array($soc_link)):
                                            $links = isset($soc_link['links']) ? $soc_link['links'] : array();
                                            if (is_array($links) || !empty($links)):
                                                $links_title = isset($links['title']) ? $links['title'] : '';
                                                $links_url = isset($links['url']) ? $links['url'] : '';
                                            endif;
                                            ?>
                                            <li>
                                                <?php if (!empty($links_title)): ?>
                                                    <a href="<?php echo esc_url($links_url); ?>" class="media__icon"><i
                                                            class="<?php echo esc_attr($links_title); ?>"></i></a>
                                                <?php endif; ?>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="energy__bg__shape">
        <img src="<?php echo esc_url($bg_image_1); ?>" alt="" />
    </div>
    <div class="energy__bg__shape one">
        <img src="<?php echo esc_url($bg_image_2); ?>" alt="" />
    </div>
</section>

<?php
$energy_transitions = get_field('energy_transitions');
if ($energy_transitions):
    $energy_title = isset($energy_transitions['title']) ? $energy_transitions['title'] : '';
    $energy_image = isset($energy_transitions['image']) ? $energy_transitions['image'] : '';
    $energy_button_link = isset($energy_transitions['button_link']) ? $energy_transitions['button_link'] : array();
    ?>
    <section class="energy__clean energy__overlay energy__white__text custom__pad">
        <?php if (!empty($energy_image)): ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($energy_image); ?>" alt="" />
            </div>
        <?php endif; ?>
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row align-items-center g-3 g-lg-5">
                    <div class="col-lg-6">
                        <?php if (!empty($energy_title)): ?>
                            <div class="energy__content__wrapper">
                                <div class="energy__header__title">
                                    <h2><?php echo esc_html($energy_title); ?></h2>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-6">
                        <?php if (is_array($energy_button_link)): ?>
                            <?php
                            $energy_btn_title = isset($energy_button_link['title']) ? $energy_button_link['title'] : '';
                            $energy_btn_url = isset($energy_button_link['url']) ? $energy_button_link['url'] : '';
                            ?>
                            <div class="energy__clean-right">
                                <?php if (!empty($energy_btn_title)): ?>
                                    <a href="<?php echo esc_url($energy_btn_url); ?>"
                                        class="energy__btn"><?php echo esc_html($energy_btn_title); ?>
                                        <span> <i class="fa-solid fa-bolt-lightning"></i> </span></a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php get_footer(); ?>