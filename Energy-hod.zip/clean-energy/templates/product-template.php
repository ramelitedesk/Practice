<?php
/*Template Name:products*/
get_header();
?>

<?php
$b = get_field('banner_options');
if ($b):
    $i = isset($b['banner_image']) ? $b['banner_image'] : '';
    ?>
    <section class="energy__inner__banner energy__overlay custom__pad">
        <?php if (!empty($i)): ?>
            <?php
            $id = attachment_url_to_postid($i);
            if ($id):
                $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
                $t = get_the_title($id);
            endif;
            ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($i); ?>" alt="<?php echo esc_attr($alt); ?>"
                    title="<?php echo esc_attr($t); ?>" />
            </div>
        <?php endif; ?>
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-12">
                        <div class="energy__content__wrapper">

                            <div class="energy__header__title">
                                <h1><?php echo get_the_title(); ?></h1>
                            </div>
                            <nav class="energy__breadcrumb" aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo get_the_title(); ?>
                                    </li>
                                </ol>
                            </nav>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$c = get_field('category_options');
if ($c):
    $h = isset($c['heading_text']) ? $c['heading_text'] : '';
    $t = isset($c['title_texts']) ? $c['title_texts'] : '';
    $e = isset($c['texts']) ? $c['texts'] : '';
    ?>
    <section class="energy__product custom__pad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="energy__content__wrapper">
                        <?php if (!empty($h)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($h); ?>
                            </h3>
                        <?php endif; ?>
                        <?php if (!empty($t)): ?>
                            <div class="energy__header__title">
                                <h2>
                                    <?php echo esc_html($t); ?>
                                </h2>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($e)): ?>
                            <p><?php echo esc_html($e); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="product__card-wrapper">
                        <div class="row g-2">
                            <div class="col-lg-2 col-md-3 col-6">
                                <a href="<?php echo esc_url(home_url('/products')); ?>" class="product__card">
                                    <div class="product__card__img">
                                        <img src="<?php echo get_template_directory_uri() . '/assets/images/cat__img.png'; ?>"
                                            alt="" />
                                    </div>
                                    <div class="product__card__content">
                                        <h3>All</h3>
                                    </div>
                                </a>
                            </div>
                            <?php
                            $pr = array(
                                'taxonomy' => 'product_category',
                                'orderby' => 'date',
                                'order' => 'DESC',
                                'hide_empty' => false,
                                'parent' => 0,
                            );
                            $pro = get_terms($pr);
                            // pr($pr);
                            $pri = ['Container ESS', 'C&I ESS', 'Residential ESS', 'Photovoltaic System'];

                            // Sort categories based on the priority
                            usort($pro, function ($a, $b) use ($pri) {
                                $pos_a = array_search($a->name, $pri);
                                $pos_b = array_search($b->name, $pri);
    
                                // Move priority categories to the top, keep the rest alphabetically sorted
                                if ($pos_a === false && $pos_b === false) {
                                    return strcmp($a->name, $b->name); // Alphabetical order for non-priority categories
                                }
    
                                return ($pos_a === false ? PHP_INT_MAX : $pos_a) - ($pos_b === false ? PHP_INT_MAX : $pos_b);
                            });
                            foreach ($pro as $c):
                                if (is_object($c)):
                                    $n = $c->name;
                                    $i = $c->term_id;
                                    $u = get_field('thumbnail_image', 'product_category_' . $i);
                                    $id = attachment_url_to_postid($u);
                                    if ($id):
                                        $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
                                        $t = get_the_title($id);
                                    endif;
                                    ?>
                                    <div class="col-lg-2 col-md-3 col-6">
                                        <a href="<?php echo esc_url(get_term_link($i)); ?>" class="product__card">
                                            <?php if (!empty($u)): ?>
                                                <div class="product__card__img">
                                                    <img src="<?php echo esc_url($u); ?>" alt="<?php echo esc_attr($alt); ?>"
                                                        title="<?php echo esc_attr($t); ?>" />
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($n)): ?>
                                                <div class="product__card__content">
                                                    <h3><?php echo esc_html($n); ?></h3>
                                                </div>
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

            </div>

        </div>


    </section>
<?php endif; ?>
<section class="energy__product-one ">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="energy__content__wrapper">
                    <div class="energy__header__title">
                        <h2>Our Products</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="row g-4 g-lg-5">

            <div class="col-md-3">
                <div class="product__one-left">
                    <div class="cat__wrappe">
                        <div class="cat__title">
                            <h3>Categories</h3>
                        </div>
                        <?php
                        $a = array(
                            'taxonomy' => 'product_category',
                            'orderby' => 'date',
                            'order' => 'DESC',
                            'hide_empty' => false,
                            'parent' => 0,
                        );
                        $prc = get_terms($a);
                        $pri = ['Container ESS', 'C&I ESS', 'Residential ESS', 'Photovoltaic System'];

                        // Sort categories based on the priority
                        usort($prc, function ($a, $b) use ($pri) {
                            $pos_a = array_search($a->name, $pri);
                            $pos_b = array_search($b->name, $pri);

                            // Move priority categories to the top, keep the rest alphabetically sorted
                            if ($pos_a === false && $pos_b === false) {
                                return strcmp($a->name, $b->name); // Alphabetical order for non-priority categories
                            }

                            return ($pos_a === false ? PHP_INT_MAX : $pos_a) - ($pos_b === false ? PHP_INT_MAX : $pos_b);
                        });
                        ?>
                        <ul class="product__categories">
                            <?php
                            if (!empty($prc) && !is_wp_error($prc)):
                                $cu = get_queried_object_id();

                                foreach ($prc as $key => $c):
                                    $i = ($c->term_id == $cu) ? 'current-cat' : '';

                                    $s = get_terms(array(
                                        'taxonomy' => 'product_category',
                                        'orderby' => 'date',
                                        'order' => 'ASC',
                                        'hide_empty' => false,
                                        'parent' => $c->term_id,
                                    ));

                                    if (!empty($s) && !is_wp_error($s)):
                                        ?>
                                        <li class="cat__item <?php echo esc_attr($i); ?>">
                                            <a href="<?php echo esc_url(get_term_link($c)); ?>">
                                                <?php echo esc_html($c->name); ?>
                                            </a>
                                            <span class="toggle__icon"><i class="fas fa-plus"></i></span>
                                            <ul class="children">
                                                <?php
                                                foreach ($s as $sc):
                                                    ?>
                                                    <li class="cat__item ">
                                                        <a href="<?php echo esc_url(get_term_link($sc)); ?>">
                                                            <?php echo esc_html($sc->name); ?>
                                                        </a>
                                                    </li>
                                                    <?php
                                                endforeach;
                                                ?>
                                            </ul>
                                        </li>
                                        <?php
                                    else:
                                        ?>
                                        <li class="cat__item <?php echo esc_attr($i); ?>">
                                            <a href="<?php echo esc_url(get_term_link($c)); ?>">
                                                <?php echo esc_html($c->name); ?>
                                            </a>
                                        </li>
                                        <?php
                                    endif;
                                endforeach;
                            endif;
                            ?>
                        </ul>
                    </div>
                    <?php
                    $ct = get_field('cta_options');
                    if ($ct):
                        $i = isset($ct['cta_image']) ? $ct['cta_image'] : '';
                        $t1 = isset($ct['text_1']) ? $ct['text_1'] : '';
                        $t2 = isset($ct['text_2']) ? $ct['text_2'] : '';
                        $pi = isset($ct['phone_image']) ? $ct['phone_image'] : '';
                        $wi = isset($ct['wpp_image']) ? $ct['wpp_image'] : '';
                        ?>
                        <div class="cta__wrapper-one ">
                            <?php if (!empty($i)): ?>
                                <div class="cta__img-wrappe">
                                    <img src="<?php echo esc_url($i); ?>" alt="" />
                                </div>
                            <?php endif; ?>
                            <div class="cta__content-one">
                                <?php if (!empty($t1) || !empty($t2)): ?>
                                    <h4><?php echo esc_html($t1); ?> <span><?php echo esc_html($t2); ?></span></h4>
                                <?php endif; ?>
                                <div class="energy__media">
                                    <ul>
                                        <li>
                                            <a href="#" class="media__icon">
                                                <?php if (!empty($pi)): ?>
                                                    <img src="<?php echo esc_url($pi); ?>" alt="">
                                                <?php endif; ?>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" class="media__icon">
                                                <?php if (!empty($wi)): ?>
                                                    <img src="<?php echo esc_url($wi); ?>" alt="">
                                                <?php endif; ?>
                                            </a>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
            <div class="col-md-9">
                <div class="product__card__one-wrapper">
                    <div class="row g-3">
                        <?php
                        $ar = array(
                            'post_type' => 'product',
                            'post_status' => 'publish',
                            'posts_per_page' => 9,
                            'order' => 'DESC',
                            'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
                        );
                        $q = new WP_Query($ar);

                        if ($q->have_posts()):
                            while ($q->have_posts()):
                                $q->the_post();
                                ?>
                                <?php
                                $id = get_post_thumbnail_id();
                                $u = wp_get_attachment_image_src($id, 'thumbnail-size', true);
                                $ur = $u[0];
                                $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
                                $t = get_the_title($id);
                                ?>
                                <div class="col-lg-4 col-md-6">
                                    <div class="product__card__one">
                                        <div class="product__card__one__img">
                                            <img src="<?php echo $ur; ?>" title="<?php echo $t; ?>"
                                                alt="<?php echo esc_html($alt); ?>">
                                        </div>
                                        <div class="product__card__one__content">
                                            <h3> <a href="<?php echo esc_url(get_the_permalink()); ?>"> <?php the_title(); ?>
                                                </a></h3>
                                            <?php
                                            $co = get_the_content();
                                            $tr = wp_trim_words($co, 15, '...');
                                            ?>
                                            <p><?php echo $tr; ?></p>
                                            <a href="<?php echo esc_url(get_the_permalink()); ?>"
                                                class="energy__btn energy__btn__one">Learn More</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php endif; ?>

                    </div>
                    <div class="pagination__box">
                        <ul class="blog-pagination">
                            <li>
                                <?php
                                echo paginate_links(array(
                                    'total' => $q->max_num_pages,
                                    'current' => max(1, $q->get('paged')),
                                    'format' => '?paged=%#%',
                                    'prev_text' => '&laquo;',
                                    'next_text' => '&raquo;',
                                ));
                                ?>
                            </li>
                        </ul>
                    </div>

                    <?php
                    wp_reset_postdata();

                    ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
$co = get_field('contact_options');
$f = get_field('footer_options', 'option');
$so = isset($f['social_links']) ? $f['social_links'] : array();
if ($co):
    $h = isset($co['heading_text']) ? $co['heading_text'] : '';
    $e = isset($co['texts']) ? $co['texts'] : '';
    $bg = isset($co['bg_image']) ? $co['bg_image'] : '';
    ?>
    <section class="energy__contact-one custom__pad">
        <div class="container">
            <div class="row g-xl-5 g-lg-4">
                <div class="col-lg-6">
                    <div class="energy__content__wrapper">
                        <?php if (!empty($h)): ?>
                            <div class="energy__header__title">
                                <h2><?php echo esc_html($h); ?></h2>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($e)): ?>
                            <p>
                                <?php echo esc_html($e); ?>
                            </p>
                        <?php endif; ?>

                        <?php if (is_array($so) || $so): ?>
                            <div class="energy__media">
                                <ul>
                                    <?php foreach ($so as $l): ?>
                                        <?php
                                        if (is_array($l)):
                                            $li = isset($l['links']) ? $l['links'] : array();
                                            if (is_array($li) || !empty($li)):
                                                $t = isset($li['title']) ? $li['title'] : '';
                                                $ur = isset($li['url']) ? $li['url'] : '';
                                            endif;
                                            ?>
                                            <li>
                                                <?php if (!empty($t)): ?>
                                                    <a href="<?php echo esc_url($ur); ?>" class="media__icon"><i
                                                            class="<?php echo esc_attr($t); ?>"></i></a>
                                                <?php endif; ?>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="contact__wrapper-left contact__grey__bg">
                        <?php echo do_shortcode('[contact-form-7 id="962dc71" title="Product Contact Form" html_class="energy__contact-form"]'); ?>
                    </div>
                </div>

            </div>
        </div>
        <?php if (!empty($bg)): ?>
            <div class="energy__bg__shape">
                <img src="<?php echo esc_url($bg); ?>" alt="">
            </div>
        <?php endif; ?>
    </section>
    <?php
endif;
get_footer();
?>