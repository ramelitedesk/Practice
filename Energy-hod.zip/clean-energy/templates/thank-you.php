<?php
/*Template Name:thanku */
get_header();
?>
<style>
    /* 404 start */
    .page-template-thank-you .energy__header:not(.active) {
        background-color: var(--clr-accent);
    }


    .energy__error .content-box {
        border-radius: 16px;
        box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 12px;
        padding: 40px;
        max-width: 784px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        margin: 60px auto 0;
    }

    .energy__error .content-box .top-header h3 {
        color: var(--clr-accent);
        text-align: center;
        margin: 12px 0;
    }

    .energy__error .content-box .top-header h1 {
        font-size: 80px;
        font-weight: 800;
        text-align: center;
        color: var(--clr-accent);
    }

    .energy__error .energy__btn {
        border-radius: 6px;
        margin-top: 15px;
    }

    .energy__error .energy__btn:hover {
        border-color: var(--clr-secondary);
        color: var(--clr-secondary);
    }

    @media (max-width: 768px) {
        .energy__error .content-box .top-header h1 {
            font-size: 67px;
        }

        .energy__error .content-box {
            margin: 42px auto 0;
        }

    }
</style>
<section class="energy__error center-aligned custom__pad">

    <div class="energy__content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="content-box">
                        <div class="top-header">
                            <h1 class="error-title ">Thank You!</h1>
                            <h3>We appreciate your response!</h3>
                        </div>
                        <p>Your submission has been successfully received. We will get back to you shortly.

                        </p>
                        <a href="<?php echo esc_url(home_url('/')); ?>" class=" energy__btn energy__btn__one">Back to
                            Homepage</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php get_footer(); ?>