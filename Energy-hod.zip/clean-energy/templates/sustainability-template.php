<?php
/*Template Name:sustainability */
get_header();
?>
<?php
$b = get_field('banner_options');
if ($b):
    $i = isset($b['banner_image']) ? $b['banner_image'] : '';
    ?>
    <section class="energy__inner__banner energy__overlay custom__pad">
        <?php if (!empty($i)): ?>
            <?php
            $id = attachment_url_to_postid($i);
            if ($id):
                $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
                $t = get_the_title($id);
            endif;
            ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($i); ?>" alt="<?php echo esc_attr($alt); ?>"
                    title="<?php echo esc_attr($t); ?>" />
            </div>
        <?php endif; ?>
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-12">
                        <div class="energy__content__wrapper">

                            <div class="energy__header__title">
                                <h1><?php echo get_the_title(); ?></h1>
                            </div>
                            <nav class="energy__breadcrumb" aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo get_the_title(); ?>
                                    </li>
                                </ol>
                            </nav>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$b = get_field('energy_business_options');
if ($b):
    $h = isset($b['heading_text']) ? $b['heading_text'] : '';
    $t = isset($b['title_text']) ? $b['title_text'] : '';
    $e = isset($b['texts']) ? $b['texts'] : '';
    $i = isset($b['image']) ? $b['image'] : '';
    $l = isset($b['button_link']) ? $b['button_link'] : array();
    ?>
    <section class="energy__bussiness custom__pad pb-0">
        <div class="container">
            <div class="row g-4 g-lg-5">
                <div class="col-lg-6">
                    <div class="energy__content__wrapper">
                        <?php if (!empty($h)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($h); ?>
                            </h3>
                        <?php endif; ?>
                        <?php if (!empty($t)): ?>
                            <div class="energy__header__title">
                                <h2>
                                    <?php echo esc_html($t); ?>
                                </h2>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($e)): ?>
                            <div class="energy__para">
                                <p><?php echo esc_html($e); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about__content-right">
                        <?php if (!empty($i)): ?>
                            <div class="about__img__wrapper">
                                <img src="<?php echo esc_url($i); ?>" alt="" />
                            </div>
                        <?php endif; ?>
                        <?php if (is_array($l)): ?>
                            <?php if (!empty($l['title'])): ?>
                                <a href="<?php echo esc_url($l['url']); ?>"
                                    class="energy__btn energy__btn__one"><?php echo esc_html($l['title']); ?>
                                    <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

        </div>
    </section>
<?php endif; ?>
<?php
$v = get_field('our_values_options');
if ($v):
    $h = isset($v['heading_text']) ? $v['heading_text'] : '';
    $t = isset($v['title_text']) ? $v['title_text'] : '';
    $i = isset($v['image']) ? $v['image'] : '';
    $vc = isset($v['value_cards']) ? $v['value_cards'] : array();
    ?>
    <section class="energy__value custom__pad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="energy__content__wrapper">
                        <?php if (!empty($h)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($h); ?>
                            </h3>
                        <?php endif; ?>
                        <?php if (!empty($t)): ?>
                            <div class="energy__header__title">
                                <h2>
                                    <?php echo esc_html($t); ?>
                                </h2>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-lg-12">
                    <div class="value__content-wrapper">
                        <div class="row g-3">
                            <?php
                            $n = count($vc);
                            $m = ceil($n / 2);
                            $chunks = array_chunk($vc, 2); // Split $vc into groups of 2
                        
                            for ($j = 0; $j < $m; $j++):
                                // $cls = ($j == 0) ? 'col-lg-4 col-md-6' : 'col-lg-4 col-';
                                $dir = ($j == 0) ? 'left' : 'right';
                                ?>
                                <div class="col-lg-4">
                                    <div class="value__card-wrapper <?php echo esc_attr($dir); ?>">
                                        <?php if (!empty($chunks[$j])): ?>
                                            <?php foreach ($chunks[$j] as $index => $c): ?>
                                                <div class="value__card">
                                                    <div class="value__icon">
                                                        <span class="num"><?php echo sprintf('%02d', ($j * 2) + $index + 1); ?></span>
                                                    </div>
                                                    <div class="value__content__wrapper">
                                                        <h3><?php echo esc_html($c['title'] ?? 'Default Title'); ?></h3>
                                                        <p><?php echo esc_html($c['texts'] ?? 'Default Description'); ?></p>
                                                        <a href="<?php echo esc_url($c['button_link']['link'] ?? '#'); ?>"
                                                            class="energy__btn energy__btn__one">
                                                            <?php echo esc_html($c['button_link']['title'] ?? '#'); ?> <span><i
                                                                    class="fa-solid fa-bolt-lightning"></i></span>
                                                        </a>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php if ($j == 0): ?>
                                    <!-- Image Column (Centered) -->
                                    <?php if (!empty($i)): ?>
                                        <div class="col-lg-4 d-none d-lg-block">
                                            <div class="value__content-center">
                                                <div class="value__img__wrapper">
                                                    <img src="<?php echo esc_url($i); ?>" alt="Value Image" />
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endfor; ?>


                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$ct = get_field('cta_options');
if ($ct):
    $h = isset($ct['heading_texts']) ? $ct['heading_texts'] : '';
    $t = isset($ct['title_texts']) ? $ct['title_texts'] : '';
    $e = isset($ct['texts']) ? $ct['texts'] : '';
    $i = isset($ct['image']) ? $ct['image'] : '';
    $l = isset($ct['button_link']) ? $ct['button_link'] : array();
    ?>
    <section class="energy__cta-one energy__overlay energy__white__text custom__pad">
        <?php if (!empty($i)): ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($i); ?>" alt="" />
            </div>
        <?php endif; ?>
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-12">
                        <div class="energy__content__wrapper">
                            <?php if (!empty($h)): ?>
                                <h3 class="energy__sub__title">
                                    <span>
                                        <i class="fa-solid fa-bolt"></i>
                                    </span>
                                    <?php echo esc_html($h); ?>
                                </h3>
                            <?php endif; ?>
                            <?php if (!empty($t)): ?>
                                <div class="energy__header__title">
                                    <h2>
                                        <?php echo esc_html($t); ?>
                                    </h2>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($e)): ?>
                                <p><?php echo esc_html($e); ?></p>
                            <?php endif; ?>
                            <?php if (is_array($l)): ?>
                                <?php if (!empty($l['title'])): ?>
                                    <a href="<?php echo esc_url($l['url']); ?>"
                                        class="energy__btn energy__btn__one"><?php echo esc_html($l['title']); ?>
                                        <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$ct2 = get_field('cta_options2');
if ($ct2):
    $h = isset($ct2['heading_texts']) ? $ct2['heading_texts'] : '';
    $t = isset($ct2['title_texts']) ? $ct2['title_texts'] : '';
    $e = isset($ct2['texts']) ? $ct2['texts'] : '';
    $i = isset($ct2['image']) ? $ct2['image'] : '';
    $l = isset($ct2['button_link']) ? $ct2['button_link'] : array();
    ?>
    <section class="energy__about-two  custom__pad">
        <div class="container">
            <div class="row g-4 g-lg-5">
                <div class="col-lg-6">
                    <div class="energy__content__wrapper">
                        <?php if (!empty($h)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($h); ?>
                            </h3>
                        <?php endif; ?>
                        <?php if (!empty($t)): ?>
                            <div class="energy__header__title">
                                <h2>
                                    <?php echo esc_html($t); ?>
                                </h2>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($e)): ?>
                            <p><?php echo esc_html($e); ?></p>
                        <?php endif; ?>
                        <?php if (is_array($l)): ?>
                            <?php if (!empty($l['title'])): ?>
                                <a href="<?php echo esc_url($l['url']); ?>"
                                    class="energy__btn energy__btn__one"><?php echo esc_html($l['title']); ?>
                                    <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about__content-right">
                        <?php if (!empty($i)): ?>
                            <div class="about__img__wrapper">
                                <img src="<?php echo esc_url($i); ?>" alt="" />
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

        </div>
    </section>
<?php endif; ?>
<?php
$sw = get_field('save_the_world');
if ($sw):
    $h = isset($sw['heading_texts']) ? $sw['heading_texts'] : '';
    $t = isset($sw['title_texts']) ? $sw['title_texts'] : '';
    $i = isset($sw['image']) ? $sw['image'] : '';
    $l = isset($sw['button_link']) ? $sw['button_link'] : array();
    ?>
    <section class="energy__green energy__green-one  energy__white__text custom__pad">
        <?php if (!empty($i)): ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($i); ?>" alt="" />
            </div>
        <?php endif; ?>
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="energy__content__wrapper">
                            <div class="energy__header__title">
                                <?php if (!empty($h)): ?>
                                    <h2><span> <?php echo esc_html($h); ?></span> </h2>
                                <?php endif; ?>
                                <?php if (!empty($t)): ?>
                                    <h3> <?php echo esc_html($t); ?></h3>
                                <?php endif; ?>
                            </div>
                            <?php if (is_array($l)): ?>
                                <?php if (!empty($l['title'])): ?>
                                    <a href="<?php echo esc_url($l['url']); ?>"
                                        class="energy__btn"><?php echo esc_html($l['title']); ?>
                                        <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$et = get_field('energy_transition');
if ($et):
    $h = isset($et['heading_texts']) ? $et['heading_texts'] : '';
    $i = isset($et['image']) ? $et['image'] : '';
    $l = isset($et['button_link']) ? $et['button_link'] : array();
    ?>
    <section class="energy__clean energy__overlay energy__white__text custom__pad">
        <?php if (!empty($i)): ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($i); ?>" alt="" />
            </div>
        <?php endif; ?>
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row align-items-center g-3 g-lg-5">
                    <div class="col-lg-6">
                        <div class="energy__content__wrapper">
                            <?php if (!empty($h)): ?>
                                <div class="energy__header__title">
                                    <h2><span> <?php echo esc_html($h); ?></span> </h2>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <?php if (is_array($l)): ?>
                            <div class="energy__clean-right">
                                <?php if (!empty($l['title'])): ?>
                                    <a href="<?php echo esc_url($l['url']); ?>"
                                        class="energy__btn"><?php echo esc_html($l['title']); ?>
                                        <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php get_footer(); ?>