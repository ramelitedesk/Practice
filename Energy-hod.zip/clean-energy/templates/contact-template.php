<?php
/*Template Name:contact */
get_header();
?>
<?php
$b = get_field('banner_options');
if ($b):
    $i = isset($b['banner_image']) ? $b['banner_image'] : '';
    ?>
    <section class="energy__inner__banner energy__overlay custom__pad">
        <?php if (!empty($i)): ?>
            <?php
            $id = attachment_url_to_postid($i);
            if ($id):
                $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
                $t = get_the_title($id);
            endif;
            ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($i); ?>" alt="<?php echo esc_attr($alt); ?>"
                    title="<?php echo esc_attr($t); ?>" />
            </div>
        <?php endif; ?>
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-12">
                        <div class="energy__content__wrapper">

                            <div class="energy__header__title">
                                <h1><?php echo get_the_title(); ?></h1>
                            </div>
                            <nav class="energy__breadcrumb" aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo get_the_title(); ?>
                                    </li>
                                </ol>
                            </nav>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<section class="energy__contact custom__pad">
    <div class="container">
        <div class="row g-xl-5 g-lg-4">
            <div class="col-lg-6">
                <div class="contact__wrapper-left">
                    <div class="energy__header__title">
                        <h2>Contact Form</h2>
                    </div>
                    <?php echo do_shortcode('[contact-form-7 id="0bc2a8c" title="Home Contact form" html_class="energy__contact-form"]'); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <?php
                $c = get_field('contact_options');
                $f = get_field('footer_options', 'option');
                if ($f):
                    $s = isset($f['social_links']) ? $f['social_links'] : array();
                endif;
                if ($c):
                    $h = isset($c['heading_text']) ? $c['heading_text'] : '';
                    $t = isset($c['title_text']) ? $c['title_text'] : '';
                    $e = isset($c['texts']) ? $c['texts'] : '';
                    $ci = isset($c['contact_info']) ? $c['contact_info'] : array();
                    $i1 = isset($c['bg_image_1']) ? $c['bg_image_1'] : '';
                    $i2 = isset($c['bg_image_2']) ? $c['bg_image_2'] : '';

                    ?>
                    <div class="energy__content__wrapper">
                        <?php if (!empty($h)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($h); ?>
                            </h3>
                        <?php endif; ?>
                        <?php if (!empty($t)): ?>
                            <div class="energy__header__title">
                                <h2> <?php echo esc_html($t); ?></h2>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($e)): ?>
                            <p>
                                <?php echo esc_html($e); ?>
                            </p>
                        <?php endif; ?>
                        <div class="energy__address">
                            <?php if (is_array($ci)): ?>
                                <ul>
                                    <?php
                                    foreach ($ci as $i):
                                        if (is_array($i)):
                                            $cl = isset($i['contact_links']) ? $i['contact_links'] : array();
                                            $ic = isset($i['icons']) ? $i['icons'] : '';
                                            if (is_array($cl)):
                                                $ct = isset($cl['title']) ? $cl['title'] : '';
                                                $cu = isset($cl['url']) ? $cl['url'] : '';
                                            endif;
                                            ?>
                                            <li>
                                                <?php if (!empty($ct)): ?>
                                                    <a href="<?php echo esc_url($cu); ?>"><span><i
                                                                class="<?php echo esc_attr($ic); ?>"></i></span>
                                                        <?php echo esc_html($ct); ?></a>
                                                <?php endif; ?>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                        <?php if (is_array($s) || $s): ?>
                            <div class="energy__media">
                                <ul>
                                    <?php foreach ($s as $l): ?>
                                        <?php
                                        if (is_array($l)):
                                            $sl = isset($l['links']) ? $l['links'] : array();
                                            if (is_array($sl) || !empty($sl)):
                                                $lt = isset($sl['title']) ? $sl['title'] : '';
                                                $lu = isset($sl['url']) ? $sl['url'] : '';
                                            endif;
                                            ?>
                                            <li>
                                                <?php if (!empty($lt)): ?>
                                                    <a href="<?php echo esc_url($lu); ?>" class="media__icon"><i
                                                            class="<?php echo esc_attr($lt); ?>"></i></a>
                                                <?php endif; ?>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="energy__bg__shape">
        <img src="<?php echo esc_url($i1); ?>" alt="" />
    </div>
    <div class="energy__bg__shape one">
        <img src="<?php echo esc_url($bg_image_2); ?>" alt="" />
    </div>
</section>
<section class="energy__map">
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-lg-12">
                <?php echo get_field('location_map'); ?>
            </div>
        </div>
    </div>
</section>

<section class="energy__faq custom__pad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <?php
                $inf = get_field('contact_info');
                if ($inf):
                    $i = isset($inf['icon']) ? $inf['icon'] : '';
                    $t = isset($inf['title']) ? $inf['title'] : '';
                    $c = isset($inf['contact_links']) ? $inf['contact_links'] : array();
                    ?>
                    <div class="address__card-wrapper custom__pad pt-0">
                        <div class="row g-3">
                            <?php foreach ($inf as $if): ?>
                                <?php if (is_array($if)): ?>
                                    <?php
                                    $i = isset($if['icon']) ? $if['icon'] : '';
                                    $t = isset($if['title']) ? $if['title'] : '';
                                    $c = isset($if['contact_links']) ? $if['contact_links'] : array();
                                    ?>
                                    <div class="col-md-4">
                                        <div class="address__card">
                                            <?php if (!empty($i)): ?>
                                                <div class="address__card__icon">
                                                    <img src="<?php echo esc_url($i); ?>" alt="" />
                                                </div>
                                            <?php endif; ?>
                                            <div class="address__card__content">
                                                <?php if (!empty($t)): ?>
                                                    <h3><?php echo esc_html($t); ?></h3>
                                                <?php endif; ?>
                                                <?php
                                                if (is_array($c)):
                                                    $ct = isset($c['title']) ? $c['title'] : '';
                                                    $cu = isset($c['url']) ? $c['url'] : '';
                                                endif;
                                                ?>
                                                <?php if (!empty($ct)): ?>
                                                    <p><a href="<?php echo esc_url($cu); ?>"><?php echo esc_html($ct); ?></a></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        $fq = get_field('faq_options');
        if ($fq):
            $i = isset($fq['image']) ? $fq['image'] : '';
            $h = isset($fq['heading_text']) ? $fq['heading_text'] : '';
            $t = isset($fq['title_text']) ? $fq['title_text'] : '';
            $e = isset($fq['texts']) ? $fq['texts'] : '';
        endif;
        $a = get_field('accordions');
        $fb = get_field('faq_button_link');
        ?>
        <div class="row g-xl-5 g-lg-4">
            <div class="col-lg-6">
                <?php if (!empty($i)): ?>
                    <div class="faq__left__part">
                        <div class="faq__img-wrapper">
                            <img src="<?php echo esc_url($i); ?>" alt="" />
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-lg-6">
                <div class="energy__content__wrapper">
                    <?php if (!empty($h)): ?>
                        <h3 class="energy__sub__title">
                            <span><i class="fa-solid fa-bolt"></i></span>
                            <?php echo esc_html($h); ?>
                        </h3>
                    <?php endif; ?>
                    <?php if (!empty($t)): ?>
                        <div class="energy__header__title">
                            <h2><?php echo esc_html($t); ?></h2>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($e)): ?>
                        <p><?php echo esc_html($e); ?></p>
                    <?php endif; ?>

                    <?php if (is_array($a) && !empty($a)): ?>
                        <div class="faq__item_wrapper">
                            <div class="accordion" id="accordionExample">
                                <?php foreach ($a as $aa => $acc): ?>
                                    <?php
                                    $q = $acc['question_text'] ?? '';
                                    $s = $acc['solution_texts'] ?? '';
                                    $show = ($aa == 0) ? 'show' : '';
                                    $ex = ($aa == 0) ? 'true' : 'false';
                                    ?>
                                    <?php if (!empty($q)): ?>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header" id="heading<?php echo $aa; ?>">
                                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#collapse<?php echo $aa; ?>" aria-expanded="<?php echo $ex; ?>"
                                                    aria-controls="collapse<?php echo $aa; ?>">
                                                    <?php echo esc_html($q); ?>
                                                </button>
                                            </h2>
                                            <?php if (!empty($s)): ?>
                                                <div id="collapse<?php echo $aa; ?>"
                                                    class="accordion-collapse collapse <?php echo $show; ?>"
                                                    aria-labelledby="heading<?php echo $aa; ?>" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <p><?php echo esc_html($s); ?></p>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if (is_array($fb) && !empty($fb)): ?>
                        <?php
                        $ft = $fb['title'] ?? '';
                        $fu = $fb['url'] ?? '';
                        ?>
                        <?php if (!empty($ft) && !empty($fu)): ?>
                            <a href="<?php echo esc_url($fu); ?>" class="energy__btn energy__btn__one">
                                <?php echo esc_html($ft); ?>
                                <span><i class="fa-solid fa-bolt-lightning"></i></span>
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</section>

<?php get_footer(); ?>