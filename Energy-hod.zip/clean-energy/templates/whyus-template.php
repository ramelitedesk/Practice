<?php
/*Template Name:why-us*/
get_header();
?>
<?php
$b = get_field('banner_options');
if ($b):
    $i = isset($b['banner_image']) ? $b['banner_image'] : '';
    ?>
    <section class="energy__inner__banner energy__overlay custom__pad">
        <?php if (!empty($i)): ?>
            <?php
            $id = attachment_url_to_postid($i);
            if ($id):
                $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
                $t = get_the_title($id);
            endif;
            ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($i); ?>" alt="<?php echo esc_attr($alt); ?>"
                    title="<?php echo esc_attr($t); ?>" />
            </div>
        <?php endif; ?>
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-12">
                        <div class="energy__content__wrapper">

                            <div class="energy__header__title">
                                <h1><?php echo get_the_title(); ?></h1>
                            </div>
                            <nav class="energy__breadcrumb" aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo get_the_title(); ?>
                                    </li>
                                </ol>
                            </nav>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$b = get_field('benifit_options');
$btn = get_field('benefit_section_button');
if ($b):
    $bh = isset($b['benefit_heading_text']) ? $b['benefit_heading_text'] : '';
    $bt = isset($b['benefit_title_text']) ? $b['benefit_title_text'] : '';
    $be = isset($b['benefit_texts']) ? $b['benefit_texts'] : '';
    ?>
    <section class="energy__why-us custom__pad ">
        <div class="container">
            <div class="row g-4 g-lg-5">
                <div class="col-lg-6">
                    <div class="energy__content__wrapper">
                        <?php if (!empty($bh)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($bh); ?>
                            </h3>
                        <?php endif; ?>
                        <?php if (!empty($bt)): ?>
                            <div class="energy__header__title">
                                <h2>
                                    <?php echo esc_html($bt); ?>
                                </h2>
                            </div>
                        <?php endif; ?>
                        <?php
                        $v = isset($b['our_vision_options']) ? $b['our_vision_options'] : array();
                        if ($v):
                            $vh = isset($v['heading_text']) ? $v['heading_text'] : '';
                            $vt = isset($v['title_text']) ? $v['title_text'] : '';
                            $vi = isset($v['image']) ? $v['image'] : '';
                            ?>
                            <div class="why__us__img-box">
                                <?php if (!empty($vi)): ?>
                                    <div class="about__img__wrapper">
                                        <img src="<?php echo esc_url($vi); ?>" alt="" />
                                    </div>
                                <?php endif; ?>
                                <div class="left__bottom-box">
                                    <?php if (!empty($vh)): ?>
                                        <h3 class="energy__sub__title">
                                            <span>
                                                <i class="fa-solid fa-bolt"></i>
                                            </span>
                                            <?php echo esc_html($vh); ?>
                                        </h3>
                                    <?php endif; ?>
                                    <?php if (!empty($vt)): ?>
                                        <div class="energy__header__title">
                                            <h2>
                                                <?php echo esc_html($vt); ?>
                                            </h2>
                                        </div>
                                    <?php endif; ?>

                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="why__content-wrapper">
                        <?php if (!empty($be)): ?>
                            <?php echo $be; ?>
                        <?php endif; ?>
                        <?php
                        $m = isset($b['our_mission_options']) ? $b['our_mission_options'] : array();
                        if ($m):
                            $mh = isset($m['heading_text']) ? $m['heading_text'] : '';
                            $mt = isset($m['title_text']) ? $m['title_text'] : '';
                            $me = isset($m['texts']) ? $m['texts'] : '';
                            $ml = isset($m['lists']) ? $m['lists'] : array();
                            if (!empty($mh)):
                                ?>
                                <h3 class="energy__sub__title">
                                    <span>
                                        <i class="fa-solid fa-bolt"></i>
                                    </span>
                                    <?php echo esc_html($mh); ?>
                                </h3>
                            <?php endif; ?>
                            <?php if (!empty($mt)): ?>
                                <div class="energy__header__title">
                                    <h2>
                                        <?php echo esc_html($mt); ?>
                                    </h2>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($me)): ?>
                                <?php echo $me; ?>
                            <?php endif; ?>
                            <?php if (is_array($ml)): ?>
                                <ul class="why__us-list">
                                    <?php foreach ($ml as $l): ?>
                                        <?php if (is_array($l)): ?>
                                            <?php if (!empty($l['text'])): ?>
                                                <li><span><i class="fa-solid fa-check"></i></span> <?php echo esc_html($l['text']); ?></li>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if (is_array($btn)): ?>
                            <?php if (!empty($btn['title'])): ?>
                                <a href="<?php echo esc_url($btn['url']); ?>"
                                    class="energy__btn energy__btn__one"><?php echo esc_html($btn['title']); ?>
                                    <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

        </div>
    </section>
<?php endif; ?>
<?php
$w = get_field('what_we_do_option');
if ($w):
    $wh = isset($w['heading_text']) ? $w['heading_text'] : '';
    $wt = isset($w['title_text']) ? $w['title_text'] : '';
    $we = isset($w['texts']) ? $w['texts'] : '';
    ?>
    <section class="energy__why-choose-one custom__pad bg__one energy__white__text">
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-12">
                        <div class="energy__content__wrapper">
                            <?php if (!empty($wh)): ?>
                                <h3 class="energy__sub__title">
                                    <span>
                                        <i class="fa-solid fa-bolt"></i>
                                    </span>
                                    <?php echo esc_html($wh); ?>
                                </h3>
                            <?php endif; ?>
                            <?php if (!empty($wt)): ?>
                                <div class="energy__header__title">
                                    <h2><?php echo esc_html($wt); ?></h2>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($we)): ?>
                                <?php echo $we; ?>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$wc = get_field('why_choose_cards');
if ($wc):
    ?>
    <section class="energy__why-choose-two">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="col-lg-12">
                        <div class="whychoose__card__wrapper energy__grid">
                            <?php foreach ($wc as $c): ?>
                                <?php if (is_array($c)): ?>
                                    <?php
                                    $i = isset($c['icon']) ? $c['icon'] : '';
                                    $t = isset($c['title']) ? $c['title'] : '';
                                    $e = isset($c['texts']) ? $c['texts'] : '';
                                    $b = isset($c['button_link']) ? $c['button_link'] : array();
                                    ?>
                                    <div class="whychoose__card">
                                        <?php if (!empty($i)): ?>
                                            <div class="whychoose__icon">
                                                <img src="<?php echo esc_url($i); ?>" alt="">
                                            </div>
                                        <?php endif; ?>
                                        <div class="whychoose__content__wrapper">
                                            <?php if (!empty($t)): ?>
                                                <h3><?php echo esc_html($t); ?></h3>
                                            <?php endif; ?>
                                            <?php if (!empty($e)): ?>
                                                <p>
                                                    <?php echo esc_html($e); ?>
                                                </p>
                                            <?php endif; ?>
                                            <?php if (is_array($b)): ?>
                                                <?php if (!empty($b['title'])): ?>
                                                    <a href="<?php echo esc_url($b['url']); ?>"
                                                        class="energy__btn energy__btn__one"><?php echo esc_html($b['title']); ?>
                                                        <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                                                    </a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$ce = get_field('clean_energy_options');
if ($ce):
    $is = isset($ce['images']) ? $ce['images'] : array();
    $h = isset($ce['heading_text']) ? $ce['heading_text'] : '';
    $t = isset($ce['title_text']) ? $ce['title_text'] : '';
    $e = isset($ce['texts']) ? $ce['texts'] : '';
    $bl = isset($ce['button_link']) ? $ce['button_link'] : array();
    ?>
    <section class="energy__gallery custom__pad ">
        <div class="container">
            <div class="row g-4 g-lg-5 align-items-center">
                <div class="col-lg-6">
                    <div class="energy__gallery-left">
                        <?php if (is_array($is)): ?>
                            <div class="gallery__wrapper">
                                <?php foreach ($is as $k => $i): ?>
                                    <?php if (!empty($i['image'])): ?>
                                        <div class="gallery__box0<?php echo $k + 1; ?> about__img__wrapper">
                                            <img src="<?php echo esc_url($i['image']); ?>" alt="" />
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="why__content-wrapper">
                        <?php if (!empty($h)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($h); ?>
                            </h3>
                        <?php endif; ?>
                        <?php if (!empty($t)): ?>
                            <div class="energy__header__title">
                                <h2>
                                    <?php echo esc_html($t); ?>
                                </h2>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($e)): ?>
                            <p> <?php echo esc_html($e); ?></p>
                        <?php endif; ?>
                        <?php if (is_array($bl)): ?>
                            <?php if (!empty($bl['title'])): ?>
                                <a href="<?php echo esc_url($bl['url']); ?>"
                                    class="energy__btn energy__btn__one"><?php echo esc_html($bl['title']); ?>
                                    <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>

                    </div>
                </div>

            </div>

        </div>
    </section>
<?php endif; ?>
<?php
$wo = get_field('work_with_us_option');
if ($wo):
    $h = isset($wo['heading_text']) ? $wo['heading_text'] : '';
    $t = isset($wo['title_text']) ? $wo['title_text'] : '';
    $e = isset($wo['texts']) ? $wo['texts'] : '';
    $bl = isset($wo['button_link']) ? $wo['button_link'] : array();
    ?>
    <section class="energy__about-text custom__pad pt-0">
        <div class="container">
            <div class="row g-2 g-lg-5 align-items-center">
                <div class="col-lg-6">
                    <div class="energy__about-left">
                        <?php if (!empty($h)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($h); ?>
                            </h3>
                        <?php endif; ?>
                        <?php if (!empty($t)): ?>
                            <div class="energy__header__title">
                                <h2>
                                    <?php echo esc_html($t); ?>
                                </h2>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>
                <div class="col-lg-6">
                    <div class="why__content-wrapper">


                        <?php if (!empty($e)): ?>
                            <p> <?php echo esc_html($e); ?></p>
                        <?php endif; ?>

                        <?php if (is_array($bl)): ?>
                            <?php if (!empty($bl['title'])): ?>
                                <a href="<?php echo esc_url($bl['url']); ?>"
                                    class="energy__btn energy__btn__one"><?php echo esc_html($bl['title']); ?>
                                    <span> <i class="fa-solid fa-bolt-lightning"></i></span>
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>

                    </div>
                </div>

            </div>

        </div>
    </section>
<?php endif; ?>
<?php
$ct = get_field('cta_options');
if ($ct):
    $i = isset($ct['image']) ? $ct['image'] : '';
    ?>
    <section class="energy__about-four ">
        <?php if (!empty($i)): ?>
            <div class="energy__bg__box">
                <img rel="preload" src="<?php echo esc_url($i); ?>" alt="">
            </div>
        <?php endif; ?>
    </section>
<?php endif; ?>
<?php
$ec = get_field('energy_cards');
if (is_array($ec)):
    ?>
    <section class="energy__card-three custom__pad  pt-0">
        <div class="energy__section__wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="feature__card__wrapper">
                            <div class="row g-2">
                                <?php foreach ($ec as $ecc): ?>
                                    <?php if (is_array($ecc)): ?>
                                        <?php
                                        $l = isset($ecc['links']) ? $ecc['links'] : '';
                                        $i = isset($ecc['image']) ? $ecc['image'] : '';
                                        $t = isset($ecc['title']) ? $ecc['title'] : '';
                                        ?>
                                        <div class="col-lg-3 col-md-6">
                                            <a href="<?php echo esc_url($l); ?>" class="feature__card energy__overlay">
                                                <?php if (!empty($i)): ?>
                                                    <div class="feature__img__wrapper">
                                                        <img src="<?php echo esc_url($i); ?>" alt="">
                                                    </div>
                                                <?php endif; ?>
                                                <div class="feature__content__wrapper">
                                                    <?php if (!empty($t)): ?>
                                                        <h3>
                                                            <?php echo esc_html($t); ?>
                                                            <span>
                                                                <img src="<?php echo get_template_directory_uri() . '/assets/images/arrow__icon.png'; ?>"
                                                                    alt="this is an image">
                                                            </span>
                                                        </h3>
                                                    <?php endif; ?>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$o = get_field('one_energy');
if ($o):
    $h = isset($o['heading_text']) ? $o['heading_text'] : '';
    $t = isset($o['title_text']) ? $o['title_text'] : '';
    $e = isset($o['texts']) ? $o['texts'] : '';
    $i = isset($o['image']) ? $o['image'] : '';
    ?>
    <section class="energy__about-five">
        <div class="container">
            <div class="row g-4 g-lg-5">
                <div class="col-lg-6">
                    <div class="about__content-wrapper">

                        <?php if (!empty($h)): ?>
                            <h3 class="energy__sub__title">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                </span>
                                <?php echo esc_html($h); ?>
                            </h3>
                        <?php endif; ?>
                        <?php if (!empty($t)): ?>
                            <div class="energy__header__title">
                                <h2>
                                    <?php echo esc_html($t); ?>
                                </h2>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($e)): ?>
                            <p> <?php echo esc_html($e); ?></p>
                        <?php endif; ?>

                    </div>
                </div>
                <div class="col-lg-6">
                    <?php if (!empty($i)): ?>
                        <div class="energy__about-right">
                            <div class="about__img__wrapper">
                                <img src="<?php echo esc_html($i); ?>" alt="" />
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$f = get_field('feature_cards');
if ($f):
    ?>
    <section class="energy__feature custom__pad pt-0">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="partner__card__wrapper">
                        <div class="row g-3">
                            <?php
                            foreach ($f as $r => $fc):
                                if (is_array(value: $fc)):
                                    $i = isset($fc['image']) ? $fc['image'] : '';
                                    $ic = isset($fc['count_image']) ? $fc['count_image'] : '';
                                    $t = isset($fc['title']) ? $fc['title'] : '';
                                    $e = isset($fc['text']) ? $fc['text'] : '';
                                    ?>
                                    <div class="col-lg-3 col-md-6">
                                        <div class="partner__card">
                                            <?php if (!empty($i)): ?>
                                                <div class="partner__img_wrapper">
                                                    <img src="<?php echo esc_url($i); ?>" alt="" />
                                                </div>
                                            <?php endif; ?>
                                            <div class="partner__icon">
                                                <!-- <img src="<?php echo esc_url($ic); ?>" alt="" /> -->
                                                <span>0<?php echo $r + 1; ?></span>
                                            </div>
                                            <div class="partner__content__wrapper">
                                                <?php if (!empty($t)): ?>
                                                    <h3><?php echo esc_html($t); ?></h3>
                                                <?php endif; ?>
                                                <?php if (!empty($e)): ?>
                                                    <p>
                                                        <?php echo esc_html($e); ?>
                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php get_footer(); ?>