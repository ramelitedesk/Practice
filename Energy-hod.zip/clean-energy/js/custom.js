// for animation
AOS.init({
  offset: 200,
  duration: 600,
  easing: "ease-in-sine",
  delay: 100,
});

// top scroll bar
document.addEventListener("DOMContentLoaded", function () {
  const customHeader = document.querySelector(".energy__header");

  function handleScroll() {
    // Check if the window scroll position is more than 50px from the top
    if (window.scrollY > 50) {
      customHeader.classList.add("active");
    } else {
      customHeader.classList.remove("active");
    }
  }
  // Add scroll event listener to handle the scroll effect
  window.addEventListener("scroll", handleScroll);

  // Optionally call handleScroll on page load to set the correct state if already scrolled
  handleScroll();
});

// swiper slider
$(document).ready(function () {
  new Swiper(".energy__slider", {
    loop: true,
    navigation: {
      nextEl: ".energy__slider-next",
      prevEl: ".energy__slider-prev",
    },
    slidesPerView: 4,
    spaceBetween: 20,
    pagination: {
      clickable: true,
    },
    breakpoints: {
     
      992: {
        slidesPerView: 4,
        spaceBetween: 20,
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 15,
      },
      0: {
        slidesPerView: 1.5,
        spaceBetween: 10,
      },
    },
  });

  // counter
  $(function () {
    function animateCounter($element) {
      $element.each(function () {
        var $this = $(this),
          countTo = $this.attr("data-count");
        $({ countNum: 0 }).animate(
          { countNum: countTo },
          {
            duration: 3000,
            easing: "linear",
            step: function () {
              $this.text(Math.floor(this.countNum));
            },
            complete: function () {
              $this.text(this.countNum.toLocaleString());
            },
          }
        );
      });
    }

    function checkVisibility() {
      $(".count").each(function () {
        var $this = $(this);
        if (
          $this.offset().top < $(window).scrollTop() + $(window).height() &&
          !$this.hasClass("counted")
        ) {
          $this.addClass("counted");
          animateCounter($this);
        }
      });
    }

    // Run on load and scroll
    $(window).on("scroll", checkVisibility);
    checkVisibility();
  });
});



//offcanvas handling

document.addEventListener("show.bs.modal", function () {
  let offcanvas = document.querySelector(".offcanvas.show");
  if (offcanvas) {
      let bsOffcanvas = bootstrap.Offcanvas.getInstance(offcanvas);
      bsOffcanvas.hide(); // Close offcanvas before opening modal
  }
});


document.addEventListener("show.bs.offcanvas", function () {
  let modal = document.querySelector(".modal.show");
  if (modal) {
      let bsModal = bootstrap.Modal.getInstance(modal);
      bsModal.hide(); // Close modal before opening offcanvas
  }
});
