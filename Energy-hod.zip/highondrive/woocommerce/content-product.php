<?php

/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.4.0
 */

defined('ABSPATH') || exit;

global $product;

// Check if the product is a valid WooCommerce product and ensure its visibility before proceeding.
if (! is_a($product, WC_Product::class) || ! $product->is_visible()) {
	return;
}
?>
<div class="<?php if(!is_archive()){echo 'product_box_full';}else{echo 'col-lg-4 col-md-4 col-sm-6 col-12';};?>">
	<div class="product__seller-single">
		<div class="product__drive-icon">
			<div class="product__drive-wish">
				<?php echo do_shortcode('[wlfmc_add_to_wishlist]');?>
			</div>
			<div class="product__drive-rating">
			<?php echo do_shortcode('[product_review]');?>
			</div>
		</div>
		<div class="drive-img">
			<?php custom_product_thumb_slider();?>
		</div>
		<div class="drive-content">
			<a href="<?php echo $product->get_permalink(); ?>">
				<h5><?php echo $product->get_name(); ?></h5>
			</a>
		</div>
		<?php
		$product_com = wc_get_product(get_the_ID());
		if ($product_com instanceof WC_Product):
			// Check if the product is variable
			if ($product_com->is_type('variable')) {
				$default_attributes = $product_com->get_default_attributes();
				$variations = $product_com->get_available_variations();
				$default_price = null;

				foreach ($variations as $variation) {
					$variation_product = wc_get_product($variation['variation_id']);
					$matched = true;

					// Check if variation matches default attributes
					foreach ($default_attributes as $key => $value) {
						if ($variation['attributes']['attribute_' . $key] !== $value) {
							$matched = false;
							break;
						}
					}

					if ($matched) {
						$default_price = (float) $variation_product->get_price();
						$regular_price = (float) $variation_product->get_regular_price();
						$sale_price = (float) $variation_product->get_sale_price();
						$discount_percentage = $sale_price && $regular_price > 0
							? round((($regular_price - $sale_price) / $regular_price) * 100)
							: 0;
						break;
					}
				}
		?>
				<div class="drive-price">
					<p>
						<?php if ($sale_price): ?>
							<span class="price-new"><i class="fa fa-inr rs-sym"></i>
								<?php echo esc_html(number_format($sale_price)); ?></span>
							<span class="price-old"><i class="fa fa-inr rs-sym"></i>
								<?php echo esc_html(number_format($regular_price)); ?></span>
							<span class="price-discount">(<?php echo esc_html($discount_percentage); ?>%
								Off)</span>
						<?php else: ?>
							<span class="price-new"><i class="fa fa-inr rs-sym"></i>
								<?php echo esc_html(number_format($default_price)); ?></span>
						<?php endif; ?>
					</p>
				</div>
			<?php
			} else {
				$regular_price = (float) $product_com->get_regular_price();
				$sale_price = (float) $product_com->get_sale_price();
				$discount_percentage = $sale_price && $regular_price > 0
					? round((($regular_price - $sale_price) / $regular_price) * 100)
					: 0;
			?>
				<div class="drive-price">
					<p>
						<?php if ($sale_price): ?>
							<span class="price-new"><i class="fa fa-inr rs-sym"></i>
								<?php echo esc_html(number_format($sale_price)); ?></span>
							<span class="price-old"><i class="fa fa-inr rs-sym"></i>
								<?php echo esc_html(number_format($regular_price)); ?></span>
							<span class="price-discount">(<?php echo esc_html($discount_percentage); ?>%
								Off)</span>
						<?php else: ?>
							<span class="price-new"><i class="fa fa-inr rs-sym"></i>
								<?php echo esc_html(number_format($regular_price)); ?></span>
						<?php endif; ?>
					</p>
				</div>
			<?php } ?>
		<?php endif; ?>

		<?php
			/**
				 * Hook: woocommerce_after_shop_loop_item.
				 *
				 * @hooked woocommerce_template_loop_product_link_close - 5
				 * @hooked woocommerce_template_loop_add_to_cart - 10
				 */
			remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5);
			do_action('woocommerce_after_shop_loop_item');
		?>
	</div>
</div>