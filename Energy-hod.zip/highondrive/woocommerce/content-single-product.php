<?php

/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined('ABSPATH') || exit;

global $product;

/**
 * Hook: woocommerce_before_single_product.
 *
 * @hooked woocommerce_output_all_notices - 10
 */
do_action('woocommerce_before_single_product');

if (post_password_required()) {
	echo get_the_password_form(); // WPCS: XSS ok.
	return;
}
?>
<section class="single_product_details custom-pad pt-0">
	<div class="container">
		<div id="product-<?php the_ID(); ?>" <?php wc_product_class('', $product); ?>>
			<div class="row">
				<div class="col-lg-6">
					<div class="single_product_thumbnail_image">
						<?php echo do_shortcode('[wlfmc_add_to_wishlist]');?>
						<?php
						/**
						 * Hook: woocommerce_before_single_product_summary.
						 *
						 * @hooked woocommerce_show_product_sale_flash - 10
						 * @hooked woocommerce_show_product_images - 20
						 */
						do_action('woocommerce_before_single_product_summary');
						?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="single_product_details">
						
						<?php
						/**
						 * Hook: woocommerce_single_product_summary.
						 *
						 * @hooked woocommerce_template_single_title - 5
						 * @hooked woocommerce_template_single_rating - 10
						 * @hooked woocommerce_template_single_price - 10
						 * @hooked woocommerce_template_single_excerpt - 20
						 * @hooked woocommerce_template_single_meta - 40
						 * @hooked woocommerce_template_single_sharing - 50
						 * @hooked WC_Structured_Data::generate_product_data() - 60
						 */
 
						do_action('woocommerce_single_product_summary');
						
						?>
						<p>Inclusive of all taxes</p>
						<ul class="socials">
							<?php
							$product_url = get_permalink();
							$product_title = get_the_title();
							$product_image = wp_get_attachment_url(get_post_thumbnail_id());
							?>
							<li>
								<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode($product_url); ?>" target="_blank">
									<i class="fa-brands fa-facebook-f"></i>
								</a>
							</li>

							<li>
								<a href="https://twitter.com/intent/tweet?text=<?php echo urlencode($product_title); ?>&url=<?php echo urlencode($product_url); ?>" target="_blank">
									<i class="fa-brands fa-x-twitter"></i>
								</a>
							</li>
							<li>
								<a href="https://api.whatsapp.com/send?text=<?php echo urlencode($product_title . ' ' . $product_url); ?>" target="_blank">
									<i class="fa-brands fa-whatsapp"></i>
								</a>
							</li>
							<li>
								<button data-copy-url="<?php echo get_the_permalink(); ?>" class="copy_url_button">
									<i class="fa-solid fa-copy"></i>
								</button>
							</li>
						</ul>
						<div class="product__shipping-content">
							<p><span><i class="fa fa-truck"></i></span> Free shipping</p>
							<p><span><i class="fa fa-undo"></i></span> Shop worry-free with our easy return policy</p>
							<p><span><i class="fa fa-credit-card"></i></span> Check out easily with our multiple payment options</p>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="product_details_tab_content">
	<div class="container">
		<?php
		/**
		 * Hook: woocommerce_after_single_product_summary.
		 *
		 * @hooked woocommerce_output_product_data_tabs - 10
		 * @hooked woocommerce_upsell_display - 15
		 * @hooked woocommerce_output_related_products - 20
		 */
		do_action('woocommerce_after_single_product_summary');
		?>
	</div>
</section>

<?php do_action('woocommerce_after_single_product'); ?>