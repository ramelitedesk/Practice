<?php

/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 8.6.0
 */

defined('ABSPATH') || exit;

get_header('shop');

/**
 * Hook: woocommerce_before_main_content.
 *
 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
 * @hooked woocommerce_breadcrumb - 20
 * @hooked WC_Structured_Data::generate_website_data() - 30
 */
remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
do_action('woocommerce_before_main_content');
?>
<section class="site__inner-banner custom-pad-braedcrumb">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="drive__inner-breadcrumb">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo site_url(); ?>"><i class="fa-solid fa-house-chimney"></i></a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">Shop</li>
						</ol>
					</nav>
				</div>
				<div class="drive__heading">
					<h2>Shop</h2>
				</div>
			</div>
		</div>
	</div>
</section>
<?php
/**
 * Hook: woocommerce_shop_loop_header.
 *
 * @since 8.6.0
 *
 * @hooked woocommerce_product_taxonomy_archive_header - 10
 */
remove_action('woocommerce_shop_loop_header', 'woocommerce_product_taxonomy_archive_header', 10);
do_action('woocommerce_shop_loop_header');
?>
<section class="hod_product_section custom-pad pt-0">
	<div class="container">
		<div class="row">
			<div class="col-lg-3">
				<div class="accordion accordion-flush" id="shopFilterAccordion">
					<div class="trex__shop-filter-box accordion-item">
						<div class="tab_listing">
							<div class="accordion-header tab_listing_items" id="shopFilterBox-1">
								<button class="trex__shop-filter-button accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#shopFilterCollapse-1" aria-expanded="true" aria-controls="shopFilterCollapse-1">

									segment
								</button>
							</div>
						</div>
						<div id="shopFilterCollapse-1" class="trex__shop-filter-collapse accordion-collapse" aria-labelledby="shopFilterBox-1" data-bs-parent="#shopFilterAccordion">
							<div class="filter_list">
								<ul class="el__shop-filter-list" id="parent_category_list">
									<?php
									$Product_Categories = get_terms([
										'taxonomy'   => 'product_cat',
										'hide_empty' => false,
										'parent'     => 0, // Fetch only parent categories first
									]);
									if (!empty($Product_Categories) && !is_wp_error($Product_Categories)) :
										foreach ($Product_Categories as $parent_category) :
											$parent_category_name  = $parent_category->name;
											$parent_category_slug  = $parent_category->slug;
											$parent_category_count = $parent_category->count;
											$parent_category_id = $parent_category->term_id;
									?>
											<li>
												<label for="<?php echo esc_attr($parent_category_slug); ?>">
													<input type="checkbox" data-parent_cat_slug="<?php echo esc_attr($parent_category_slug); ?>" id="<?php echo esc_attr($parent_category_slug); ?>" value="<?php echo esc_attr($parent_category_slug); ?>">
													<?php echo esc_html($parent_category_name); ?> <span>(<?php echo $parent_category_count; ?>)</span>
												</label>
											</li>
									<?php
										endforeach;
									endif;
									?>
								</ul>


							</div>
						</div>
					</div>

					<div class="trex__shop-filter-box">
						<div class="tab_listing">
							<div class="accordion-header tab_listing_items" id="shopFilterBox-3">
								<button class="trex__shop-filter-button accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#shopFilterCollapse-3" aria-expanded="false" aria-controls="shopFilterCollapse-3">
									Categories
								</button>
							</div>
						</div>
						<div id="shopFilterCollapse-3" class="trex__shop-filter-collapse" aria-labelledby="shopFilterBox-3" data-bs-parent="#shopFilterAccordion">
							<div class="filter_list">
								<ul class="el__shop-filter-list" id="child_category_list">
									<?php
									if (!empty($Product_Categories) && !is_wp_error($Product_Categories)) :
										foreach ($Product_Categories as $Parent_Category) :
											$Child_Categories = get_terms([
												'taxonomy'   => 'product_cat',
												'hide_empty' => false,
												'parent'     => $Parent_Category->term_id,
											]);

											if (!empty($Child_Categories) && !is_wp_error($Child_Categories)) :
												foreach ($Child_Categories as $Product_Category) :
													$category_name = $Product_Category->name;
													$category_slug = $Product_Category->slug;
													$product_count = $Product_Category->count;
									?>
													<li>
														<label for="<?php echo esc_attr($category_slug); ?>">
															<input type="checkbox" id="<?php echo esc_attr($category_slug); ?>" value="<?php echo esc_attr($category_slug); ?>">
															<?php echo esc_html($category_name); ?> <span>(<?php echo $product_count; ?>)</span>
														</label>
													</li>
									<?php
												endforeach;
											endif;
										endforeach;
									endif;
									?>
								</ul>

							</div>
						</div>
					</div>

				</div>
			</div>
			<div class="col-lg-9">
				<div class="row">
					<div class="showing_count_filter_row">
						<?php
						if (woocommerce_product_loop()) {
							woocommerce_product_loop_start();
							/**
							 * Hook: woocommerce_before_shop_loop.
							 *
							 * @hooked woocommerce_output_all_notices - 10
							 * @hooked woocommerce_result_count - 20
							 * @hooked woocommerce_catalog_ordering - 30
							 */
							do_action('woocommerce_before_shop_loop');
						?>
					</div>
					<div class="showing_filter_active">
						<ul id="selectedFilters">

						</ul>
					</div>
				</div>
							
					<div class="row gy-4 product_box_full_list" id="product_list_in_id">
						

						<?php

								if (wc_get_loop_prop('total')) {
									while (have_posts()) {
										the_post();

										/**
										 * Hook: woocommerce_shop_loop.
										 */
										do_action('woocommerce_shop_loop');

										wc_get_template_part('content', 'product');
									}
								}

								woocommerce_product_loop_end();
						?>

						
					</div>
					<div class="theme_pagination_more_wrapper">
						<nav class="woocommerce-pagination pagination" aria-label="Product Pagination">

						<?php
								/**
								 * Hook: woocommerce_after_shop_loop.
								 *
								 * @hooked woocommerce_pagination - 10
								 */

								do_action('woocommerce_after_shop_loop');
							} else {
								/**
								 * Hook: woocommerce_no_products_found.
								 *
								 * @hooked wc_no_products_found - 10
								 */
								do_action('woocommerce_no_products_found');
							};
						?>


						</nav>
					</div>

				<?php

							do_action('woocommerce_after_main_content');
					?>
			</div>
		</div>
	</div>
</section>


<?php
/**
 * Hook: woocommerce_sidebar.
 *
 * @hooked woocommerce_get_sidebar - 10
 */
remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);
do_action('woocommerce_sidebar');
?>

<?php
get_footer('shop');
