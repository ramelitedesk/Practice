<?php
/*Template Name:about */
get_header();
?>
<section class="site__inner-banner custom-pad-braedcrumb">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="drive__inner-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo esc_url(home_url('/')); ?>"><i
                                        class="fa-solid fa-house-chimney"></i></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page"><a
                                    href="#"><?php echo esc_html(get_the_title()); ?></a></li>
                        </ol>
                    </nav>
                </div>
                <div class="drive__heading">
                    <h2><?php echo esc_html(get_the_title()); ?></h2>
                </div>
            </div>
        </div>
    </div>

</section>
<section class="site__inner-about custom-pad pt-0">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="drive__about-wrapper site__inner-banner-wrap">
                    <div class="drive__content">
                        <?php the_content(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="about__team custom-pad pt-0">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="drive__heading text-center">
                    <h2><?php echo esc_html(get_field('section_heading')); ?></h2>
                </div>
            </div>
            <div class="col-lg-12">
                <?php
                $t = get_field('team_card');
                if (is_array($t)):
                    ?>
                    <div class="about__team-wrapper">
                        <div class="row gy-4">
                            <?php foreach ($t as $tt): ?>
                                <?php if (is_array($tt)): ?>
                                    <?php
                                    $i = isset($tt['image']) ? $tt['image'] : array();
                                    $n = isset($tt['name']) ? $tt['name'] : array();
                                    $p = isset($tt['position']) ? $tt['position'] : array();
                                    $d = isset($tt['description']) ? $tt['description'] : array();
                                    ?>
                                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                                        <div class="about__team-single">
                                            <?php if (is_array($i) && !empty($i['url'])): ?>
                                                <div class="drive-img">
                                                    <img src="<?php echo esc_url($i['url']); ?>"
                                                        alt="<?php echo esc_attr($i['alt']); ?>">
                                                </div>
                                            <?php endif; ?>
                                            <div class="drive__content text-center">
                                                <?php if (!empty($n)): ?>
                                                    <h5><?php echo esc_html($n); ?></h5>
                                                <?php endif; ?>
                                                <?php if (!empty($p)): ?>
                                                    <h6><?php echo esc_html($p); ?></h6>
                                                <?php endif; ?>
                                                <?php if (!empty($d)): ?>
                                                    <p><?php echo esc_html($d); ?></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>