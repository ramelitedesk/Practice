<?php
/*Template Name:contact */
get_header();
?>
<section class="site__inner-banner custom-pad-braedcrumb">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="drive__inner-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo esc_html(home_url('/')); ?>"><i
                                        class="fa-solid fa-house-chimney"></i></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page"><a
                                    href="#"><?php echo esc_html(get_the_title()); ?></a></li>
                        </ol>
                    </nav>
                </div>
                <div class="drive__heading">
                    <h2><?php echo esc_html(get_the_title()); ?></h2>
                </div>
            </div>

        </div>
    </div>
</section>
<section class="site__inner-contact custom-pad pt-0">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="drive__contact-wrapper site__inner-banner-wrap">
                    <div class="drive__content">
                        <?php the_content(); ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>