<?php
/*Template Name:track-order */
get_header();
?>
<section class="site__inner-banner  custom-pad-braedcrumb">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="drive__inner-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo esc_html(home_url('/')); ?>"><i
                                        class="fa-solid fa-house-chimney"></i></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page"><a href="#">Track Order </a></li>
                        </ol>
                    </nav>
                </div>
                <div class="drive__heading">
                    <h2><?php echo esc_html(get_the_title()); ?> </h2>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<section class="site__inner-track custom-pad pt-0">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-8 col-12 mx-auto">
                <div class="drive__track-wrapper">
                    <p>Enter the Order No./Mobile No. associated with your account/order. </p>
                    <form id="" class="drive__register-form">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="first_name"> <span>*</span> Order No./Mobile No.</label>
                                    <input type="text" class="form-control" name="mobile_no" id="mobile_no"
                                        placeholder="Order No./Mobile No.">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-button">
                                    <a href="#" class="custom-button" type="button" value="Continue"> Continue</a>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-button ">
                                    <a href="<?php echo esc_url(home_url('/')); ?>" class="back-button" type="button"> <i
                                            class="fa fa fa-angle-left"></i> Back</a>
                                </div>
                            </div>
                        </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>