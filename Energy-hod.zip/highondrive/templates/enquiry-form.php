<?php
/*Template Name:enquiry-form */
get_header();
?>
<section class="site__inner-banner custom-pad-braedcrumb">
    <div class="site__inner-banner-wrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="drive__inner-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo esc_html(home_url('/')); ?>"><i
                                            class="fa-solid fa-house-chimney"></i></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page"><a
                                        href="#"><?php echo esc_html(get_field('enquiry_form_heading')); ?> </a></li>
                                <!-- <li class="breadcrumb-item active" aria-current="page"><a href="#">Distributors</a> -->
                                <!-- </li> -->
                            </ol>
                        </nav>
                    </div>
                    <?php
                    $eh = get_field('enquiry_form_heading');
                    if (!empty($eh)):
                        ?>
                        <div class="drive__heading">
                            <h2><?php echo esc_html($eh); ?></h2>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="enquiry-form-sec custom-pad pt-0">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="enquiry-distuibutor-wrapper">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="enquiry-distuibutor-left">
                                <?php
                                $i = get_field('enquiry_form_image');
                                if (is_array($i) && !empty($i['url'])):
                                    ?>
                                    <div class="drive__img">
                                        <img src="<?php echo esc_url($i['url']); ?>"
                                            alt="<?php echo esc_attr($i['alt']); ?>">
                                    </div>
                                <?php endif; ?>
                                <div class="drive__content text-center">
                                    <h2><?php echo esc_html(get_field('image_title')); ?></h2>
                                    <p><?php echo esc_html(get_field('image_text')); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="enquiry-distuibutor-right">
                                <div class="drive__heading">
                                    <h3><?php echo esc_html(get_field('form_title')); ?></h3>
                                    <p><?php echo esc_html(get_field('form_text')); ?></p>
                                </div>
                                <?php echo get_field('form_shortcode'); ?>
                                <p><?php echo esc_html(get_field('thank_you_texts')); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>