<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package highondrive
 */

?>

<footer class="site__footer custom-pad pb-0">
	<div class="container">
		<div class="col-lg-12">
			<div class="footer-top">
				<div class="row gy-4">
					<div class="col-lg-4 col-md-12 col-12">
						<div class="footer-col">
							<?php
							$fl = get_field('footer_logo', 'option');
							if (!empty($fl)):
							?>
								<a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url($fl); ?>"
										alt="..."></a>
							<?php endif; ?>
							<?php
							$ft = get_field('footer_texts', 'option');
							if (!empty($ft)):
							?>
								<div class="drive__content">
									<p><?php echo esc_html($ft); ?></p>
								</div>
							<?php endif; ?>

							<?php
							$si = get_field('social_icons', 'option');
							if (is_array($si)):
							?>
								<ul class="socials">
									<?php foreach ($si as $sii): ?>
										<?php if (is_array($sii)): ?>
											<?php
											$li = isset($sii['icons']) ? $sii['icons'] : array();
											?>
											<li>
												<?php if (is_array($li) && !empty($li['title'])): ?>
													<a href="<?php echo esc_url($li['url']); ?>"><i
															class="<?php echo esc_attr($li['title']); ?>"></i></a>
												<?php endif; ?>
											</li>
										<?php endif; ?>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>
						</div>
					</div>
					<div class="col-lg-3 col-md-5 col-sm-5 col-7">
						<div class="site__footer-col">
							<?php
							$csh = get_field('customer_service_heading', 'option');
							if (!empty($csh)):
							?>
								<div class="site__footer-heading">
									<h4><?php echo esc_html($csh); ?> </h4>
								</div>
							<?php endif; ?>
							<?php
							$m = get_field('menus', 'option');
							if (is_array($m)):
							?>
								<div class="site__footer-content">
									<ul class="site__footer-list">
										<?php foreach ($m as $mm): ?>
											<?php if (is_array($mm)): ?>
												<?php
												$mi = isset($mm['menu_items']) ? $mm['menu_items'] : array();
												?>
												<li>
													<?php if (is_array($mi) && !empty($mi['title'])): ?>
														<a class="site__footer-link"
															href="<?php echo esc_url($mi['url']); ?>"><?php echo esc_html($mi['title']); ?></a>
													<?php endif; ?>
												</li>
											<?php endif; ?>
										<?php endforeach; ?>
									</ul>
								</div>
							<?php endif; ?>
						</div>
					</div>
					<div class="col-lg-2 col-md-3 col-sm-3 col-5">
						<div class="site__footer-col">
							<?php
							$qsh = get_field('quick_link_heading', 'option');
							if (!empty($qsh)):
							?>
								<div class="site__footer-heading">
									<h4><?php echo esc_html($qsh); ?> </h4>
								</div>
							<?php endif; ?>
							<?php
							$l = get_field('links', 'option');
							if (is_array($l)):
							?>
								<div class="site__footer-content">
									<ul class="site__footer-list">
										<?php foreach ($l as $ll): ?>
											<?php if (is_array($ll)): ?>
												<?php
												$pl = isset($ll['page_links']) ? $ll['page_links'] : array();
												?>
												<li>
													<?php if (is_array($pl) && !empty($pl['title'])): ?>
														<a class="site__footer-link"
															href="<?php echo esc_url($pl['url']); ?>"><?php echo esc_html($pl['title']); ?></a>
													<?php endif; ?>
												</li>
											<?php endif; ?>
										<?php endforeach; ?>
									</ul>
								</div>
							<?php endif; ?>
						</div>
					</div>
					<div class="col-lg-3 col-md-4 col-sm-4 col-6">
						<div class="site__footer-col">
							<?php
							$coh = get_field('contact_heading', 'option');
							if (!empty($coh)):
							?>
								<div class="site__footer-heading">
									<h4><?php echo esc_html($coh); ?> </h4>
								</div>
							<?php endif; ?>
							<?php
							$cl = get_field('contact_links', 'option');
							if (is_array($cl)):
							?>
								<div class="site__footer-content">
									<ul class="site__footer-list">
										<?php foreach ($cl as $cll): ?>
											<?php if (is_array($cll)): ?>
												<?php
												$ci = isset($cll['links']) ? $cll['links'] : array();
												$icon = isset($cll['icon']) ? $cll['icon'] : array();												?>
												<li>
													<?php if (is_array($ci) && !empty($ci['title'])): ?>
														<a class="site__footer-link"
															href="<?php echo esc_url($ci['url']); ?>">
															<span>
																<?php echo $icon; ?>
															</span>
															<?php echo esc_html($ci['title']); ?></a>
													<?php endif; ?>
												</li>
											<?php endif; ?>
										<?php endforeach; ?>
									</ul>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-12">
			<div class="footer-bottom">
				<div class="row">
					<div class="col-lg-12">
						<div class="footer-bottom-content">
							<p> <?php echo get_field('copy_right_text', 'option'); ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
</footer>
<script>
	var ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
</script>

<?php wp_footer(); ?>
<script>
	jQuery(document).ready(function() {
		document.querySelector(".copy_url_button").addEventListener("click", function() {
			let copy_url = this.getAttribute('data-copy-url');
			let tempInput = document.createElement("input");
			tempInput.value = copy_url;
			document.body.appendChild(tempInput);
			tempInput.select();
			document.execCommand("copy");
			document.body.removeChild(tempInput);
			console.log("Copied:", copy_url);
		});


		function updateDiscount() {
			let originalPrice = $('.woocommerce-variation-price del .woocommerce-Price-amount bdi').text().replace(/[^0-9.]/g, '');
			let salePrice = $('.woocommerce-variation-price ins .woocommerce-Price-amount bdi').text().replace(/[^0-9.]/g, '');

			if (originalPrice && salePrice) {
				let discount = ((originalPrice - salePrice) / originalPrice) * 100;
				$('.discount-percentage').text('Discount: ' + discount.toFixed(2) + '%');
			} else {
				$('.discount-percentage').text('');
			}
		}

		$(document).on('found_variation', 'form.variations_form', function() {
			updateDiscount();
		});

		updateDiscount(); // Initial check




	})
	// ************************************************* //
	// * +++++++++++ Product Filter Js ++++++++++++ * //
	// ************************************************* //
	jQuery(document).ready(function($) {
		var paged = 1;

		function getSelectedFilters() {
			var categories = [];
			$('.el__shop-filter-list input[type="checkbox"]:checked').each(function() {
				var filterCategory = $(this).closest('.trex__shop-filter-collapse').attr('id');
				if (filterCategory === 'shopFilterCollapse-1' || filterCategory === 'shopFilterCollapse-3') {
					categories.push($(this).val());
				}
			}); 
			return {
				categories: categories,
			};
		}
		function updateProductList(page = 1) {
			var filters = getSelectedFilters();
			$.ajax({
				url: wc_add_to_cart_params.ajax_url,
				type: 'POST',
				data: {
					action: 'filter_products',
					categories: filters.categories,
					paged: page
				},
				beforeSend: function(){
					$('.product_box_full_list').html(`<div id="loaderSpiner">
						<img src="<?php echo get_template_directory_uri() . '/assets/images/loaderImage.gif';?>" alt="">
					</div>`);
				},
				success: function(response) {
					var data = JSON.parse(response);
					$('.product_box_full_list').html(data.products);

					var start = ((page - 1) * data.posts_per_page) + 1;
					var end = Math.min(page * data.posts_per_page, data.result_count);
					$('.woocommerce-result-count').html('Showing ' + start + '–' + end + ' of ' + data.result_count + ' results');

					if (data.max_num_pages > 1) {
						var paginationHtml = '';
						var totalPages = data.max_num_pages;
						var currentPage = paged; // Ensure `paged` is defined


						// Previous Page Arrow
						if (currentPage > 1) {
							paginationHtml += `<li><a href="#" class="pagination-link page-numbers prev-page" data-page="${currentPage - 1}">←</a></li>`;
						}
						let startPage, endPage;
						if (totalPages <= 5) {
							startPage = 1;
							endPage = totalPages;
						} else if (currentPage <= 3) {
							startPage = 1;
							endPage = 5;
						} else if (currentPage >= totalPages - 2) {
							startPage = totalPages - 4;
							endPage = totalPages;
						} else {
							startPage = currentPage - 2;
							endPage = currentPage + 2;
						}
						if (startPage > 1) {
							paginationHtml += `<li><a href="#" class="pagination-link page-numbers" data-page="1">1</a></li>`;
							if (startPage > 2) {
								paginationHtml += `<li><span class="dots">...</span></li>`;
							}
						}

						// Page Numbers Loop
						for (var i = startPage; i <= endPage; i++) {
							paginationHtml += `<li><a href="#" class="pagination-link page-numbers ${i === currentPage ? 'current' : ''}" data-page="${i}">${i}</a></li>`;
						}

						// Last Page with Ellipsis
						if (endPage < totalPages) {
							if (endPage < totalPages - 1) {
								paginationHtml += `<li><span class="dots">...</span></li>`;
							}
							paginationHtml += `<li><a href="#" class="pagination-link page-numbers" data-page="${totalPages}">${totalPages}</a></li>`;
						}

						// Next Page Arrow
						if (currentPage < totalPages) {
							paginationHtml += `<li><a href="#" class="pagination-link page-numbers next-page" data-page="${currentPage + 1}">→</a></li>`;
						}

						$('.pagination').html('<ul class="page-numbers">' + paginationHtml + '</ul>');
					} else {
						$('.pagination').html('');
					}

				},
				error: function(xhr, status, error) {
					console.error('AJAX Error:', status, error);
				}
			});
		}
		$('.el__shop-filter-list li label').on('click', function(event) {
			if ($(event.target).is('input') || $(event.target).is('label')) {
				return;
			}
			var checkbox = $(this).find('input[type="checkbox"]');
			var label = $(this).find('label').text().trim();
			checkbox.prop('checked', !checkbox.prop('checked')).trigger('change');
		});
		$('.el__shop-filter-list input[type="checkbox"]').on('change', function() {
			var checkbox = $(this);
			var label = checkbox.closest('li').find('label').text().trim();
			var value = checkbox.val();
			if (checkbox.is(':checked')) {
				$('#selectedFilters').append(
					'<li data-value="' + value + '">' + label + ' <button class="remove-filter"><i class="fa-solid fa-circle-xmark"></i></button></li>'
				);
			} else {
				$('#selectedFilters li[data-value="' + value + '"]').remove();
			}
			paged = 1;
			updateProductList(paged);
			updateChildCategoryList();
		});
		$('#selectedFilters').on('click', '.remove-filter', function() {
			var value = $(this).parent().data('value');
			$('.el__shop-filter-list input[value="' + value + '"]').prop('checked', false).trigger('change');
			$(this).parent().remove();
			paged = 1;
			updateProductList(paged);
		});
		$('#selectedFilters').on('click', '.remove-filter', function() {
			var value = $(this).parent().data('value');
			$('.el__shop-filter-list input[value="' + value + '"]').prop('checked', false);
			$(this).parent().remove();
			paged = 1;
			updateProductList(paged);
		});
		$(document).on('click', '.pagination-link', function(e) {
			e.preventDefault();
			paged = $(this).data('page');
			updateProductList(paged);
		});
		let ajaxTimeout;
		function updateProductListDebounced(page = 1) {
			clearTimeout(ajaxTimeout);
			ajaxTimeout = setTimeout(() => updateProductList(page), 300);
		}
	});
	jQuery(document.body).trigger('wc_fragment_refresh');
</script>
</body>

</html>