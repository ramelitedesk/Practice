<?php
/**
 * highondrive functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package highondrive
 */

if (!defined('_S_VERSION')) {
	// Replace the version number of the theme on each release.
	define('_S_VERSION', '1.0.0');
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function highondrive_setup()
{
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on highondrive, use a find and replace
	 * to change 'highondrive' to the name of your theme in all the template files.
	 */
	load_theme_textdomain('highondrive', get_template_directory() . '/languages');

	// Add default posts and comments RSS feed links to head.
	add_theme_support('automatic-feed-links');

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support('title-tag');

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support('post-thumbnails');

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__('Primary', 'highondrive'),
		)
	);

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'highondrive_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support('customize-selective-refresh-widgets');

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height' => 250,
			'width' => 250,
			'flex-width' => true,
			'flex-height' => true,
		)
	);
}
add_action('after_setup_theme', 'highondrive_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function highondrive_content_width()
{
	$GLOBALS['content_width'] = apply_filters('highondrive_content_width', 640);
}
add_action('after_setup_theme', 'highondrive_content_width', 0);

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function highondrive_widgets_init()
{
	register_sidebar(
		array(
			'name' => esc_html__('Sidebar', 'highondrive'),
			'id' => 'sidebar-1',
			'description' => esc_html__('Add widgets here.', 'highondrive'),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget' => '</section>',
			'before_title' => '<h2 class="widget-title">',
			'after_title' => '</h2>',
		)
	);
}
add_action('widgets_init', 'highondrive_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function highondrive_scripts()
{
	wp_enqueue_style('highondrive-style', get_stylesheet_uri(), array(), _S_VERSION);
	wp_style_add_data('highondrive-style', 'rtl', 'replace');

	wp_enqueue_script('highondrive-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);

	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}
}
add_action('wp_enqueue_scripts', 'highondrive_scripts');

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
	require get_template_directory() . '/inc/jetpack.php';
}


include get_template_directory() . '/admin/index.php';

function allow_svg_uploads($mimes)
{
	$mimes['svg'] = 'image/svg+xml';
	$mimes['svgz'] = 'image/svg+xml';
	return $mimes;
}
add_filter('upload_mimes', 'allow_svg_uploads');

function year_shortcode() { 
	$year = date('Y');
	return $year;
}
add_shortcode('year', 'year_shortcode');

function fix_svg()
{
	echo '<style type="text/css">
		  .attachment-266x266, .thumbnail img {
			   width: 100% !important;
			   height: auto !important;
		  }
		  </style>';
}
add_action('admin_head', 'fix_svg');


add_filter('wpcf7_form_elements', 'remove_cf7_paragraph_tags_for_location');
function remove_cf7_paragraph_tags_for_location($content)
{
	$content = preg_replace('/<\/?p>\s*(<\/?br\s*\/?>)?/', '', $content);
	$content = preg_replace('/<\/?span[^>]*>/', '', $content);
	$content = preg_replace('/<span(?! class="wpcf7-spinner")[^>]*>/', '', $content);
	return $content;
}

add_filter( 'woocommerce_loop_add_to_cart_link', function( $button, $product, $args ) {
    return str_replace( 'button', 'button custom-button', $button );
}, 10, 3 );

add_filter('woocommerce_order_button_html', 'custom_class_checkout_order_button');
function custom_class_checkout_order_button($button) {
    $button = str_replace('class="button alt', 'class="button alt custom-button', $button);
    return $button;
}       

function custom_product_thumb_slider() {
    global $product;
 
    if (!$product) {
        return;
    }
    $product_id = $product->get_id();
    
    // Get featured image
    $featured_image_id = $product->get_image_id();
    $featured_image = $featured_image_id ? wp_get_attachment_url($featured_image_id) : '';
 
    // Get gallery images
    $attachment_ids = $product->get_gallery_image_ids();
 
    // Combine featured and gallery images
    $image_urls = array();
    if ($featured_image) {
        $image_urls[] = $featured_image;
    }
    foreach ($attachment_ids as $attachment_id) {
        $image_url = wp_get_attachment_url($attachment_id);
        if ($image_url) {
            $image_urls[] = $image_url;
        }
    }
 
    if (empty($image_urls)) {
        return;
    }
    ?>
    <div class="swiper gallery-top-<?php echo $product_id; ?>">
        <div class="swiper-wrapper">
            <?php foreach ($image_urls as $image_url) : ?>
                <div class="swiper-slide">
                    <div class="product-details-img">
                        <a href="<?php echo $product->get_permalink();?>" data-fancybox="gallery-<?php echo $product_id; ?>">
            				<img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($product->get_name()); ?>">
        				</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="swiper gallery-thumbs-<?php echo $product_id; ?>">
        <div class="swiper-wrapper">
            <?php foreach ($image_urls as $image_url) : ?>
                <div class="swiper-slide">
                    <div class="product-thumbs-img">
                        <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($product->get_name()); ?>">
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
 
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var swiperThumbs<?php echo $product_id; ?> = new Swiper(".gallery-thumbs-<?php echo $product_id; ?>", {
                spaceBetween: 5,
                slidesPerView: 5,
                freeMode: true,
                watchSlidesVisibility: true,
                watchSlidesProgress: true,
            });
 
            var swiperTop<?php echo $product_id; ?> = new Swiper(".gallery-top-<?php echo $product_id; ?>", {
                spaceBetween: 5,
               
                thumbs: {
                    swiper: swiperThumbs<?php echo $product_id; ?>
                }
            });
        });
    </script>
    <?php
}
function custom_ajax_cart_count_update() {
    ?>
    <script type="text/javascript">
        jQuery(function($) {
            // Listen for WooCommerce cart updates
            $(document.body).on('updated_wc_div removed_from_cart', function() {
                // Refresh WooCommerce cart fragments
                $.ajax({
                    url: wc_cart_fragments_params.wc_ajax_url.toString().replace('%%endpoint%%', 'get_refreshed_fragments'),
                    type: 'POST',
                    success: function(response) {
                        if (response && response.fragments) {
                            // Update mini-cart content
                            if (response.fragments['div.widget_shopping_cart_content']) {
                                $('.widget_shopping_cart_content').html(response.fragments['div.widget_shopping_cart_content']);
                            }
                            
                            // Update cart count dynamically
                            if (response.fragments['#cart-total']) {
                                $('#cart-total').html(response.fragments['#cart-total']);
                            } else {
                                $('#cart-total').html('0'); // If empty, set count to 0
                            }
                        }
                    }
                });
            });
        });
    </script>
    <?php
}
add_action('wp_footer', 'custom_ajax_cart_count_update', 10);

/* buy now button woocommerce code by WPcookie
 * update: https://redpishi.com/wordpress-tutorials/buy-now-button-woocommerce/
 */
add_action('wp_footer', function() {
    if (!is_admin()) {
        // Change button color from here
        $color = "";
        ?>
        <style>
        a.custom-checkout-btn {
            margin: 0px 5px!important;
        }
        </style>
        <?php
        if ($color != "") {
            ?>
            <style>
            a.custom-checkout-btn {
                background: <?php echo $color; ?>!important;
                transition: 0.4s filter ease;
            }
            a.custom-checkout-btn:hover {
                filter: saturate(2);
            }
            </style>
            <?php
        }
    }
});

add_action('woocommerce_after_add_to_cart_button', 'add_custom_addtocart_and_checkout');
function add_custom_addtocart_and_checkout() {
    global $product;

    // conditional tags
    $condition = $product->is_type('simple') || $product->is_type('variable');

    $button_class = 'single_add_to_cart_button button custom-button alt custom-checkout-btn';

    // Change the text of the buy now button from here
    $button_text = __("Buy now", "woocommerce");

    if ($condition) {
        // For both simple and variable products
        ?>
        <script>
        jQuery(function($) {
            var checkoutUrl = '<?php echo wc_get_checkout_url(); ?>',
                addToCartUrl = '<?php echo wc_get_cart_url(); ?>',
                qty = 'input.qty',
                button = 'a.custom-checkout-btn';

            function updateBuyNowButton() {
                var $form = $('form.cart'),
                    productId = $form.find('input[name="product_id"]').val(),
                    variationId = $form.find('input[name="variation_id"]').val(),
                    quantity = $form.find(qty).val();

                var targetUrl = checkoutUrl + '?add-to-cart=';
                
                if (variationId && variationId != '') {
                    targetUrl += variationId;
                } else {
                    targetUrl += productId;
                }

                targetUrl += '&quantity=' + quantity;

                // Add all selected attributes to the URL
                $form.find('.variations select').each(function() {
                    var attributeName = $(this).attr('name');
                    var attributeValue = $(this).val();
                    if (attributeValue) {
                        targetUrl += '&' + attributeName + '=' + attributeValue;
                    }
                });
                
                $(button).attr('href', targetUrl);
            }

            // Initial update
            updateBuyNowButton();

            // On quantity change
            $(qty).on('input change', updateBuyNowButton);

            // On variation change
            $('.variations_form').on('woocommerce_variation_has_changed', updateBuyNowButton);

            // Ensure button is updated after variation is selected
            $('form.variations_form').on('show_variation', function(event, variation) {
                updateBuyNowButton();
            });

            // Update on any attribute change
            $('.variations_form').on('change', 'select', updateBuyNowButton);

            // Disable the button if not all attributes are selected
            $('.variations_form').on('change', 'select', function() {
                var allSelected = true;
                $('.variations_form select').each(function() {
                    if ($(this).val() === '') {
                        allSelected = false;
                        return false;  // break the loop
                    }
                });
                
                if (allSelected) {
                    $(button).removeClass('disabled').attr('aria-disabled', 'false');
                } else {
                    $(button).addClass('disabled').attr('aria-disabled', 'true');
                }
            });

            // Prevent click if button is disabled
            $(button).on('click', function(e) {
                if ($(this).hasClass('disabled')) {
                    e.preventDefault();
                    alert('Please select all product options before purchasing.');
                }
            });
        });
        </script>
        <?php
        echo '<a href="#" class="' . $button_class . '">' . $button_text . '</a>';
    }
}

add_filter('woocommerce_add_to_cart_fragments', 'custom_refresh_cart_count');

function custom_refresh_cart_count($fragments) {
    ob_start();
    ?>
    <span id="cart-total"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
    <?php
    $fragments['#cart-total'] = ob_get_clean();

    ob_start();
    woocommerce_mini_cart();
    $fragments['div.widget_shopping_cart_content'] = ob_get_clean();

    return $fragments;
}


add_filter( 'loop_shop_per_page', 'custom_products_per_page', 20 );
function custom_products_per_page( $products_per_page ) {
    return 6;   
}

add_action( 'woocommerce_variable_add_to_cart', function() {
    add_action( 'wp_print_footer_scripts', function() {
		$color = "#1c1c1c";
		
        ?>
        <script type="text/javascript">

        // DOM Loaded
        document.addEventListener( 'DOMContentLoaded', function() {

            // Get Variation Pricing Data
            var variations_form = document.querySelector( 'form.variations_form' );
            var data = variations_form.getAttribute( 'data-product_variations' );
            data = JSON.parse( data );

            // Loop Drop Downs
            document.querySelectorAll( 'table.variations select' )
                .forEach( function( select ) {

                // Loop Drop Down Options
                select.querySelectorAll( 'option' )
                    .forEach( function( option ) {

                    // Skip Empty
                    if( ! option.value ) {
                        return;
                    }

                    // Get Pricing For This Option
                    var pricing = '';
                    data.forEach( function( row ) {
                        if( row.attributes[select.name] == option.value ) {
                            pricing = row.price_html;
                        }
                    } );

					 var span = document.createElement( 'span' );

                    // Create Radio
                    var radio = document.createElement( 'input' );
                        radio.type = 'radio';
                        radio.name = select.name;
                        radio.value = option.value;
                        radio.checked = option.selected;
					radio.setAttribute('id',option.value);
                    var label = document.createElement( 'label' );
					     	 label.htmlFor = option.value;
                    	label.appendChild( document.createTextNode( ' ' + option.text + ' ' ) );

					 span.appendChild( radio );
					 span.appendChild( label );


                    // Insert Radio
                    select.closest( 'td' ).appendChild( span );

                    // Handle Clicking
                    radio.addEventListener( 'click', function( event ) {
                        select.value = radio.value;
                        jQuery( select ).trigger( 'change' );
                    } );

                } ); // End Drop Down Options Loop

                // Hide Drop Down
                select.style.display = 'none';

            } ); // End Drop Downs Loop

        } ); // End Document Loaded
        </script>
		<style>
			html {
			--radio-color: <?= $color ?>;	
			}	
			td.value {
				width: 100%;
				height: 100%;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				gap: 10px;
			}


			td.value input[type="radio"] {
				appearance: none;
				display: none;
			}

			td.value label {
				font-size: 1em;
				display: flex;
				justify-content: center;
				align-items: center;
				background-color: inherit;
				text-align: center;
				border-radius: 5px;
				overflow: hidden;
				transition: linear 0.3s;
				color: var(--radio-color);
				padding: 0.3em 0.6em;
				border: 2px solid var(--radio-color);
				cursor: pointer;
			}
			td.value input[type="radio"]:checked + label {
				background-color: var(--radio-color);
				color: #f1f3f5;
				transition: 0.3s;
			}
			a.reset_variations {
				display: none!important;
			}
		</style>
        <?php
    } );
} );


function sale_tag_percentage() {
    global $product;
    if (!$product) return;
    if ($product->is_type('variable')) {
        $default_attributes = $product->get_default_attributes();
        $variations = $product->get_available_variations();
        $default_price = null;

        foreach ($variations as $variation) {
            $variation_product = wc_get_product($variation['variation_id']);
            $matched = true;

            foreach ($default_attributes as $key => $value) {
                if ($variation['attributes']['attribute_' . $key] !== $value) {
                    $matched = false;
                    break;
                }
            }

            if ($matched) {
                $default_price = (float) $variation_product->get_price();
                $regular_price = (float) $variation_product->get_regular_price();
                $sale_price = (float) $variation_product->get_sale_price();
                $discount_percentage = $sale_price && $regular_price > 0
                    ? round((($regular_price - $sale_price) / $regular_price) * 100)
                    : 0;
                break;
            }
        }
    } else {
        $regular_price = (float) $product->get_regular_price();
        $sale_price = (float) $product->get_sale_price();
        $discount_percentage = $sale_price && $regular_price > 0
            ? round((($regular_price - $sale_price) / $regular_price) * 100)
            : 0;
    }
    ?>
	<?php if (!empty($sale_price)): ?>
		<span class="price-discount"><?php echo esc_html($discount_percentage); ?>% Off</span>
	<?php else: ?>
		<span class="price-new">Sale!</span>
	<?php endif; ?>

<?php
}
add_filter( 'woocommerce_sale_flash', 'sale_tag_percentage', 10, 2 );


function custom_variable_product_add_to_cart_button($html, $product) {
    if ($product->is_type('variable')) {
        $variations = $product->get_available_variations();
        if (!empty($variations)) {
            $first_variation = $variations[0];
            $variation_id = $first_variation['variation_id'];

            $html = sprintf(
                '<form action="%s" method="post">
                    <input type="hidden" name="add-to-cart" value="%s">
                    <input type="hidden" name="variation_id" value="%s">
                    <input type="hidden" name="product_id" value="%s">
                    <input type="hidden" name="quantity" value="1">
                    <button type="submit" class="button ajax_add_to_cart custom-button add_to_cart_button" data-product_id="%s">%s</button>
                </form>',
                esc_url(wc_get_cart_url()),
                esc_attr($product->get_id()),
                esc_attr($variation_id),
                esc_attr($product->get_id()),
                esc_attr($product->get_id()),
                esc_html__('Add to Cart', 'woocommerce')
            );
        }
    }
    return $html;
}
add_filter('woocommerce_loop_add_to_cart_link', 'custom_variable_product_add_to_cart_button', 10, 2);



//filter function
add_action('wp_ajax_filter_products', 'filter_products'); 
add_action('wp_ajax_nopriv_filter_products', 'filter_products'); 

function filter_products() {
    $categories = isset($_POST['categories']) ? array_map('sanitize_text_field', $_POST['categories']) : [];

   
    $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1; 

    $args = [
        'post_type' => 'product',
		'post_status' => 'publish',
        'posts_per_page' => 6,
		'orderby'   => 'date',
        'order' => 'DESC',
        'paged' => $paged, 
    ];

    if (!empty($categories)) {
        $args['tax_query'] = ['relation' => 'AND'];

        if (!empty($categories)) {
            $args['tax_query'][] = [
                'taxonomy' => 'product_cat',
                'field' => 'slug',
                'terms' => $categories,
            ];
        }
    }

    $query = new WP_Query($args);
    ob_start();

    if ($query->have_posts()) {
        woocommerce_product_loop_start();
        while ($query->have_posts()) {
            $query->the_post();
			?>
			<div class="col-lg-4">
				<?php wc_get_template_part('content', 'product');?>
			</div>
			<?php
        }
        woocommerce_product_loop_end();
    } else {
        echo '<p>No products found matching your criteria.</p>';
    }

    wp_reset_postdata();

    $product_html = ob_get_clean();

    $response = [
        'products' => $product_html,
        'result_count' => $query->found_posts,
        'max_num_pages' => $query->max_num_pages,
        'posts_per_page' => 6,
        'current_page' => $paged
    ];

    echo json_encode($response);
    wp_die(); 
}

function custom_product_review_shortcode() {
    global $product;
    if ( ! is_a( $product, 'WC_Product' ) || ! wc_review_ratings_enabled() ) {
        return '';
    }
     $rating = $product->get_average_rating();
    $review_count = $product->get_review_count();
    ob_start();
    if ( $rating ) {
        ?>
        <?php
            for ($i = 1; $i <= 5; $i++) {
                if ($i > $rating){
                    echo '<span><i class="fa-regular fa-star"></i></span>';
                    
                }else{
                    echo '<span><i class="fa-solid fa-star"></i></span>';
                }
                
            }
            ?>     
        <?php
    } else {
        ?>
            <?php
            for ($i = 1; $i <= 5; $i++) {
                if ($i > $rating){
                    echo '<span><i class="fa-regular fa-star"></i></span>';
                    
                }else{
                    echo '<span><i class="fa-solid fa-star"></i></span>';
                }
                
            }
            ?>       

        <?php
    }
    return ob_get_clean();
}
add_shortcode('product_review', 'custom_product_review_shortcode');

