jQuery(document).ready(function ($) {
    $("#head-search").autocomplete({
        source: function (e, a) {
            $.ajax({
                url: ajax_object.ajax_url,
                type: "POST",
                data: { action: "get_search_suggestions", term: e.term },
                success: function (e) {
                    var a = JSON.parse(e),
                        t = "";
                    c = "";
                    if (a.product.length > 0) {
                        c += '<h3>Products</h3>';
                        a.product.forEach(function (s) {
                            (c += '<div class="suggestion-item" data-url="' + s.url + '">'),
                                (c += '<img src="' + s.image + '" alt="' + s.label + '" class="suggestion-image" />'),
                                (c += '<span class="suggestion-label">' + s.label + "</span>"),
                                (c += "</div>");
                        });
                    }

                    if (a.post.length > 0) {
                        t += '<h3>Blogs</h3>';
                        a.post.forEach(function (s) {
                            (t += '<div class="suggestion-item" data-url="' + s.url + '">'),
                                (t += '<img src="' + s.image + '" alt="' + s.label + '" class="suggestion-image" />'),
                                (t += '<span class="suggestion-label">' + s.label + "</span>"),
                                (t += "</div>");
                        });
                    }
                    $(".search-suggestions").html(
                        (c ? '<div class="cat-suggestions">' + c + '</div>' : '') +
                        (t ? '<div class="product-suggestions">' + t + '</div>' : '')
                    );
                    $(".suggestion-item").on("click", function () {
                        window.location.href = $(this).data("url");
                    });

                },
            });
        },
        minLength: 3,
    }),
        $("#head-search").on("input", function () {
            "" === jQuery.trim($("#head-search").val()) && $(".search-suggestions").empty();
        });
});