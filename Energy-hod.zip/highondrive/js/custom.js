// fixed header

jQuery(document).ready(function ($){
  $(window).on('scroll', function () {
    if ($(this).scrollTop() > 250) {
      $(".site__header").addClass("fixed__header");
    } else {
      $(".site__header").removeClass("fixed__header");
    }
  });
});


var bannerswiper = new Swiper(".site__banner-swiper", {
  slidesPerView: 1,
  spaceBetween: 30,
  loop: true,
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  }
});

var productSwiper = new Swiper(".drive__product-swiper", {
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev"
    },
    autoPlay: false,
    spaceBetween: 60,
    loop: true,
    autoplay: {
      delay: 3000,
    },
    pagination: {
      el: ".swiper-pagination",
      dynamicBullets: true,
    },
    breakpoints: {
      0: {
        slidesPerView: 1
      },
      1024: {
        slidesPerView: 4

      },
      576: {
        slidesPerView: 2

      }
    }
  });

var related_product_slider = new Swiper(".related_product_slider", {
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev"
    },
    autoPlay: false,
    spaceBetween: 60,
    loop: true,
    autoplay: {
      delay: 3000,
    },
    pagination: {
      el: ".swiper-pagination",
      dynamicBullets: true,
    },
    breakpoints: {
      0: {
        slidesPerView: 1
      },
      1024: {
        slidesPerView: 4

      },
      576: {
        slidesPerView: 2

      }
    }
  });

  var productSwiper = new Swiper(".client__testimonial-swiper", {
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev"
    },
    autoPlay: false,
    spaceBetween: 60,
    loop: true,
    autoplay: {
      delay: 3000,
    },
    pagination: {
      el: ".swiper-pagination",
      dynamicBullets: true,
    },
    breakpoints: {
      0: {
        slidesPerView: 1
      },
      1024: {
        slidesPerView: 3

      }, 
      768: {
        slidesPerView: 2

      },
      576:{
        slidesPerView: 1
      }
    }
  });
