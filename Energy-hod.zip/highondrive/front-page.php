<?php
get_header();
?>
<?php
$b = get_field('banner_options');
if (is_array($b)):
    ?>
    <section class="site__banner">
        <div class="container-fluid px-0 ">
            <div class="row gx-0">
                <div class="col-lg-12">
                    <div class="site__banner-wrapper">
                        <div class="swiper site__banner-swiper">
                            <div class="swiper-wrapper">
                                <?php foreach ($b as $bb): ?>
                                    <?php if (is_array($bb)): ?>
                                        <?php
                                        $i = isset($bb['image']) ? $bb['image'] : array();
                                        if (is_array($i)):
                                            ?>
                                            <div class="swiper-slide">
                                                <?php if (!empty($i['url'])): ?>
                                                    <div class="site__banner-img">
                                                        <img src="<?php echo esc_url($i['url']); ?>"
                                                            alt="<?php echo esc_attr($i['title']); ?>">
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            <div class="swiper-pagination"></div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$p = get_field('product_options');
$bh = isset($p['best_seller_heading']) ? $p['best_seller_heading'] : array();
$bs = isset($p['best_seller_products_slider']) ? $p['best_seller_products_slider'] : array();
$mv = isset($p['most_viewed_products_slider']) ? $p['most_viewed_products_slider'] : array();
$mh = isset($p['most_viewed_product_heading']) ? $p['most_viewed_product_heading'] : array();
$os = isset($p['on_sale_products_slider']) ? $p['on_sale_products_slider'] : array();
$oh = isset($p['on_sale_product_heading']) ? $p['on_sale_product_heading'] : array();
?>
<section class="product__seller-sec custom-pad pb-0">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="drive__heading">
                    <h2><span><?php echo esc_html($bh[0]['heading']); ?>
                        </span><?php echo esc_html($bh[1]['heading']); ?></h2>
                </div>
            </div>
            <?php
            product_slider($bs);
            ?>
        </div>
    </div>
</section>
<?php
$c = get_field('category_options');
if ($c):
    ?>
    <section class="product__category custom-pad pb-0">
        <div class="container-fluid">
            <div class="row gy-4">
                <?php foreach ($c as $cc): ?>
                    <?php if (is_object($cc)): ?>
                        <?php
                        $csl = $cc->slug;
                        $cnm = $cc->name;
                        $tid = get_term_meta($cc->term_id, 'thumbnail_id', true);
                        $iu = wp_get_attachment_url($tid);
                        $iid = attachment_url_to_postid($iu);
                        if ($iid):
                            $alt = get_post_meta($iid, '_wp_attachment_image_alt', true);
                            $t = get_the_title($iid);
                        endif;
                        ?>
                        <div class="col-lg-4 col-md-4 col-6">
                            <div class="product__category-single">
                                <div class="product__category-img">
                                    <a href="<?php echo esc_url(get_term_link($cc->term_id)); ?>"> <img
                                            src="<?php echo esc_url($iu); ?>" title="<?php echo esc_attr($t); ?>"
                                            alt="<?php echo esc_attr($alt); ?>"></a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<?php endif; ?>
<section class="product__view-sec custom-pad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="col-lg-12">
                    <div class="drive__heading">
                        <h2><span><?php echo esc_html($mh[0]['heading']); ?>
                            </span><?php echo esc_html($mh[1]['heading']); ?></h2>
                    </div>
                </div>
            </div>

            <?php
            product_slider($mv);
            ?>
        </div>
    </div>
</section>
<?php
$cnt = get_field('counter_options');
if (is_array($cnt)):
    ?>
    <section class="drive__counter-sec custom-pad">
        <div class="container">
            <div class="row  align-items-center gy-4">
                <?php foreach ($cnt as $cntt): ?>
                    <?php
                    if (is_array($cntt)):
                        $ic = isset($cntt['icon']) ? $cntt['icon'] : '';
                        $t = isset($cntt['title']) ? $cntt['title'] : '';
                        $e = isset($cntt['text']) ? $cntt['text'] : '';
                        ?>
                        <div class="col-lg-4 col-md-4 col-sm-6 col-12 text-center">
                            <div class="drive__counter-wrap">
                                <?php if (!empty($ic)): ?>
                                    <div class="drive__counter-img">
                                        <span> <img class="img-fluid" src="<?php echo esc_url($ic); ?>" alt="...">
                                        </span>
                                    </div>
                                <?php endif; ?>
                                <div class="drive-content">
                                    <h3><?php echo esc_html($t); ?></h3>
                                    <p><?php echo esc_html($e); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<?php endif; ?>
<section class="product__sale-sec custom-pad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="drive__heading">
                    <h2><span><?php echo esc_html($oh[0]['heading']); ?>
                        </span><?php echo esc_html($oh[1]['heading']); ?></h2>
                </div>
            </div>
            <?php
            product_slider($os);
            ?>
        </div>
    </div>
</section>
<?php
$cg = get_field('company_logos');
if (is_array($cg)):
    ?>
    <section class="drive__logo-sec custom-pad">
        <div class="container">
            <div class="row gy-4">
                <?php foreach ($cg as $cgg): ?>
                    <?php
                    if (is_array($cgg)):
                        ?>
                        <div class="col-md-3 col-sm-3 col-6">
                            <?php if (!empty($cgg['url'])): ?>
                                <div class="drive__logo-wrap">
                                    <div class="drive__logo-img">
                                        <a href="#url"><img src="<?php echo esc_url($cgg['url']); ?>" alt="..."></a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$cta = get_field('cta_options');
if (is_array($cta)):
    ?>
    <section class="drive__cta  ">
        <div class="container-fluid px-0">
            <div class="row">
                <div class="col-md-12">
                    <div class="drive__cta-wrap">
                        <?php if (!empty($cta['url'])): ?>
                            <div class="drive__cta-img">
                                <a href="#"><img src="<?php echo esc_url($cta['url']); ?>" alt="..."></a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
$cth = get_field('testimonial_heading');
$tc = get_field('testimonial_cards');
?>
<section class="drive__testimonial custom-pad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="drive__heading">
                    <h2><?php echo esc_html($cth); ?></h2>
                    <!-- <h2><span> Client </span>Testimonials</h2> -->
                </div>
            </div>
            <div class="col-lg-12">
                <?php if (is_array($tc)): ?>
                    <div class="client__testimonial-wrapper">
                        <div class="swiper client__testimonial-swiper">
                            <div class="swiper-wrapper">
                                <?php foreach ($tc as $tcc): ?>
                                    <?php
                                    if (is_array($tcc)):
                                        $d = isset($tcc['description']) ? $tcc['description'] : '';
                                        $t = isset($tcc['title']) ? $tcc['title'] : '';
                                        $i = isset($tcc['image']) ? $tcc['image'] : '';
                                        ?>
                                        <div class="swiper-slide">
                                            <div class="testimonial__wrap">
                                                <?php if (!empty($d)): ?>
                                                    <div class="drive-content">
                                                        <p><?php echo esc_html($d); ?></p>
                                                    </div>
                                                <?php endif; ?>
                                                <div class="testimonia-name">
                                                    <?php if (!empty($i)): ?>
                                                        <div class="testimonial-img">
                                                            <img src="<?php echo esc_html($i); ?>" alt="...">
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if (!empty($t)): ?>
                                                        <div class="drive-content">
                                                            <h6><?php echo esc_html($t); ?></h6>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>

                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            <div class="swiper-button-prev swiper-button-prev1"><i class="fa-solid fa-chevron-left"></i>
                            </div>
                            <div class="swiper-button-next swiper-button-next1"><i class="fa-solid fa-chevron-right"></i>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php
$k = get_field('key_features');
if (is_array($k)):
    ?>
    <section class="drive__social-sec  ">
        <div class="container">
            <div class="row gy-4">
                <?php foreach ($k as $kk): ?>
                    <?php if (is_array($kk)): ?>
                        <?php
                        $i = isset($kk['icon']) ? $kk['icon'] : '';
                        $t = isset($kk['title']) ? $kk['title'] : '';
                        ?>
                        <div class="col-md-4 col-sm-4 col-12">
                            <div class="drive__deelevry-wrap">
                                <?php if (!empty($i)): ?>
                                    <div class="drive__deelevry-img">
                                        <img src="<?php echo esc_url($i); ?>" alt="....">
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($t)): ?>
                                    <div class="drive__content">
                                        <h6><?php echo esc_html($t); ?></h6>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php
get_footer();
?>