<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package highondrive
 */

get_header();
?>
<section class="site__inner-banner custom-pad-braedcrumb">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="drive__inner-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo site_url();?>"><i class="fa-solid fa-house-chimney"></i></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page"><a href="#">Blog</a></li>
                        </ol>
                    </nav>
                </div>
                <div class="drive__heading">
                    <h1>Blog</h1>
                </div>
            </div>

        </div>
    </div>
</section>
<section class="site__inner-blog custom-pad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="blog__inner-wrapper">
                    <div class="row gy-4">
                        <?php

                        $ar = array(
                            'post_type' => 'post',
                            'post_status' => 'publish',
                            'posts_per_page' => 9,
                            'order' => 'DESC',
                            'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
                        );

                        $q = new WP_Query($ar);

                        if ($q->have_posts()):
                            while ($q->have_posts()):
                                $q->the_post();
                                ?>
                                <?php
                                $id = get_the_ID();
                                $tid = get_post_thumbnail_id();
                                $ua = wp_get_attachment_image_src($tid, 'thumbnail-size', true);
                                $img = $ua[0];
                                $alt = get_post_meta($tid, '_wp_attachment_image_alt', true);
                                $it = get_the_title($tid);
                                ?>
                                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                    <div class="blog__inner-single">
                                        <div class="drive-img">
                                            <a href="<?php echo esc_url(get_the_permalink()); ?>"><img
                                                    src="<?php echo $img; ?>"></a>
                                        </div>
                                        <div class="drive-content">
                                            <h5><?php the_title(); ?></h5>
                                        </div>
                                        <a href="<?php echo esc_url(get_the_permalink()); ?>" class="blog-button"> Read
                                            More<span><i class="fa-solid fa-chevron-right"></i></span> </a>
                                    </div>
                                </div>
                                <?php
                            endwhile;
                        endif;
                        ?>
                        <div class="pagination">
                            <ul class="blog-pagination">
                                <li>
                                    <?php
                                    echo paginate_links(array(
                                        'total' => $q->max_num_pages,
                                        'current' => max(1, $q->get('paged')),
                                        'format' => '?paged=%#%',
                                        'prev_text' => '&laquo;',
                                        'next_text' => '&raquo;',
                                    ));
                                    ?>
                                </li>
                            </ul>
                        </div>
                        <?php
                        wp_reset_postdata();

                        ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<?php
get_footer();
