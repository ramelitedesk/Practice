<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package highondrive
 */

get_header();
?>
	<section class="site__inner-banner custom-pad-braedcrumb">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="drive__inner-breadcrumb">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo site_url();?>"><i class="fa-solid fa-house-chimney"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page"><a href="#"><?php echo get_the_title();?></a></li>
							</ol>
						</nav>
					</div>
					<div class="drive__heading">
						<h1><?php echo get_the_title();?></h1>
					</div>
				</div>

			</div>
		</div>
	</section>
	<section class="common_woo_section custom-pad pt-0">
		<div class="container">
			<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content', 'page' );
				endwhile;
			?>
		</div>
	</section>

<?php
get_footer();
