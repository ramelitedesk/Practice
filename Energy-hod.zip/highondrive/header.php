<?php

/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package highondrive
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>
	<header class="site__header">
		<div class="header__top">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-lg-12 d-lg-block d-md-block d-sm-none d-none">
						<nav class="navbar navbar-expand site__header-top-wrap justify-content-between">
							<?php
							$hl = get_field('header_logo', 'option');
							if (!empty($hl)):
							?>
								<div class="header__logo">
									<a href="<?php echo esc_url(home_url('/')); ?>" class="">
										<img src="<?php echo esc_url($hl); ?>" alt="....">
									</a>
								</div>
							<?php endif; ?>
							<div class="header__top-right d-flex  ">
								<div class="drive-search  ">
									<form class="drive_search-box" id="drive-search-form">
										<input class="ui-autocomplete-input form-control" type="search" id="head-search" name="search"
											placeholder="Search " autocomplete="off">
										<div class="search-suggestions"></div>
										<button class="search-btn" type="submit">
											<span><i class="fa-solid fa-magnifying-glass"></i></span>
										</button>
									</form>
								</div>
								<div class="drive__header-item">
									<ul>

										<li><?php echo do_shortcode('[wlfmc_wishlist_counter]');?></li>
										<?php
										$cnt = WC()->cart->get_cart_contents_count();
										?>


										<li class="ajax_cart_update_count"><a href="<?php echo esc_url(wc_get_cart_url()); ?>" id="cart_update_count"><span><img
														src="<?php echo get_template_directory_uri() ?>/assets/images/header-icon2.svg"
														alt="">
												</span>

												<i class="cart-count"><span id="cart-total"><?php echo WC()->cart->get_cart_contents_count(); ?></span></i>

											</a>
											
										</li>
										<li><a href="<?php echo site_url('my-account');?>"><span><img
														src="<?php echo get_template_directory_uri() ?>/assets/images/header-icon3.svg"
														alt="">
												</span></a></li>
									</ul>
								</div>
								<button class="navbar-toggler collapsed" type="button" data-bs-toggle="offcanvas"
									data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2"
									aria-expanded="false" aria-label="Toggle navigation">
									<span class="navbar-toggler-icon"></span>

								</button>
							</div>

						</nav>
					</div>
					<div class="col-lg-12 d-lg-none d-md-none d-sm-block d-block">
						<nav class="navbar navbar-expand site__header-top-wrap justify-content-between">
							<?php
							$hl = get_field('header_logo', 'option');
							if (!empty($hl)):
							?>
								<div class="header__logo">
									<a href="<?php echo esc_url(home_url('/')); ?>" class="">
										<img src="<?php echo esc_url($hl); ?>" alt="....">
									</a>
								</div>
							<?php endif; ?>
							<div class="header__top-right d-flex  ">
								
								<div class="drive__header-item">
									<ul>

										<li><?php echo do_shortcode('[wlfmc_wishlist_counter]');?></li>
										<?php
										$cnt = WC()->cart->get_cart_contents_count();
										?>


										<li class="ajax_cart_update_count"><a href="<?php echo esc_url(wc_get_cart_url()); ?>" id="cart_update_count"><span><img
														src="<?php echo get_template_directory_uri() ?>/assets/images/header-icon2.svg"
														alt="">
												</span>

												<i class="cart-count"><span id="cart-total"><?php echo WC()->cart->get_cart_contents_count(); ?></span></i>

											</a>
											
										</li>
										<li><a href="<?php echo site_url('my-account');?>"><span><img
														src="<?php echo get_template_directory_uri() ?>/assets/images/header-icon3.svg"
														alt="">
												</span></a></li>
									</ul>
								</div>
								<button class="navbar-toggler collapsed" type="button" data-bs-toggle="offcanvas"
									data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2"
									aria-expanded="false" aria-label="Toggle navigation">
									<span class="navbar-toggler-icon"></span>

								</button>
							</div>

						</nav>
						<div class="drive-search  ">
									<form class="drive_search-box" id="drive-search-form">
										<input class="ui-autocomplete-input form-control" type="search" id="head-search" name="search"
											placeholder="Search " autocomplete="off">
										<div class="search-suggestions"></div>
										<button class="search-btn" type="submit">
											<span><i class="fa-solid fa-magnifying-glass"></i></span>
										</button>
									</form>
								</div>
					</div>
				</div>
			</div>
		</div>
		<div class="drive__header-bottom">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="drive__header-bottom-wrap">
							<nav class="navbar navbar-expand-lg " aria-label="Offcanvas navbar large">
								<a class="navbar-brand" href="#">
								</a>
								
								<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar2"
									aria-labelledby="offcanvasNavbar2Label">
									<div class="offcanvas-header">
										<a href="<?php echo esc_url(home_url('/')); ?>"
											class="navbar-brand header__logo">
											<img src="https://kreativemachinez.website/dev/highondrive/wp-content/uploads/2025/03/header-logo.avif"
												alt="....">
										</a>
										<button type="button" class="btn-close " data-bs-dismiss="offcanvas"
											aria-label="Close"></button>
									</div>
									<div class="offcanvas-body">
										<?php
										wp_nav_menu(array(
											'theme_location' => 'primary-menu',
											'menu_class' => 'navbar-nav justify-content-center flex-grow-1',
											'container' => false,
											'walker' => new Custom_Walker_Nav_Menu(),
										));
										?>
									</div>
								</div>
							</nav>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>