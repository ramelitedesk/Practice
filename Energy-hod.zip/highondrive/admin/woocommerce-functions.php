<?php
/* Woocommerce Override */

add_action('after_setup_theme', 'woocommerce_support');
function woocommerce_support()
{
    add_theme_support('woocommerce');
}

// Add Variation Settings
add_action('woocommerce_product_after_variable_attributes', 'ts_variation_settings_fields', 10, 3);

// Save Variation Settings
add_action('woocommerce_save_product_variation', 'ts_save_variation_settings_fields', 10, 2);

/**
 * Create new fields for variations
 */
function ts_variation_settings_fields($loop, $variation_data, $variation)
{
    // Text Field
    woocommerce_wp_text_input(
        array(
            'id' => '_text_field[' . $variation->ID . ']',
            'label' => __('Product Variation Title', 'woocommerce'),
            'placeholder' => '',
            'desc_tip' => 'true',
            'description' => __('Enter the product variation title.', 'woocommerce'),
            'value' => get_post_meta($variation->ID, '_text_field', true)
        )
    );

}

/**
 * Save new fields for variations
 */
function ts_save_variation_settings_fields($post_id)
{
    // Text Field
    $text_field = $_POST['_text_field'][$post_id];
    if (!empty($text_field)) {
        update_post_meta($post_id, '_text_field', esc_attr($text_field));
    }

}

// Add filter to load variation settings fields
add_filter('woocommerce_available_variation', 'ts_load_variation_settings_fields');

/**
 * Load custom fields for variations
 */
function ts_load_variation_settings_fields($variations)
{
    // Text Field
    $variations['text_field'] = get_post_meta($variations['variation_id'], '_text_field', true);

    return $variations;
}



function plt_hide_woocommerce_menus() {

	//Hide "Products → All Products".
	remove_submenu_page('edit-tags.php?post_type=product', 'edit-tags.php?taxonomy=product_brand&post_type=product');

}

add_action('admin_menu', 'plt_hide_woocommerce_menus', 100);