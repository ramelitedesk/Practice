<?php
include get_template_directory() . '/admin/woocommerce-functions.php';
include get_template_directory() . '/admin/generate-sku.php';
include get_template_directory() . '/admin/theme-settings.php';
include get_template_directory() . '/admin/enqueue-css-js.php';
include get_template_directory() . '/admin/nav-menu.php';
include get_template_directory() . '/admin/walker-class.php';
include get_template_directory() . '/admin/product-slider.php';
include get_template_directory() . '/admin/ajax-callback.php';
?>