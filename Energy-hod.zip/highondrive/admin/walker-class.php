<?php

class Custom_Walker_Nav_Menu extends Walker_Nav_Menu
{
    function start_lvl(&$output, $depth = 0, $args = null)
    {
        $indent = str_repeat("\t", $depth);
        $classes = $depth === 0 ? 'dropdown-menu' : 'dropdown-menu sub-dropdown-menu';
        $output .= "\n$indent<ul class='" . esc_attr($classes) . "' aria-labelledby='navbarDropdown' data-bs-popper='static'>\n";
    }

    function end_lvl(&$output, $depth = 0, $args = null)
    {
        $indent = str_repeat("\t", $depth);
        $output .= "$indent</ul>\n";
    }

    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        $indent = ($depth) ? str_repeat("\t", $depth) : '';
        $classes = empty($item->classes) ? [] : (array) $item->classes;

        // Add classes based on depth and children
        if ($depth === 0 && $args->walker->has_children) {
            $classes[] = 'nav-item dropdown';
        } elseif ($depth === 1 && $args->walker->has_children) {
            $classes[] = 'nav-item dropdown';
        } else {
            $classes[] = 'nav-item';
        }

        // Remove classes for dropdown items
        if ($depth > 0) {
            $classes = [];
        }

        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args, $depth));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';

        $output .= $indent . '<li' . $class_names . '>';

        // Set anchor classes
        $link_classes = $depth === 0
            ? ($args->walker->has_children ? 'nav-link dropdown-toggle' : 'nav-link')
            : 'dropdown-item';

        $attributes = '';
        !empty($item->url) && $attributes .= ' href="' . esc_attr($item->url) . '"';
        $attributes .= ' class="' . esc_attr($link_classes) . '"';
        if ($depth === 0 && $args->walker->has_children) {
            $attributes .= ' id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"';
        }

        $item_output = $args->before;
        $item_output .= '<a' . $attributes . '>';
        $item_output .= $args->link_before . $item->title . $args->link_after;
        $item_output .= ($depth === 0 && $args->walker->has_children) ? '<span class="caret"><i class="fa-solid fa-angle-down"></i></span></a>' : '</a>';
        // $item_output .= '</a>';
        $item_output .= $args->after;

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }

    function end_el(&$output, $item, $depth = 0, $args = null)
    {
        $output .= "</li>\n";
    }
}


?>