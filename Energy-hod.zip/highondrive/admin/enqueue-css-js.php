<?php


function my_theme_styles_and_scripts()
{
    wp_enqueue_style('highondrive-bootstrap-min-css', get_template_directory_uri() . '/assets/css/bootstrap.min.css', array(), _S_VERSION);
    wp_enqueue_style('highondrive-magnific-min-css', get_template_directory_uri() . '/assets/css/magnific-popup.min.css', array(), _S_VERSION);
    wp_enqueue_style('highondrive-swiper-min-css', get_template_directory_uri() . '/assets/css/swiper-bundle.min.css', array(), _S_VERSION);
    wp_enqueue_style('highondrive-all-css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', array(), '6.5.2');
    wp_enqueue_style('highondrive-fancybox-min-css', get_template_directory_uri() . '/assets/css/fancybox.min.css', array(), _S_VERSION);
    wp_enqueue_style('highondrive-custom-min-css', get_template_directory_uri() . '/assets/css/custom.css', array(), _S_VERSION);
    wp_enqueue_style('highondrive-responsive-min-css', get_template_directory_uri() . '/assets/css/responsive.css', array(), _S_VERSION);


    wp_enqueue_script('highondrive-jquery-min-js', get_template_directory_uri() . '/assets/js/jquery.min.js', array(), _S_VERSION, false);
    wp_enqueue_script('highondrive-bootstrap-min-js', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), _S_VERSION, true);
    wp_enqueue_script('highondrive-magnific-min-js', get_template_directory_uri() . '/assets/js/magnific-popup.min.js', array(), _S_VERSION, true);
    wp_enqueue_script('highondrive-swiper-min-js', get_template_directory_uri() . '/assets/js/swiper-bundle.min.js', array(), _S_VERSION, true);
    wp_enqueue_script('highondrive-fancybox-min-js', get_template_directory_uri() . '/assets/js/fancybox.umd.js', array(), _S_VERSION, true);
    wp_enqueue_script('highondrive-custom-min-js', get_template_directory_uri() . '/assets/js/custom.js', array(), _S_VERSION, true);
    wp_enqueue_script('highondrive-ajax-js', get_template_directory_uri() . '/assets/js/ajax.js', array(), _S_VERSION, true);

    wp_enqueue_script('highondrive-jquery-ui-js', 'https://code.jquery.com/ui/1.12.1/jquery-ui.min.js', array(), _S_VERSION, true);

    wp_localize_script('highondrive-ajax-js', 'ajax_object', array(
        'ajax_url' => admin_url('admin-ajax.php'),
    ));
}

add_action('wp_enqueue_scripts', 'my_theme_styles_and_scripts');

?>