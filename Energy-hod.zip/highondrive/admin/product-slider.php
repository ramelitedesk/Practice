<?php
function product_slider($bs)
{
    // Ensure $bs contains product IDs; otherwise, default to an empty array
    $product_ids = isset($bs) ? $bs : array();

    if (!empty($product_ids)) :
        ?>
        <div class="col-lg-12">
            <div class="product__seller-wrapper">
                <div class="swiper drive__product-swiper">
                    <div class="swiper-wrapper">
                        <?php foreach ($product_ids as $product_id) : 
                            $post_object = get_post($product_id);
                            if ($post_object) :
                                setup_postdata($post_object);
                                ?>
                                <div class="swiper-slide">
                                    <?php wc_get_template_part('content', 'product'); ?>
                                </div>
                                <?php
                                wp_reset_postdata();
                            endif;
                        endforeach; ?>
                    </div>
                    <div class="swiper-button-prev swiper-button-prev1">
                        <i class="fa-solid fa-chevron-left"></i>
                    </div>
                    <div class="swiper-button-next swiper-button-next1">
                        <i class="fa-solid fa-chevron-right"></i>
                    </div>
                </div>
            </div>
        </div>
        <?php
    endif;
}
