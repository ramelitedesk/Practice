<?php
// Function to generate a random SKU
function generate_random_sku()
{
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $skuLength = 6; // Length of the SKU

    $randomSKU = '';

    // Ensure at least one letter and one number
    $randomSKU .= $characters[rand(0, 9)]; // Ensure at least one number
    $randomSKU .= $characters[rand(10, $charactersLength - 1)]; // Ensure at least one letter

    // Generate the remaining characters
    for ($i = 2; $i < $skuLength; $i++) {
        $randomSKU .= $characters[rand(0, $charactersLength - 1)];
    }

    // Shuffle the string to avoid fixed positions of letters and numbers
    return str_shuffle($randomSKU);
}

// Function to assign a SKU to a product
function assign_random_sku_to_product($post_id)
{
    // Check if this is an auto-save routine
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Check if the post type is 'product'
    if (get_post_type($post_id) !== 'product') {
        return;
    }

    // Check if the SKU already exists
    $existing_sku = get_post_meta($post_id, '_sku', true);

    // Generate and save a random SKU only if it doesn't exist
    if (empty($existing_sku)) {
        $sku = generate_random_sku();
        update_post_meta($post_id, '_sku', $sku);

        // Debugging (optional)
        error_log('SKU generated and saved: ' . $sku);
    }
}

// Hook into the 'save_post' action to generate SKU
add_action('save_post', 'assign_random_sku_to_product');
