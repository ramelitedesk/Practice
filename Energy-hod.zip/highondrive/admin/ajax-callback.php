<?php
function get_search_suggestions()
{
    $term = sanitize_text_field($_POST['term']);

    global $wpdb;

    $skus = $wpdb->get_col("SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_sku'");

    $matching_sku = '';

    foreach ($skus as $sku) {
        if (strcasecmp($sku, $term) === 0) {
            $matching_sku = $sku;
            break;
        }
    }
    $response = [];
    $args = [
        'post_type' => 'product',
        'posts_per_page' => 10,
        'meta_query' => !empty($matching_sku) && preg_match('/^[a-zA-Z0-9-]+$/', $matching_sku) && !preg_match('/^\d+$/', $matching_sku)
            ? [['key' => '_sku', 'value' => $matching_sku, 'compare' => 'LIKE']]
            : [],
        's' => empty($matching_sku) || !preg_match('/^[a-zA-Z0-9-]+$/', $matching_sku) || preg_match('/^\d+$/', $matching_sku)
            ? $term
            : ''
    ];
    $query = new WP_Query($args);
    $post_search = array();

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $product_image = get_the_post_thumbnail_url(get_the_ID(), 'thumbnail');
            $post_search[] = array(
                'label' => get_the_title(),
                'url' => get_permalink(),
                'image' => $product_image
            );
        }
    }

    wp_reset_postdata();

    $service_args = [
        'post_type' => 'post',
        'posts_per_page' => 10,
        's' => $term
    ];
    $service_query = new WP_Query($service_args);
    $service_search = array();

    if ($service_query->have_posts()) {
        while ($service_query->have_posts()) {
            $service_query->the_post();
            $service_image = get_the_post_thumbnail_url(get_the_ID(), 'thumbnail');
            $service_search[] = array(
                'label' => get_the_title(),
                'url' => get_permalink(),
                'image' => $service_image
            );
        }
    }
    wp_reset_postdata();
    $response = [
        'product' => $post_search,
        'post' => $service_search,
    ];
    echo json_encode($response);
    exit;
}
add_action('wp_ajax_get_search_suggestions', 'get_search_suggestions');
add_action('wp_ajax_nopriv_get_search_suggestions', 'get_search_suggestions');