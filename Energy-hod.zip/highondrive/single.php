<?php

/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package highondrive
 */

get_header();
?>

<section class="site__inner-banner  custom-pad-braedcrumb">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="drive__inner-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo esc_html(home_url('/')); ?>"><i
                                        class="fa-solid fa-house-chimney"></i></a>
                            </li>
							<li class="breadcrumb-item"><a href="<?php echo site_url('/blog/');?>">Blog</a></li>
							<li class="breadcrumb-item active" aria-current="page"><?php echo get_the_title();?></li>                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<section class="single_blog_content custom-pad pt-0">
	<div class="container">
		<div class="single_blog_content_wrapper ">
			<?php
			while (have_posts()) :
				the_post();
				get_template_part('template-parts/content', get_post_type());
			endwhile; // End of the loop.
			?>
		</div>
	</div>
</section>


<?php
get_footer();
